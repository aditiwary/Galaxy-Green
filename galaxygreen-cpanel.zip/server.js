// cPanel / Phusion Passenger Node.js Startup File
import("./.output/server/index.mjs");
