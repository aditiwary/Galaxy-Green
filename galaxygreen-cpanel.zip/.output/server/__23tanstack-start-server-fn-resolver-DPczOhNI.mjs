//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-DPczOhNI.js
var manifest = {
	"0962a1e2dd3197bad26b146bdd61eed6e69f7038cdd069591f142ecc8c0685c1": {
		functionName: "updateAdminConfigFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"0f2f9b5130e556d3703f4e4e0b680d8beadac7e625696b2c98bdb56803ea808a": {
		functionName: "updatePlotFn_createServerFn_handler",
		importer: () => import("./_ssr/server-plots-ZshRQhNc.mjs")
	},
	"229ab4d8d9e2af42116f701d93c17ed66b09d8e83df8d142383772d647367c61": {
		functionName: "adminCreateInquiryFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"259c099986c4c7c61bab8947852c80d8fde8680824e76666722a26c4725ea1fd": {
		functionName: "updatePlotStatusFn_createServerFn_handler",
		importer: () => import("./_ssr/server-plots-ZshRQhNc.mjs")
	},
	"43cd7b54e5dc3bcb5518523224afd8375657788c242e7a28c12b315439ae2fbb": {
		functionName: "getAdminConfigFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"4877a1cab4e33623d7dcfe7339376faf33cbd3233330988495f52b8680c031c9": {
		functionName: "submitInquiryFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"505be61f9be0c6d90fc623b88117224ca63263ae0c12268ce4e49dcb70af582a": {
		functionName: "checkDbHealthFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"5e26ac6fa8f922e9958a1008e30aa59228ff5a307c4a951894aac4575e90051f": {
		functionName: "getInquiriesFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"71aea097aeb5e10964f19f87ad24f909232bd0e78dbeb7cb02f6d05cfe5b283d": {
		functionName: "deleteUserBookingFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"8c710ba4c68dd2ed572581dc584f419650b9e0a6aa6f12e5d0c6347969b95968": {
		functionName: "getGalleryPhotosFn_createServerFn_handler",
		importer: () => import("./_ssr/server-photos-DSmiJlPC.mjs")
	},
	"9d6b73876cd40b51a52c7ab36aa575bd58faa97bae203d0ffe1f8d16caf4ad01": {
		functionName: "uploadGalleryPhotoFn_createServerFn_handler",
		importer: () => import("./_ssr/server-photos-DSmiJlPC.mjs")
	},
	"ccb4fcc0e7246afcc476b8436daced544a671fe0598a87fa727c5832f88bdbf1": {
		functionName: "updateUserBookingFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"d125ede39de5148edd10518c551ad2202cbab0d643afefdf8b8a497be6188831": {
		functionName: "deletePlotFn_createServerFn_handler",
		importer: () => import("./_ssr/server-plots-ZshRQhNc.mjs")
	},
	"da08288dee2b8de2f703e2e6761fd88e44f780fda7ecb8ef2ca897e534fa7921": {
		functionName: "deleteInquiryFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"e1c9dfbebb211bc04aae75249b29da3d4165d897aeceaad3c8d64a443253e4fd": {
		functionName: "deleteGalleryPhotoFn_createServerFn_handler",
		importer: () => import("./_ssr/server-photos-DSmiJlPC.mjs")
	},
	"e7ac86809fa5971ab2c5617edd3c6f0b3b2d480f6744776eb92f355f7285a156": {
		functionName: "verifyDealerPinFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"e84fb555a6cb651ec16f9488a9b44867349925588b9630f1ed87aba7f6b9c588": {
		functionName: "updateInquiryStatusFn_createServerFn_handler",
		importer: () => import("./_ssr/server-inquiries-DI9I81NX.mjs")
	},
	"edbac7c3ae6095459940938f08e64e482be3eee43774392588100cc872807d7b": {
		functionName: "getPlotsFn_createServerFn_handler",
		importer: () => import("./_ssr/server-plots-ZshRQhNc.mjs")
	},
	"fd475df625a73983c0c3375d6a7527582026cb8a08676484661b19b79f06298e": {
		functionName: "createPlotFn_createServerFn_handler",
		importer: () => import("./_ssr/server-plots-ZshRQhNc.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
