//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cj39dKbD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bv6BpDAL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bv6BpDAL.js"
		} }]
	},
	"/": {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B5uZUg8v.js",
			"/assets/server-inquiries-ecGOO0tG.js",
			"/assets/badge-Cesw7yfD.js",
			"/assets/ClockTimePicker-DwG1zkWD.js",
			"/assets/trees-RrzKWYy8.js",
			"/assets/textarea-CUvlJzwF.js",
			"/assets/visit-helpers-HqguzM7R.js",
			"/assets/photos-client-DPcfIzSe.js",
			"/assets/download-BvRn3Owp.js",
			"/assets/shield-check-BV1t1fIf.js",
			"/assets/user-CRxz970H.js",
			"/assets/leads-client-5RpmLBqO.js",
			"/assets/dialog-DFK5hAEU.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
