globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/_headers": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"db-4Lpc/+wyUAOsz7sUxXM8/lz75Jo\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 219,
		"path": "../public/_headers"
	},
	"/android-chrome-192x192.png": {
		"type": "image/png",
		"etag": "\"f1e1-Rw5EMhMGcqzTgvFD+xP1AKQVa30\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 61921,
		"path": "../public/android-chrome-192x192.png"
	},
	"/android-chrome-512x512.png": {
		"type": "image/png",
		"etag": "\"51299-zWSZz0nXo+nvuOVUah2UP/KYhWY\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 332441,
		"path": "../public/android-chrome-512x512.png"
	},
	"/favicon-32x32.png": {
		"type": "image/png",
		"etag": "\"ac3-p6TIrRd9frBfsoya34j5C0XSErc\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 2755,
		"path": "../public/favicon-32x32.png"
	},
	"/favicon-64x64.png": {
		"type": "image/png",
		"etag": "\"232a-IzWqVjXQIBRJ8VST43u0S1Qllmk\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 9002,
		"path": "../public/favicon-64x64.png"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"2f93-+rj+KBw15muPwxshghy85DPsnuU\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 12179,
		"path": "../public/favicon.svg"
	},
	"/galaxy-green-emblem.jpg": {
		"type": "image/jpeg",
		"etag": "\"ea17-IVkwlp8L9yf1eJ9Bh9ItMN56XkA\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 59927,
		"path": "../public/galaxy-green-emblem.jpg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"d8-VUSS2CQ4Yu7Feijxxv468X+SXjg\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 216,
		"path": "../public/robots.txt"
	},
	"/galaxy-green-logo.jpg": {
		"type": "image/jpeg",
		"etag": "\"1f254-ldlUI2iqXreBw0kZ3qE+hdtkNP0\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 127572,
		"path": "../public/galaxy-green-logo.jpg"
	},
	"/sitemap.xml": {
		"type": "application/xml",
		"etag": "\"2ee-T6Yh2e5C+pKwqsuH+oam2s+koM8\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 750,
		"path": "../public/sitemap.xml"
	},
	"/galaxy-green-emblem.png": {
		"type": "image/png",
		"etag": "\"50d58-Bniim/2lJ8B93NQWKZYdI+Zd5FQ\"",
		"mtime": "2026-09-24T13:15:16.750Z",
		"size": 331096,
		"path": "../public/galaxy-green-emblem.png"
	},
	"/assets/lucknow-connectivity-B43LUJi1.jpg": {
		"type": "image/jpeg",
		"etag": "\"4f29e-tkxEMsFCLj5JXdhx3VMbdJulTvU\"",
		"mtime": "2026-09-24T13:15:16.397Z",
		"size": 324254,
		"path": "../public/assets/lucknow-connectivity-B43LUJi1.jpg"
	},
	"/assets/index-DBUMvH76.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6732c-YReivUMW5Qt/F5ZbWLGZNZz/Tvg\"",
		"mtime": "2026-09-24T13:15:16.397Z",
		"size": 422700,
		"path": "../public/assets/index-DBUMvH76.js"
	},
	"/assets/routes-B2TfYeCq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"62242-hzlL5YWR/cntPszTUSRic9YyJzk\"",
		"mtime": "2026-09-24T13:15:16.397Z",
		"size": 401986,
		"path": "../public/assets/routes-B2TfYeCq.js"
	},
	"/assets/styles-DbGlTcCj.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"21c44-dhka5ouHeJvm2+VW3R7G9l7bM1c\"",
		"mtime": "2026-09-24T13:15:16.397Z",
		"size": 138308,
		"path": "../public/assets/styles-DbGlTcCj.css"
	},
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"d86a-UyncuBQ13CEMMFkgfBZGisUv5Gc\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 55402,
		"path": "../public/apple-touch-icon.png"
	},
	"/site-photos/galaxy-green-actual-site-1.jpg": {
		"type": "image/jpeg",
		"etag": "\"2e6ef-fv7CYnbYpUT+O2JKGGyqkFqwiTE\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 190191,
		"path": "../public/site-photos/galaxy-green-actual-site-1.jpg"
	},
	"/site-photos/galaxy-green-actual-site-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"2b9b4-R2oUMrSDg/ACZuTL3BdMf4vXs8w\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 178612,
		"path": "../public/site-photos/galaxy-green-actual-site-2.jpg"
	},
	"/site-photos/galaxy-green-actual-site-4.jpg": {
		"type": "image/jpeg",
		"etag": "\"324f7-T7JiosUaeKdPaWpF21FHy38aQSM\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 206071,
		"path": "../public/site-photos/galaxy-green-actual-site-4.jpg"
	},
	"/site-photos/galaxy-green-actual-site-3.jpg": {
		"type": "image/jpeg",
		"etag": "\"29a47-01jnEOctJp4AGLaEbkxRe2NjnVw\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 170567,
		"path": "../public/site-photos/galaxy-green-actual-site-3.jpg"
	},
	"/site-photos/galaxy-green-airport-connectivity.jpg": {
		"type": "image/jpeg",
		"etag": "\"4f29e-tkxEMsFCLj5JXdhx3VMbdJulTvU\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 324254,
		"path": "../public/site-photos/galaxy-green-airport-connectivity.jpg"
	},
	"/site-photos/galaxy-green-actual-site-5.jpg": {
		"type": "image/jpeg",
		"etag": "\"40793-fhs2cEE2Hne/EgI7ulOIMOaVo+Y\"",
		"mtime": "2026-09-24T13:15:16.748Z",
		"size": 264083,
		"path": "../public/site-photos/galaxy-green-actual-site-5.jpg"
	},
	"/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf": {
		"type": "application/pdf",
		"etag": "\"8d0c8-rt3jNshVXOyJQjMD79Eobiiy1Mk\"",
		"mtime": "2026-09-24T13:15:16.749Z",
		"size": 577736,
		"path": "../public/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf"
	},
	"/assets/township-entrance-CKrNp9yg.jpg": {
		"type": "image/jpeg",
		"etag": "\"f17e2-Q3B8EQzAlD09sWFzm+FrE0SSuA8\"",
		"mtime": "2026-09-24T13:15:16.398Z",
		"size": 989154,
		"path": "../public/assets/township-entrance-CKrNp9yg.jpg"
	},
	"/assets/luxury-villa-concept-BIJPGvq-.jpg": {
		"type": "image/jpeg",
		"etag": "\"f95ad-1sLGI6XdqeWSr1H96r0gnazlI4Y\"",
		"mtime": "2026-09-24T13:15:16.397Z",
		"size": 1021357,
		"path": "../public/assets/luxury-villa-concept-BIJPGvq-.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_zpepD0 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_zpepD0
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
