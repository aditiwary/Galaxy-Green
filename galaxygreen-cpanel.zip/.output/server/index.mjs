globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/.DS_Store": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"2004-CFP97lNfypQcWO3bV0HweoSg6vI\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 8196,
		"path": "../public/.DS_Store"
	},
	"/.htaccess": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"af8-BD7gDdob4PjPYhYzbMwn9CcWobc\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 2808,
		"path": "../public/.htaccess"
	},
	"/_headers": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"3a3-K+kwbkoBkcnZfIXZt5xkvfLf4KY\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 931,
		"path": "../public/_headers"
	},
	"/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf": {
		"type": "application/pdf",
		"etag": "\"3dd5d-QKDPgLGPabtDrI3B68iDINWyYPQ\"",
		"mtime": "2026-10-01T14:45:09.059Z",
		"size": 253277,
		"path": "../public/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf"
	},
	"/android-chrome-192x192.png": {
		"type": "image/png",
		"etag": "\"d2ea-fEZjTRtGTI3rjDn2CRBcmA+Z5zc\"",
		"mtime": "2026-10-01T14:45:09.060Z",
		"size": 53994,
		"path": "../public/android-chrome-192x192.png"
	},
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"bd78-UBoUkDtz5fpkc8b/kCwZCnkcG3M\"",
		"mtime": "2026-10-01T14:45:09.060Z",
		"size": 48504,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon-32x32.png": {
		"type": "image/png",
		"etag": "\"d5d-JxczoSvPB76x6R0JO/dqWMTDCuQ\"",
		"mtime": "2026-10-01T14:45:09.060Z",
		"size": 3421,
		"path": "../public/favicon-32x32.png"
	},
	"/android-chrome-512x512.png": {
		"type": "image/png",
		"etag": "\"42dfb-4U6b4soj0eoqmzV+66zw7SdixEA\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 273915,
		"path": "../public/android-chrome-512x512.png"
	},
	"/favicon-48x48.png": {
		"type": "image/png",
		"etag": "\"17fc-Xg4qTPYJa2RLlNZb7NQBhcP7XXY\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 6140,
		"path": "../public/favicon-48x48.png"
	},
	"/favicon-64x64.png": {
		"type": "image/png",
		"etag": "\"24ce-MsmOPUCuCpVc4ozDQA4/van1Foo\"",
		"mtime": "2026-10-01T14:45:09.060Z",
		"size": 9422,
		"path": "../public/favicon-64x64.png"
	},
	"/favicon-96x96.png": {
		"type": "image/png",
		"etag": "\"4479-ZIDHg0K55kxm7Dyvvm/WPM6G5Og\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 17529,
		"path": "../public/favicon-96x96.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"2b86-CbrzFOFlGw3SX3OZnIx2IkANQuE\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 11142,
		"path": "../public/favicon.ico"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"58ac-mb6KdskFP7gLS1JUihiW/+CdDAA\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 22700,
		"path": "../public/favicon.svg"
	},
	"/galaxy-green-emblem.png": {
		"type": "image/png",
		"etag": "\"14b8d-3qBGF6TFnpxywXrc0fp/uJ2nSgc\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 84877,
		"path": "../public/galaxy-green-emblem.png"
	},
	"/galaxy-green-logo.jpg": {
		"type": "image/jpeg",
		"etag": "\"18d15-p5YXCRKlbnLyNyaBiRDHbVFLmaE\"",
		"mtime": "2026-10-01T14:45:09.064Z",
		"size": 101653,
		"path": "../public/galaxy-green-logo.jpg"
	},
	"/galaxy-green-emblem.jpg": {
		"type": "image/jpeg",
		"etag": "\"28ec3-ony8niwIsLvLGsqrQ3L/xIxYEtY\"",
		"mtime": "2026-10-01T14:45:09.062Z",
		"size": 167619,
		"path": "../public/galaxy-green-emblem.jpg"
	},
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"2ad-4JiJeeJIuEfNofLvkrcqm3S+jpU\"",
		"mtime": "2026-10-01T14:45:09.061Z",
		"size": 685,
		"path": "../public/manifest.json"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"d8-VUSS2CQ4Yu7Feijxxv468X+SXjg\"",
		"mtime": "2026-10-01T14:45:09.062Z",
		"size": 216,
		"path": "../public/robots.txt"
	},
	"/sitemap.xml": {
		"type": "application/xml",
		"etag": "\"296-ocatQtMEPtsiQD6DRLGbWoTdEBs\"",
		"mtime": "2026-10-01T14:45:09.062Z",
		"size": 662,
		"path": "../public/sitemap.xml"
	},
	"/site.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"2ad-4JiJeeJIuEfNofLvkrcqm3S+jpU\"",
		"mtime": "2026-10-01T14:45:09.062Z",
		"size": 685,
		"path": "../public/site.webmanifest"
	},
	"/amenities/amenity-electricity.jpg": {
		"type": "image/jpeg",
		"etag": "\"1973e-fJRAetyoZvIxuitoHb5ImKL0dB0\"",
		"mtime": "2026-10-01T14:45:09.054Z",
		"size": 104254,
		"path": "../public/amenities/amenity-electricity.jpg"
	},
	"/amenities/amenity-nagar-nigam.jpg": {
		"type": "image/jpeg",
		"etag": "\"1c378-mtqBKCtkgQiK6VPecXRgy4RX0Ug\"",
		"mtime": "2026-10-01T14:45:09.054Z",
		"size": 115576,
		"path": "../public/amenities/amenity-nagar-nigam.jpg"
	},
	"/amenities/amenity-gated-society.jpg": {
		"type": "image/jpeg",
		"etag": "\"28a80-9rbtkHdnpMk+ZO4d+YS6RAhc5ng\"",
		"mtime": "2026-10-01T14:45:09.054Z",
		"size": 166528,
		"path": "../public/amenities/amenity-gated-society.jpg"
	},
	"/amenities/amenity-roads.jpg": {
		"type": "image/jpeg",
		"etag": "\"24e2f-xPppdRTlMRtBgmYE/TF/kBlMpI8\"",
		"mtime": "2026-10-01T14:45:09.055Z",
		"size": 151087,
		"path": "../public/amenities/amenity-roads.jpg"
	},
	"/amenities/amenity-parks.jpg": {
		"type": "image/jpeg",
		"etag": "\"276d9-ID3VPVKZeMXiQQE/gdhyQCiAtf0\"",
		"mtime": "2026-10-01T14:45:09.055Z",
		"size": 161497,
		"path": "../public/amenities/amenity-parks.jpg"
	},
	"/amenities/amenity-security.jpg": {
		"type": "image/jpeg",
		"etag": "\"1bfb8-h/pBbcNSokNegMPo2Q2tT9ulxFw\"",
		"mtime": "2026-10-01T14:45:09.055Z",
		"size": 114616,
		"path": "../public/amenities/amenity-security.jpg"
	},
	"/amenities/amenity-water-supply.jpg": {
		"type": "image/jpeg",
		"etag": "\"2c467-8JUShno2cr/dufmsLFSBSchbpBQ\"",
		"mtime": "2026-10-01T14:45:09.055Z",
		"size": 181351,
		"path": "../public/amenities/amenity-water-supply.jpg"
	},
	"/site-photos/galaxy-green-actual-site-1.jpg": {
		"type": "image/jpeg",
		"etag": "\"2afd3-zq8lJsTBZ/5j5BzUAGhQRsBfZsE\"",
		"mtime": "2026-10-01T14:45:09.055Z",
		"size": 176083,
		"path": "../public/site-photos/galaxy-green-actual-site-1.jpg"
	},
	"/site-photos/galaxy-green-actual-site-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"28856-aoK9f8FbDH45EgeUB2kQJZAh2EE\"",
		"mtime": "2026-10-01T14:45:09.054Z",
		"size": 165974,
		"path": "../public/site-photos/galaxy-green-actual-site-2.jpg"
	},
	"/site-photos/galaxy-green-actual-site-3.jpg": {
		"type": "image/jpeg",
		"etag": "\"26a6e-4PbwyxUMy606UWE95R2Chf7naMc\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 158318,
		"path": "../public/site-photos/galaxy-green-actual-site-3.jpg"
	},
	"/site-photos/galaxy-green-actual-site-4.jpg": {
		"type": "image/jpeg",
		"etag": "\"2e851-AIMhPGb6oouER4zVVx7h8Mff02Y\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 190545,
		"path": "../public/site-photos/galaxy-green-actual-site-4.jpg"
	},
	"/site-photos/galaxy-green-actual-site-5.jpg": {
		"type": "image/jpeg",
		"etag": "\"39df2-1vhIdzN+Z5heU4v5b83RD8NAGLQ\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 237042,
		"path": "../public/site-photos/galaxy-green-actual-site-5.jpg"
	},
	"/site-photos/galaxy-green-airport-connectivity.jpg": {
		"type": "image/jpeg",
		"etag": "\"45ddd-TYq2RypsgU9ItMyQN9Nflrr+mWc\"",
		"mtime": "2026-10-01T14:45:09.058Z",
		"size": 286173,
		"path": "../public/site-photos/galaxy-green-airport-connectivity.jpg"
	},
	"/assets/AdminLeadsDrawer-CyJorfuI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11c63-hKdsXA7eAiBDoid/aq0gmaCijew\"",
		"mtime": "2026-10-01T14:45:08.623Z",
		"size": 72803,
		"path": "../public/assets/AdminLeadsDrawer-CyJorfuI.js"
	},
	"/assets/BrochureModal-d9P0pH09.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cf0-3dnsA2LdeS9KPDbu0r3JMpQrVp8\"",
		"mtime": "2026-10-01T14:45:08.623Z",
		"size": 7408,
		"path": "../public/assets/BrochureModal-d9P0pH09.js"
	},
	"/assets/ClockTimePicker-DwG1zkWD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2758-oipRH1ODgNZ7JPeQMZlQS8f/X4A\"",
		"mtime": "2026-10-01T14:45:08.623Z",
		"size": 10072,
		"path": "../public/assets/ClockTimePicker-DwG1zkWD.js"
	},
	"/assets/MyBookingsDrawer-DE5cj9LU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47fe-50WXQNTGlaUOnn/xmRrsaiHo2ag\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 18430,
		"path": "../public/assets/MyBookingsDrawer-DE5cj9LU.js"
	},
	"/assets/SiteVisitModal-CAZkXh8M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5590-+PiAUn6WBfGKHreEqsbbbxyqMV4\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 21904,
		"path": "../public/assets/SiteVisitModal-CAZkXh8M.js"
	},
	"/assets/badge-Cesw7yfD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10ec7-Qi7zxWEJSL5OfUI5y11BM6Y909U\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 69319,
		"path": "../public/assets/badge-Cesw7yfD.js"
	},
	"/assets/circle-alert-B9IFni5L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef-rn6qjeALaPxEiybakGrBPEoqyD0\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 239,
		"path": "../public/assets/circle-alert-B9IFni5L.js"
	},
	"/assets/dialog-DFK5hAEU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75b-DtDqOMbkP/sbKqhEr7zWU0BMeFA\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 1883,
		"path": "../public/assets/dialog-DFK5hAEU.js"
	},
	"/assets/download-BvRn3Owp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd-LfcnugVziYkjmBshClq8kaa7L60\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 221,
		"path": "../public/assets/download-BvRn3Owp.js"
	},
	"/assets/index-Bv6BpDAL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"677b0-l1FYdyLfXyA5zjUh2Y1GH82/Smg\"",
		"mtime": "2026-10-01T14:45:08.623Z",
		"size": 423856,
		"path": "../public/assets/index-Bv6BpDAL.js"
	},
	"/assets/label-Ck6XuCgM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"287-BRtpi3qZWEzJ2fHHKIXMR/scEzE\"",
		"mtime": "2026-10-01T14:45:08.624Z",
		"size": 647,
		"path": "../public/assets/label-Ck6XuCgM.js"
	},
	"/assets/leads-client-5RpmLBqO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a6-cK8yBM9KFJ3hvFQ05eAtNftQor4\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 4518,
		"path": "../public/assets/leads-client-5RpmLBqO.js"
	},
	"/assets/lucknow-connectivity-D3tu17Py.jpg": {
		"type": "image/jpeg",
		"etag": "\"4fe79-ECfmnJdvLwsPZmsC4+x0uWUkSp8\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 327289,
		"path": "../public/assets/lucknow-connectivity-D3tu17Py.jpg"
	},
	"/assets/luxury-villa-concept-Sn-U05g1.jpg": {
		"type": "image/jpeg",
		"etag": "\"52149-+tl9WJummKdQlVqWOfahzVoLAfI\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 336201,
		"path": "../public/assets/luxury-villa-concept-Sn-U05g1.jpg"
	},
	"/assets/photos-client-DPcfIzSe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"123fb-DFXQ6sAo5XWQHgycKi0KT/Vbk04\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 74747,
		"path": "../public/assets/photos-client-DPcfIzSe.js"
	},
	"/assets/routes-B5uZUg8v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"233bb-EPjLq1LjwFxP2KJNmxU+n3sGJ+U\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 144315,
		"path": "../public/assets/routes-B5uZUg8v.js"
	},
	"/assets/server-inquiries-ecGOO0tG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1939-W1fMiwmvbpajrFCJmtrqKwWNU1g\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 6457,
		"path": "../public/assets/server-inquiries-ecGOO0tG.js"
	},
	"/assets/shield-check-BV1t1fIf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135-CEX3F2400dOJp1EtZiR8vLvIiK0\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 309,
		"path": "../public/assets/shield-check-BV1t1fIf.js"
	},
	"/assets/styles-OoTdsBmp.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"237b0-uNyCsxD/HyJeqdinaDBH8cxqys0\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 145328,
		"path": "../public/assets/styles-OoTdsBmp.css"
	},
	"/assets/textarea-CUvlJzwF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ff-tgX+lqUNYyMOJ1bH5PLAx+w5EAU\"",
		"mtime": "2026-10-01T14:45:08.625Z",
		"size": 767,
		"path": "../public/assets/textarea-CUvlJzwF.js"
	},
	"/assets/township-entrance-x7-uqFp1.jpg": {
		"type": "image/jpeg",
		"etag": "\"619e0-2TsNfNYb7L3uUSXeSa/dOA+JQQ8\"",
		"mtime": "2026-10-01T14:45:08.627Z",
		"size": 399840,
		"path": "../public/assets/township-entrance-x7-uqFp1.jpg"
	},
	"/assets/trash-2-C-TMuQeu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48f-g9umh2E006DKpzs9XO+1MLnePu4\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 1167,
		"path": "../public/assets/trash-2-C-TMuQeu.js"
	},
	"/assets/trees-RrzKWYy8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"436-tpSNIaYklYrxBAAvlA5VwfND/AQ\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 1078,
		"path": "../public/assets/trees-RrzKWYy8.js"
	},
	"/assets/user-CRxz970H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b9-3qs+W0Tdf/4lMl6sXZF0Ez6O/Go\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 185,
		"path": "../public/assets/user-CRxz970H.js"
	},
	"/assets/visit-helpers-HqguzM7R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1327-wOb/YctdaPipwPxLUiPjXhXZPMU\"",
		"mtime": "2026-10-01T14:45:08.626Z",
		"size": 4903,
		"path": "../public/assets/visit-helpers-HqguzM7R.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_zpepD0 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_zpepD0
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
