import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { r as cn } from "./badge-CC6878ln.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-DPczOhNI.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { t as inquirySchema } from "./inquiry-types-BhnwrXC3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-inquiries-BZCzG7ab.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var checkDbHealthFn = createServerFn({ method: "GET" }).handler(createSsrRpc("505be61f9be0c6d90fc623b88117224ca63263ae0c12268ce4e49dcb70af582a"));
var verifyDealerPinFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e7ac86809fa5971ab2c5617edd3c6f0b3b2d480f6744776eb92f355f7285a156"));
var getAdminConfigFn = createServerFn({ method: "GET" }).handler(createSsrRpc("43cd7b54e5dc3bcb5518523224afd8375657788c242e7a28c12b315439ae2fbb"));
var updateAdminConfigFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("0962a1e2dd3197bad26b146bdd61eed6e69f7038cdd069591f142ecc8c0685c1"));
var getInquiriesFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("5e26ac6fa8f922e9958a1008e30aa59228ff5a307c4a951894aac4575e90051f"));
var submitInquiryFn = createServerFn({ method: "POST" }).validator((data) => inquirySchema.parse(data)).handler(createSsrRpc("4877a1cab4e33623d7dcfe7339376faf33cbd3233330988495f52b8680c031c9"));
var updateInquiryStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e84fb555a6cb651ec16f9488a9b44867349925588b9630f1ed87aba7f6b9c588"));
var deleteInquiryFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("da08288dee2b8de2f703e2e6761fd88e44f780fda7ecb8ef2ca897e534fa7921"));
var adminCreateInquiryFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("229ab4d8d9e2af42116f701d93c17ed66b09d8e83df8d142383772d647367c61"));
var deleteUserBookingFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("71aea097aeb5e10964f19f87ad24f909232bd0e78dbeb7cb02f6d05cfe5b283d"));
var updateUserBookingFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("ccb4fcc0e7246afcc476b8436daced544a671fe0598a87fa727c5832f88bdbf1"));
//#endregion
export { deleteInquiryFn as a, getInquiriesFn as c, updateInquiryStatusFn as d, updateUserBookingFn as f, createSsrRpc as i, submitInquiryFn as l, adminCreateInquiryFn as n, deleteUserBookingFn as o, verifyDealerPinFn as p, checkDbHealthFn as r, getAdminConfigFn as s, Input as t, updateAdminConfigFn as u };
