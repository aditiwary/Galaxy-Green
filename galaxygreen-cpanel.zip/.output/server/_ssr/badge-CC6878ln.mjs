import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, g as Slot, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-CC6878ln.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-xs font-semibold uppercase tracking-[0.09em] cursor-pointer transition-all duration-250 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed select-none [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "btn-luxury btn-shimmer bg-primary text-primary-foreground shadow-glow hover:bg-primary/95",
			luxury: "btn-luxury btn-shimmer bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-slate-950 font-bold shadow-gold hover:brightness-105",
			destructive: "btn-luxury bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "btn-luxury-outline border border-border text-foreground hover:border-primary/60",
			secondary: "btn-luxury-outline bg-secondary/80 text-secondary-foreground shadow-sm hover:bg-secondary",
			ghost: "transition-all duration-200 hover:bg-surface/90 hover:text-primary text-foreground/90",
			link: "text-primary underline-offset-4 hover:underline normal-case tracking-normal text-sm"
		},
		size: {
			default: "h-10 px-5 py-2",
			sm: "h-8 px-3.5 text-[11px]",
			lg: "h-12 px-7",
			xl: "h-14 px-8 text-xs font-bold tracking-widest",
			icon: "h-10 w-10 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Button as n, cn as r, Badge as t };
