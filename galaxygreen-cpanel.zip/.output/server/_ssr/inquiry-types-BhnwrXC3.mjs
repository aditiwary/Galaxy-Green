import { a as objectType, o as stringType, r as literalType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inquiry-types-BhnwrXC3.js
var inquirySchema = objectType({
	name: stringType().min(2, "Please provide your full name").max(80),
	phone: stringType().regex(/^[6-9]\d{9}$/, "Please provide a valid 10-digit Indian mobile number"),
	email: stringType().email("Invalid email address").optional().or(literalType("")),
	plotPreference: stringType().default("1000 sq ft"),
	visitDate: stringType().optional(),
	slot: stringType().default("Morning (10:00 AM)"),
	cabPickup: booleanType().default(false),
	pickupLocation: stringType().default("On Site"),
	message: stringType().max(500).optional(),
	website: stringType().max(100).optional()
});
//#endregion
export { inquirySchema as t };
