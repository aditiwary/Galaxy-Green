import { f as updateUserBookingFn, o as deleteUserBookingFn } from "./server-inquiries-BZCzG7ab.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visit-helpers-Cila1FpI.js
/**
* Client device local storage manager & server synchronizer for "My Bookings"
* Persists scheduled visits privately on the user's device/browser cache
* and keeps them synchronized in real time with the online MySQL server & Admin CRM.
*/
var STORAGE_KEY = "gg_my_bookings_cache";
var EVENT_NAME = "gg_my_bookings_updated";
var ADMIN_LEADS_STORAGE_KEY = "galaxy_green_leads_v1";
var ADMIN_EVENT_NAME = "gg_leads_updated";
function getLocalBookings() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch (err) {
		console.warn("Failed to read local bookings cache:", err);
		return [];
	}
}
function saveLocalBooking(booking) {
	if (typeof window === "undefined") return [];
	try {
		const existing = getLocalBookings();
		const updated = [{
			...booking,
			bookedAt: booking.bookedAt || (/* @__PURE__ */ new Date()).toISOString()
		}, ...existing.filter((b) => b.id !== booking.id)].slice(0, 20);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
		window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: updated }));
		window.dispatchEvent(new CustomEvent(ADMIN_EVENT_NAME));
		return updated;
	} catch (err) {
		console.warn("Failed to persist local booking:", err);
		return getLocalBookings();
	}
}
function updateLocalBooking(id, updates) {
	if (typeof window === "undefined") return [];
	try {
		const updated = getLocalBookings().map((b) => b.id === id ? {
			...b,
			...updates
		} : b);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
		try {
			const adminRaw = localStorage.getItem(ADMIN_LEADS_STORAGE_KEY);
			if (adminRaw) {
				const adminLeads = JSON.parse(adminRaw);
				if (Array.isArray(adminLeads)) {
					const updatedAdmin = adminLeads.map((item) => {
						if (item.id === id) return {
							...item,
							...updates.visitDate !== void 0 ? { visitDate: updates.visitDate } : {},
							...updates.slot !== void 0 ? { slot: updates.slot } : {},
							...updates.plotPreference !== void 0 ? { plotPreference: updates.plotPreference } : {},
							...updates.message !== void 0 ? { message: updates.message } : {}
						};
						return item;
					});
					localStorage.setItem(ADMIN_LEADS_STORAGE_KEY, JSON.stringify(updatedAdmin));
				}
			}
		} catch {}
		window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: updated }));
		window.dispatchEvent(new CustomEvent(ADMIN_EVENT_NAME));
		return updated;
	} catch (err) {
		console.warn("Failed to update local booking:", err);
		return getLocalBookings();
	}
}
function removeLocalBooking(id) {
	if (typeof window === "undefined") return [];
	try {
		const updated = getLocalBookings().filter((b) => b.id !== id);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
		try {
			const adminRaw = localStorage.getItem(ADMIN_LEADS_STORAGE_KEY);
			if (adminRaw) {
				const adminLeads = JSON.parse(adminRaw);
				if (Array.isArray(adminLeads)) {
					const updatedAdmin = adminLeads.filter((item) => item.id !== id);
					localStorage.setItem(ADMIN_LEADS_STORAGE_KEY, JSON.stringify(updatedAdmin));
				}
			}
		} catch {}
		window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: updated }));
		window.dispatchEvent(new CustomEvent(ADMIN_EVENT_NAME));
		return updated;
	} catch (err) {
		console.warn("Failed to remove local booking:", err);
		return getLocalBookings();
	}
}
function subscribeToBookings(callback) {
	if (typeof window === "undefined") return () => {};
	const handler = () => {
		callback(getLocalBookings());
	};
	window.addEventListener(EVENT_NAME, handler);
	window.addEventListener("storage", handler);
	return () => {
		window.removeEventListener(EVENT_NAME, handler);
		window.removeEventListener("storage", handler);
	};
}
/**
* Server-synced delete: deletes booking from MySQL server, memory cache,
* and local storage, ensuring admin panel immediately updates.
*/
async function syncDeleteUserBooking(id, phone) {
	try {
		const res = await deleteUserBookingFn({ data: {
			id,
			phone
		} });
		removeLocalBooking(id);
		if (res && typeof res === "object" && "success" in res && !res.success && res.error) return {
			success: false,
			error: res.error
		};
		return { success: true };
	} catch (err) {
		removeLocalBooking(id);
		console.warn("Server booking deletion notice:", err);
		return {
			success: true,
			error: err instanceof Error ? err.message : "Deleted locally; will sync with server."
		};
	}
}
/**
* Server-synced update: updates booking on MySQL server, memory cache,
* and local storage, ensuring admin panel immediately updates.
*/
async function syncUpdateUserBooking(id, updates) {
	try {
		const res = await updateUserBookingFn({ data: {
			id,
			...updates
		} });
		if (res && typeof res === "object" && "success" in res && !res.success && res.error) return {
			success: false,
			error: res.error
		};
		updateLocalBooking(id, updates);
		return { success: true };
	} catch (err) {
		console.error("Server booking update error:", err);
		return {
			success: false,
			error: err instanceof Error ? err.message : "Failed to sync updates with server."
		};
	}
}
/**
* Visit scheduling date & time validation utilities
* Ensures local timezone accuracy (immune to UTC date shift) and strict prevention of past date/time bookings
* while keeping all upcoming dates and operational future timings (7:00 AM – 7:00 PM) fully open and usable.
*/
function getLocalDateString(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseTimeHoursMinutes(timeStr) {
	if (!timeStr || typeof timeStr !== "string") return null;
	const clean = timeStr.trim();
	const colonMatch = clean.match(/(\d{1,2})[:.](\d{2})\s*(AM|PM)?/i);
	if (colonMatch && colonMatch[1] && colonMatch[2]) {
		let hours = parseInt(colonMatch[1], 10);
		const minutes = parseInt(colonMatch[2], 10);
		const meridian = colonMatch[3]?.toUpperCase();
		if (meridian === "PM" && hours < 12) hours += 12;
		if (meridian === "AM" && hours === 12) hours = 0;
		if (!meridian && hours >= 1 && hours <= 6) hours += 12;
		return {
			hours,
			minutes
		};
	}
	const hourMatch = clean.match(/^(\d{1,2})\s*(AM|PM)$/i);
	if (hourMatch && hourMatch[1] && hourMatch[2]) {
		let hours = parseInt(hourMatch[1], 10);
		const meridian = hourMatch[2].toUpperCase();
		if (meridian === "PM" && hours < 12) hours += 12;
		if (meridian === "AM" && hours === 12) hours = 0;
		return {
			hours,
			minutes: 0
		};
	}
	return null;
}
/**
* Decomposes a time string into 12-hour parts (hours 1-12, minutes 0-59, AM/PM)
*/
function splitTimeToHMP(timeStr) {
	const parsed = parseTimeHoursMinutes(timeStr);
	if (!parsed) return {
		hour12: 10,
		minute: 0,
		period: "AM"
	};
	const { hours, minutes } = parsed;
	const period = hours >= 12 ? "PM" : "AM";
	let hour12 = hours % 12;
	if (hour12 === 0) hour12 = 12;
	return {
		hour12,
		minute: minutes,
		period
	};
}
/**
* Recombines 12-hour parts into standard formatted time string, e.g. "10:30 AM"
*/
function composeHMPToTime(hour12, minute, period) {
	return `${String(hour12).padStart(2, "0")}:${String(minute).padStart(2, "0")} ${period}`;
}
/**
* Converts 12-hour time parts to 24-hour total minutes from midnight
*/
function timePartsToTotalMinutes(hour12, minute, period) {
	let h24 = hour12 % 12;
	if (period === "PM") h24 += 12;
	return h24 * 60 + minute;
}
/**
* Validates if time parts fall within daylight operational hours (7:00 AM – 7:00 PM)
*/
function isWithinOperatingHours(hour12, minute, period) {
	const totalMins = timePartsToTotalMinutes(hour12, minute, period);
	return totalMins >= 420 && totalMins <= 1140;
}
/**
* Check if a specific time has already passed for a selected date
*/
function isSpecificTimePassed(hour12, minute, period, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	return timePartsToTotalMinutes(hour12, minute, period) <= now.getHours() * 60 + now.getMinutes();
}
/**
* Checks if an entire hour (all 60 minutes) has passed for today
*/
function isHourEntirelyPassed(hour12, period, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	return timePartsToTotalMinutes(hour12, 59, period) <= now.getHours() * 60 + now.getMinutes();
}
function isTimePassedForDate(timeStr, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	const parsed = parseTimeHoursMinutes(timeStr);
	if (!parsed) return false;
	return now.getHours() * 60 + now.getMinutes() >= parsed.hours * 60 + parsed.minutes;
}
var PRESET_SLOTS = [
	{
		id: "Morning (10:00 AM)",
		label: "10:00 AM (Morning)"
	},
	{
		id: "Afternoon (2:00 PM)",
		label: "02:00 PM (Afternoon)"
	},
	{
		id: "Evening Sunset (4:30 PM)",
		label: "04:30 PM (Evening)"
	}
];
//#endregion
export { isHourEntirelyPassed as a, isWithinOperatingHours as c, splitTimeToHMP as d, subscribeToBookings as f, getLocalDateString as i, parseTimeHoursMinutes as l, syncUpdateUserBooking as m, composeHMPToTime as n, isSpecificTimePassed as o, syncDeleteUserBooking as p, getLocalBookings as r, isTimePassedForDate as s, PRESET_SLOTS as t, saveLocalBooking as u };
