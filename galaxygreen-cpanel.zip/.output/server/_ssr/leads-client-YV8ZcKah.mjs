import { a as deleteInquiryFn, c as getInquiriesFn, d as updateInquiryStatusFn, l as submitInquiryFn, n as adminCreateInquiryFn, p as verifyDealerPinFn, s as getAdminConfigFn, u as updateAdminConfigFn } from "./server-inquiries-BZCzG7ab.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-client-YV8ZcKah.js
var STORAGE_KEY = "galaxy_green_leads_v1";
var PIN_TOKEN_KEY = "gg_dealer_pin_signed_token";
var BASE_RATE_CACHE_KEY = "gg_market_base_rate";
function getClientPinToken() {
	if (typeof window === "undefined") return void 0;
	return localStorage.getItem(PIN_TOKEN_KEY) || void 0;
}
function setClientPinToken(token) {
	if (typeof window === "undefined") return;
	localStorage.setItem(PIN_TOKEN_KEY, token);
}
async function verifyDealerPin(pin) {
	const clientPinToken = getClientPinToken();
	const res = await verifyDealerPinFn({ data: {
		pin,
		clientPinToken
	} });
	const typedRes = res;
	if (typedRes?.success && typedRes?.signedPinToken) setClientPinToken(typedRes.signedPinToken);
	return res;
}
async function fetchAllLeads(token) {
	if (!token) return [];
	let serverLeads = [];
	try {
		const res = await getInquiriesFn({ data: { token } });
		if (Array.isArray(res)) serverLeads = res;
	} catch (err) {
		console.warn("Error fetching leads from server:", err);
	}
	if (typeof window !== "undefined") try {
		const saved = localStorage.getItem(STORAGE_KEY);
		if (saved) {
			const localList = JSON.parse(saved);
			const map = /* @__PURE__ */ new Map();
			for (const item of serverLeads) map.set(item.id, item);
			for (const item of localList) if (!map.has(item.id)) map.set(item.id, item);
			return Array.from(map.values());
		}
	} catch {}
	return serverLeads;
}
async function recordNewInquiry(input) {
	let created = null;
	try {
		const res = await submitInquiryFn({ data: input });
		if (res && typeof res === "object" && "success" in res && !res.success && res.error) throw new Error(res.error);
		if (res?.inquiry) created = res.inquiry;
	} catch (err) {
		if (err instanceof Error && !err.message.includes("fetch") && !err.message.includes("Failed to execute")) throw err;
		console.warn("Server submission fallback:", err);
	}
	if (!created) created = {
		...input,
		id: `GG-2026-${Math.floor(1e3 + Math.random() * 9e3)}`,
		status: "New",
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	if (typeof window !== "undefined") try {
		const saved = localStorage.getItem(STORAGE_KEY);
		const list = saved ? JSON.parse(saved) : [];
		list.unshift(created);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
	} catch {}
	return created;
}
async function updateLeadStatus(id, status, token) {
	const activeToken = token || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") : void 0);
	if (!activeToken) return false;
	try {
		if ((await updateInquiryStatusFn({ data: {
			token: activeToken,
			id,
			status
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const saved = localStorage.getItem(STORAGE_KEY);
				if (saved) {
					const updated = JSON.parse(saved).map((item) => item.id === id ? {
						...item,
						status
					} : item);
					localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
				}
			} catch (err) {}
			return true;
		}
	} catch (err) {
		console.warn("Server status update error:", err);
	}
	return false;
}
function exportLeadsToCsv(leads) {
	const headers = [
		"ID",
		"Name",
		"Phone",
		"Email",
		"Plot Preference",
		"Visit Date",
		"Slot",
		"Status",
		"Created At",
		"Message"
	];
	const rows = leads.map((lead) => [
		lead.id,
		`"${lead.name.replace(/"/g, "\"\"")}"`,
		`"${lead.phone}"`,
		`"${lead.email || ""}"`,
		`"${lead.plotPreference}"`,
		`"${lead.visitDate || ""}"`,
		`"${lead.slot}"`,
		`"${lead.status}"`,
		`"${new Date(lead.createdAt).toLocaleString("en-IN")}"`,
		`"${(lead.message || "").replace(/"/g, "\"\"")}"`
	]);
	const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
	const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.setAttribute("href", url);
	link.setAttribute("download", `Galaxy_Green_Leads_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`);
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
}
async function deleteLead(id, token) {
	const activeToken = token || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") : void 0);
	if (!activeToken) return false;
	try {
		if ((await deleteInquiryFn({ data: {
			token: activeToken,
			id
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const saved = localStorage.getItem(STORAGE_KEY);
				if (saved) {
					const filtered = JSON.parse(saved).filter((item) => item.id !== id);
					localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
				}
			} catch (err) {}
			return true;
		}
	} catch (err) {
		console.warn("Delete inquiry error:", err);
	}
	return false;
}
async function adminAddLead(input, token) {
	const activeToken = token || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") : void 0);
	if (!activeToken) return null;
	try {
		const res = await adminCreateInquiryFn({ data: {
			token: activeToken,
			inquiry: input
		} });
		if (res?.success && res.inquiry) {
			if (typeof window !== "undefined") try {
				const saved = localStorage.getItem(STORAGE_KEY);
				const list = saved ? JSON.parse(saved) : [];
				list.unshift(res.inquiry);
				localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
			} catch (err) {}
			return res.inquiry;
		}
	} catch (err) {
		console.warn("Admin add inquiry error:", err);
	}
	return null;
}
async function fetchMarketBaseRate() {
	try {
		const res = await getAdminConfigFn();
		if (res?.baseRatePerSqFt && !isNaN(res.baseRatePerSqFt)) {
			if (typeof window !== "undefined") localStorage.setItem(BASE_RATE_CACHE_KEY, String(res.baseRatePerSqFt));
			return res.baseRatePerSqFt;
		}
	} catch (err) {
		console.warn("Error fetching base rate from server:", err);
	}
	if (typeof window !== "undefined") {
		const cached = localStorage.getItem(BASE_RATE_CACHE_KEY);
		if (cached) {
			const parsed = parseInt(cached, 10);
			if (!isNaN(parsed) && parsed > 0) return parsed;
		}
	}
	return 1199;
}
async function updateMarketBaseRate(rate, updatePlots = false, token) {
	const activeToken = token || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") : void 0);
	try {
		const res = await updateAdminConfigFn({ data: {
			token: activeToken,
			baseRatePerSqFt: rate,
			updatePlots
		} });
		if (res?.success) {
			const newRate = res.baseRatePerSqFt || rate;
			if (typeof window !== "undefined") {
				localStorage.setItem(BASE_RATE_CACHE_KEY, String(newRate));
				window.dispatchEvent(new CustomEvent("market-rate-updated", { detail: { baseRate: newRate } }));
			}
			return {
				success: true,
				rate: newRate,
				message: res.message
			};
		}
		return {
			success: false,
			message: res?.error || "Failed to update market price."
		};
	} catch (err) {
		return {
			success: false,
			message: err instanceof Error ? err.message : "Error saving market price."
		};
	}
}
//#endregion
export { fetchMarketBaseRate as a, updateLeadStatus as c, fetchAllLeads as i, updateMarketBaseRate as l, deleteLead as n, recordNewInquiry as o, exportLeadsToCsv as r, setClientPinToken as s, adminAddLead as t, verifyDealerPin as u };
