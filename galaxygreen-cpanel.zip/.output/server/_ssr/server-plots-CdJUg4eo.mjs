import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { n as createServerRpc, r as executeQuery, s as verifyAdminToken } from "./auth-token-DZLAq3Jc.mjs";
import { n as plotSchema, t as DEFAULT_PLOTS } from "./plot-types-Dpo7Dr3n.mjs";
import fs from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-plots-CdJUg4eo.js
var memoryPlots = [...DEFAULT_PLOTS];
function trySavePlotsDisk(plots) {
	try {
		fs.writeFileSync("/tmp/galaxy_green_plots.json", JSON.stringify(plots));
	} catch {}
}
function tryLoadPlotsDisk() {
	try {
		if (fs.existsSync("/tmp/galaxy_green_plots.json")) {
			const raw = fs.readFileSync("/tmp/galaxy_green_plots.json", "utf-8");
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed;
		}
	} catch {}
	return null;
}
function mapRowToPlot(row) {
	return {
		id: String(row["id"] || ""),
		number: String(row["number"] || ""),
		sizeSqFt: Number(row["size_sq_ft"]) || 1e3,
		dimensions: String(row["dimensions"] || ""),
		facing: row["facing"] || "East",
		roadWidth: String(row["road_width"] || "30 Ft"),
		ratePerSqFt: Number(row["rate_per_sq_ft"]) || 1199,
		status: row["status"] || "Available",
		feature: String(row["feature"] || "")
	};
}
var getPlotsFn_createServerFn_handler = createServerRpc({
	id: "edbac7c3ae6095459940938f08e64e482be3eee43774392588100cc872807d7b",
	name: "getPlotsFn",
	filename: "src/lib/server-plots.ts"
}, (opts) => getPlotsFn.__executeServer(opts));
var getPlotsFn = createServerFn({ method: "GET" }).handler(getPlotsFn_createServerFn_handler, async () => {
	const rows = await executeQuery("SELECT * FROM plots ORDER BY number ASC");
	if (rows && Array.isArray(rows) && rows.length > 0) {
		const loaded = rows.map(mapRowToPlot);
		memoryPlots = loaded;
		trySavePlotsDisk(loaded);
		return loaded;
	}
	const disk = tryLoadPlotsDisk();
	if (disk) memoryPlots = disk;
	return memoryPlots;
});
var createPlotFn_createServerFn_handler = createServerRpc({
	id: "fd475df625a73983c0c3375d6a7527582026cb8a08676484661b19b79f06298e",
	name: "createPlotFn",
	filename: "src/lib/server-plots.ts"
}, (opts) => createPlotFn.__executeServer(opts));
var createPlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createPlotFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) return {
		success: false,
		error: "Unauthorized: Valid dealer authentication required."
	};
	const newPlot = {
		...plotSchema.parse(data.plot),
		id: `plot-${Date.now()}`
	};
	memoryPlots.push(newPlot);
	trySavePlotsDisk(memoryPlots);
	if (await executeQuery(`INSERT INTO plots (id, number, size_sq_ft, dimensions, facing, road_width, rate_per_sq_ft, status, feature)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
		newPlot.id,
		newPlot.number,
		newPlot.sizeSqFt,
		newPlot.dimensions,
		newPlot.facing,
		newPlot.roadWidth,
		newPlot.ratePerSqFt,
		newPlot.status,
		newPlot.feature
	]) === null) return {
		success: true,
		plot: newPlot,
		note: "Plot added and synchronized to live website."
	};
	return {
		success: true,
		plot: newPlot
	};
});
var updatePlotStatusFn_createServerFn_handler = createServerRpc({
	id: "259c099986c4c7c61bab8947852c80d8fde8680824e76666722a26c4725ea1fd",
	name: "updatePlotStatusFn",
	filename: "src/lib/server-plots.ts"
}, (opts) => updatePlotStatusFn.__executeServer(opts));
var updatePlotStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(updatePlotStatusFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) return {
		success: false,
		error: "Unauthorized: Valid dealer authentication required."
	};
	memoryPlots = memoryPlots.map((p) => p.id === data.id ? {
		...p,
		status: data.status
	} : p);
	trySavePlotsDisk(memoryPlots);
	if (await executeQuery("UPDATE plots SET status = ? WHERE id = ?", [data.status, data.id]) === null) return {
		success: true,
		note: "Plot status updated and synchronized."
	};
	return { success: true };
});
var deletePlotFn_createServerFn_handler = createServerRpc({
	id: "d125ede39de5148edd10518c551ad2202cbab0d643afefdf8b8a497be6188831",
	name: "deletePlotFn",
	filename: "src/lib/server-plots.ts"
}, (opts) => deletePlotFn.__executeServer(opts));
var deletePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(deletePlotFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) return {
		success: false,
		error: "Unauthorized: Valid dealer authentication required."
	};
	memoryPlots = memoryPlots.filter((p) => p.id !== data.id);
	trySavePlotsDisk(memoryPlots);
	if (await executeQuery("DELETE FROM plots WHERE id = ?", [data.id]) === null) return {
		success: true,
		note: "Plot deleted and synchronized."
	};
	return { success: true };
});
var updatePlotFn_createServerFn_handler = createServerRpc({
	id: "0f2f9b5130e556d3703f4e4e0b680d8beadac7e625696b2c98bdb56803ea808a",
	name: "updatePlotFn",
	filename: "src/lib/server-plots.ts"
}, (opts) => updatePlotFn.__executeServer(opts));
var updatePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(updatePlotFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) return {
		success: false,
		error: "Unauthorized: Valid dealer authentication required."
	};
	let current = memoryPlots.find((p) => p.id === data.id);
	if (!current) {
		const rows = await executeQuery("SELECT * FROM plots WHERE id = ? LIMIT 1", [data.id]);
		if (rows && rows.length > 0 && rows[0]) current = mapRowToPlot(rows[0]);
		else {
			const disk = tryLoadPlotsDisk();
			if (disk) {
				const found = disk.find((p) => p.id === data.id);
				if (found) current = found;
			}
		}
	}
	if (!current) return {
		success: false,
		error: "Plot not found in database."
	};
	const updated = {
		...current,
		...data.plot,
		number: data.plot.number ? data.plot.number.toUpperCase().trim() : current.number,
		sizeSqFt: data.plot.sizeSqFt !== void 0 ? Number(data.plot.sizeSqFt) : current.sizeSqFt,
		ratePerSqFt: data.plot.ratePerSqFt !== void 0 ? Number(data.plot.ratePerSqFt) : current.ratePerSqFt
	};
	memoryPlots = memoryPlots.map((p) => p.id === data.id ? updated : p);
	trySavePlotsDisk(memoryPlots);
	const updates = [];
	const params = [];
	if (data.plot.number !== void 0) {
		updates.push("number = ?");
		params.push(updated.number);
	}
	if (data.plot.sizeSqFt !== void 0) {
		updates.push("size_sq_ft = ?");
		params.push(updated.sizeSqFt);
	}
	if (data.plot.dimensions !== void 0) {
		updates.push("dimensions = ?");
		params.push(data.plot.dimensions);
	}
	if (data.plot.facing !== void 0) {
		updates.push("facing = ?");
		params.push(data.plot.facing);
	}
	if (data.plot.roadWidth !== void 0) {
		updates.push("road_width = ?");
		params.push(data.plot.roadWidth);
	}
	if (data.plot.ratePerSqFt !== void 0) {
		updates.push("rate_per_sq_ft = ?");
		params.push(updated.ratePerSqFt);
	}
	if (data.plot.status !== void 0) {
		updates.push("status = ?");
		params.push(data.plot.status);
	}
	if (data.plot.feature !== void 0) {
		updates.push("feature = ?");
		params.push(data.plot.feature);
	}
	if (updates.length > 0) {
		params.push(data.id);
		if (await executeQuery(`UPDATE plots SET ${updates.join(", ")} WHERE id = ?`, params) === null) return {
			success: true,
			plot: updated,
			note: "Plot updated and synchronized to live website."
		};
	}
	return {
		success: true,
		plot: updated,
		message: "Plot details updated and synchronized."
	};
});
//#endregion
export { createPlotFn_createServerFn_handler, deletePlotFn_createServerFn_handler, getPlotsFn_createServerFn_handler, updatePlotFn_createServerFn_handler, updatePlotStatusFn_createServerFn_handler };
