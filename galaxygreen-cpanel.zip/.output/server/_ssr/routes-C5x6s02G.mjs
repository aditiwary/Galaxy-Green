import { o as __toESM } from "../_runtime.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { a as Trigger2, b as require_react, h as Slot, i as Root2, n as Header, r as Item, t as Content2, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-BsX9pigE.mjs";
import { t as inquirySchema } from "./inquiry-types-BhnwrXC3.mjs";
import { t as DEFAULT_PLOTS } from "./plot-types-Dpo7Dr3n.mjs";
import { $ as Car, A as Landmark, B as Database, C as Menu, D as Lock, E as Mail, F as FileCheck, G as CircleX, H as CodeXml, I as Eye, J as CircleAlert, K as CirclePlus, L as EyeOff, M as Image$1, N as HeartPulse, O as Linkedin, P as FileText, Q as Check, R as ExternalLink, S as MessageCircle, T as MapPin, U as CloudUpload, V as Compass, W as Clock, X as ChevronLeft, Y as ChevronRight, Z as ChevronDown, _ as RotateCcw, a as User, at as Award, b as Phone, c as Trees, d as Sparkles, et as Camera, f as SlidersVertical, g as Route, h as Search, i as X, it as BadgePercent, j as KeyRound, k as Layers, l as Trash2, m as ShieldCheck, n as ZoomIn, nt as CalendarCheck, o as TriangleAlert, ot as ArrowRight, p as ShoppingBag, q as CircleCheck, r as Zap, rt as Building2, s as TrendingUp, st as ArrowDown, t as ZoomOut, tt as Calendar, u as TramFront, v as RefreshCw, w as Maximize2, x as Pencil, y as Plane, z as Download } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { i as Trigger, n as List, r as Root2$1, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C5x6s02G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var township_entrance_default = "/assets/township-entrance-CKrNp9yg.jpg";
var luxury_villa_concept_default = "/assets/luxury-villa-concept-BIJPGvq-.jpg";
var lucknow_connectivity_default = "/assets/lucknow-connectivity-B43LUJi1.jpg";
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-xs font-semibold uppercase tracking-[0.09em] cursor-pointer transition-all duration-250 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed select-none [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "btn-luxury btn-shimmer bg-primary text-primary-foreground shadow-glow hover:bg-primary/95",
			luxury: "btn-luxury btn-shimmer bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-slate-950 font-bold shadow-gold hover:brightness-105",
			destructive: "btn-luxury bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "btn-luxury-outline border border-border text-foreground hover:border-primary/60",
			secondary: "btn-luxury-outline bg-secondary/80 text-secondary-foreground shadow-sm hover:bg-secondary",
			ghost: "transition-all duration-200 hover:bg-surface/90 hover:text-primary text-foreground/90",
			link: "text-primary underline-offset-4 hover:underline normal-case tracking-normal text-sm"
		},
		size: {
			default: "h-10 px-5 py-2",
			sm: "h-8 px-3.5 text-[11px]",
			lg: "h-12 px-7",
			xl: "h-14 px-8 text-xs font-bold tracking-widest",
			icon: "h-10 w-10 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getPlotsFn = createServerFn({ method: "GET" }).handler(createSsrRpc("edbac7c3ae6095459940938f08e64e482be3eee43774392588100cc872807d7b"));
var createPlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("fd475df625a73983c0c3375d6a7527582026cb8a08676484661b19b79f06298e"));
var updatePlotStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("259c099986c4c7c61bab8947852c80d8fde8680824e76666722a26c4725ea1fd"));
var deletePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("d125ede39de5148edd10518c551ad2202cbab0d643afefdf8b8a497be6188831"));
var updatePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("0f2f9b5130e556d3703f4e4e0b680d8beadac7e625696b2c98bdb56803ea808a"));
var PLOTS_STORAGE_KEY = "galaxy_green_plots_v1";
async function fetchLivePlots() {
	try {
		const serverPlots = await getPlotsFn();
		if (Array.isArray(serverPlots) && serverPlots.length > 0) {
			if (typeof window !== "undefined") localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(serverPlots));
			return serverPlots;
		}
	} catch (err) {
		console.warn("Using local storage fallback for plots:", err);
	}
	if (typeof window !== "undefined") {
		const saved = localStorage.getItem(PLOTS_STORAGE_KEY);
		if (saved) try {
			return JSON.parse(saved);
		} catch {}
		localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(DEFAULT_PLOTS));
	}
	return DEFAULT_PLOTS;
}
function getClientToken$1(token) {
	if (token) return token;
	if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || void 0;
}
async function addLivePlot(input, token) {
	const activeToken = getClientToken$1(token);
	try {
		const res = await createPlotFn({ data: {
			plot: input,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.plot) {
			if (typeof window !== "undefined") try {
				const updated = [...(await fetchLivePlots()).filter((p) => p.id !== res.plot.id), res.plot];
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return res.plot;
		}
		if (res?.error) console.error("Failed to add plot to database:", res.error);
	} catch (err) {
		console.error("Server add plot error:", err);
	}
	return null;
}
async function setPlotStatus(id, status, token) {
	const activeToken = getClientToken$1(token);
	try {
		if ((await updatePlotStatusFn({ data: {
			id,
			status,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLivePlots()).map((p) => p.id === id ? {
					...p,
					status
				} : p);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server plot status update error:", err);
	}
	return false;
}
async function removePlot(id, token) {
	const activeToken = getClientToken$1(token);
	try {
		if ((await deletePlotFn({ data: {
			id,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLivePlots()).filter((p) => p.id !== id);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server plot deletion error:", err);
	}
	return false;
}
async function updateLivePlot(id, plotUpdates, token) {
	const activeToken = getClientToken$1(token);
	try {
		const res = await updatePlotFn({ data: {
			id,
			plot: plotUpdates,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.plot) {
			if (typeof window !== "undefined") try {
				const updatedList = (await fetchLivePlots()).map((p) => p.id === id ? res.plot : p);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updatedList));
			} catch {}
			return res.plot;
		}
	} catch (err) {
		console.error("Server plot update error:", err);
	}
	return null;
}
function MasterPlanViewer({ onSelectPlotForBooking }) {
	const [plots, setPlots] = (0, import_react.useState)([]);
	const [selectedSizeFilter, setSelectedSizeFilter] = (0, import_react.useState)("all");
	const [activePlot, setActivePlot] = (0, import_react.useState)(null);
	const loadPlots = async () => {
		try {
			const data = await fetchLivePlots();
			setPlots(data);
		} catch (err) {
			console.error("Error loading plots:", err);
		}
	};
	(0, import_react.useEffect)(() => {
		loadPlots();
		const handleUpdate = () => loadPlots();
		window.addEventListener("plots-updated", handleUpdate);
		return () => window.removeEventListener("plots-updated", handleUpdate);
	}, []);
	const filteredPlots = plots.filter((p) => {
		if (selectedSizeFilter === "all") return true;
		if (selectedSizeFilter === "1000") return p.sizeSqFt === 1e3;
		if (selectedSizeFilter === "1500") return p.sizeSqFt >= 1200 && p.sizeSqFt <= 1500;
		if (selectedSizeFilter === "2000+") return p.sizeSqFt >= 2e3;
		if (selectedSizeFilter === "corner") return p.facing === "Boulevard Corner";
		return true;
	});
	const formatINR = (val) => new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(val);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "masterplan",
		className: "section-shell bg-background border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "02 · Township Master Plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "section-title",
							children: "Interactive Plot Matrix & Layout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base text-muted-foreground leading-relaxed",
							children: "Explore demarcated freehold residential plots in Phase 1. Each parcel features direct wide-road access, underground electrification conduits, and instant registry eligibility."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 bg-primary/10 border border-primary/30 px-3.5 py-2 rounded text-xs text-primary font-mono",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phase 1: 72% Sold Out" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex flex-wrap gap-2 pb-2 border-b border-border/50",
					children: [
						{
							id: "all",
							label: "All Available Plots"
						},
						{
							id: "1000",
							label: "1,000 Sq Ft (₹11.99 Lakh)"
						},
						{
							id: "1500",
							label: "1,200 - 1,500 Sq Ft"
						},
						{
							id: "2000+",
							label: "2,000+ Sq Ft (Grand Villa)"
						},
						{
							id: "corner",
							label: "Boulevard & Corner Plots"
						}
					].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSelectedSizeFilter(tab.id),
						className: `px-4 py-2 text-xs uppercase tracking-wider rounded transition-all font-medium ${selectedSizeFilter === tab.id ? "bg-primary text-primary-foreground font-semibold shadow-glow" : "bg-surface/80 text-muted-foreground hover:text-foreground hover:bg-surface border border-border"}`,
						children: tab.label
					}, tab.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: filteredPlots.map((plot) => {
						const totalPrice = plot.sizeSqFt * plot.ratePerSqFt;
						Math.round(totalPrice * .1);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							onClick: () => setActivePlot(plot),
							className: `card-architectural group p-6 rounded-xl relative overflow-hidden cursor-pointer ${plot.status === "Reserved" ? "opacity-75" : plot.status === "Fast Selling" ? "border-accent/60 bg-gradient-to-b from-accent/5 to-card" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs uppercase tracking-widest text-primary font-bold",
										children: ["Plot ", plot.number]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: `text-[10px] uppercase font-semibold tracking-wider ${plot.status === "Available" ? "border-primary/50 text-primary bg-primary/10" : plot.status === "Fast Selling" ? "border-accent text-accent bg-accent/15" : "border-muted text-muted-foreground bg-muted/20"}`,
										children: plot.status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-3xl font-display font-semibold text-foreground tracking-tight",
											children: plot.sizeSqFt.toLocaleString()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs uppercase text-muted-foreground font-mono",
											children: "Sq Ft"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground font-mono mt-0.5",
										children: ["Dim: ", plot.dimensions]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-4 h-px bg-border/60" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Orientation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-foreground flex items-center gap-1 font-medium",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3 text-primary" }),
													" ",
													plot.facing
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Road Access" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground font-medium",
												children: plot.roadWidth
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Base Rate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-primary font-medium",
												children: [
													"₹",
													plot.ratePerSqFt,
													" / sq ft"
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 pt-3 border-t border-border/80 flex items-end justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Estimated Value"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-lg font-display text-primary",
										children: formatINR(totalPrice)
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-primary flex items-center gap-1 font-medium group-hover:translate-x-0.5 transition-transform",
										children: ["Inspect ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
									})]
								})
							]
						}, plot.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
					open: !!activePlot,
					onOpenChange: (open) => !open && setActivePlot(null),
					children: activePlot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-w-xl bg-card border-border text-foreground p-6 sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "border-primary text-primary bg-primary/10",
										children: "Phase 1 Verified"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground font-mono",
										children: "Freehold Title · Ready For Registry"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
									className: "text-2xl font-display uppercase tracking-tight text-foreground mt-2",
									children: [
										"Plot ",
										activePlot.number,
										" · ",
										activePlot.sizeSqFt.toLocaleString(),
										" Sq Ft"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
									className: "text-sm text-muted-foreground",
									children: activePlot.feature
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3 my-5 p-4 rounded bg-surface/90 border border-border/60 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Dimensions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground text-sm font-medium",
										children: activePlot.dimensions
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Facing Direction"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-foreground text-sm font-medium flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3.5 text-primary" }),
											" ",
											activePlot.facing
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Frontage Road"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground text-sm font-medium",
										children: activePlot.roadWidth
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Booking Token (10%)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-accent text-sm font-medium",
										children: formatINR(Math.round(activePlot.sizeSqFt * activePlot.ratePerSqFt * .1))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2 pt-2 border-t border-border/40 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Total Plot Consideration:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-xl font-display text-primary",
											children: formatINR(activePlot.sizeSqFt * activePlot.ratePerSqFt)
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-xs text-muted-foreground bg-background/50 p-3 rounded border border-border/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Immediate registry and mutation (Dakhil Kharij) documentation ready" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bank loan pre-approved up to 80% with SBI, HDFC & PNB" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Demarcated boundary pillars installed on ground" })]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row items-center gap-3 mt-4 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "w-full sm:flex-1 h-12 uppercase tracking-wider text-xs bg-primary text-primary-foreground font-semibold hover:bg-primary/90 btn-shimmer",
									onClick: () => {
										const num = activePlot.number;
										const sz = `${activePlot.sizeSqFt} sq ft`;
										setActivePlot(null);
										onSelectPlotForBooking(num, sz);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 mr-2" }), " Book This Plot Now"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "w-full sm:w-auto h-12 uppercase tracking-wider text-xs border-border hover:bg-surface",
									onClick: () => setActivePlot(null),
									children: "Close"
								})]
							})
						]
					})
				})
			]
		})
	});
}
var DEFAULT_GALLERY_PHOTOS = [
	{
		id: "site-photo-1",
		src: "/site-photos/galaxy-green-actual-site-1.jpg",
		title: "Ground Demarcation & Boundary Pillars",
		category: "demarcation",
		categoryLabel: "Demarcation & Registry Ready",
		tag: "Phase 1 Demarcation",
		dimensionsLabel: "Min 600 sq ft to Custom Requirements",
		description: "Clear on-ground plot boundaries with reinforced stone pillars and concrete edging. Plots start from compact 600 sq ft up to large custom footprints.",
		highlights: [
			"Physical boundary curbing & corner pillars installed",
			"Immediate registry & mutation (Dakhil Kharij) ready",
			"Customizable plot dimensions starting from 600 sq ft",
			"Direct frontage onto wide 30ft internal access roads"
		]
	},
	{
		id: "site-photo-2",
		src: "/site-photos/galaxy-green-actual-site-2.jpg",
		title: "Wide 30-Ft Internal Road & Sunset Streetlighting",
		category: "roads",
		categoryLabel: "Internal Roads & Lighting",
		tag: "30-Ft Road Infrastructure",
		dimensionsLabel: "30-Ft Wide Internal Avenue",
		description: "Wide, leveled internal township road network illuminated by active street lighting poles with utility pathways.",
		highlights: [
			"30-ft wide internal avenue for smooth two-way driving",
			"Functional electric poles and evening streetlights active",
			"Direct connectivity to Kanpur-Lucknow Expressway (3 km)",
			"Unobstructed access for construction materials and private vehicles"
		]
	},
	{
		id: "site-photo-3",
		src: "/site-photos/galaxy-green-actual-site-3.jpg",
		title: "Elevated Township Panorama & Surrounding Greenery",
		category: "panorama",
		categoryLabel: "Township Horizon",
		tag: "Open Green Environs",
		dimensionsLabel: "Pollution-Free Eco Zone",
		description: "Panoramic elevated perspective of Sai Suraksha Nagar showing peaceful residential surroundings and overhead water infrastructure.",
		highlights: [
			"Overhead water reservoir ensuring reliable high-pressure water supply",
			"Clean, green environment away from city congestion",
			"Close proximity to Amausi Railway Station (2.7 km) & Market (2.5 km)",
			"Vastu-compliant residential zoning with open morning sunlight"
		]
	},
	{
		id: "site-photo-4",
		src: "/site-photos/galaxy-green-actual-site-4.jpg",
		title: "Main Access Boulevard & Plot Inventory Grid",
		category: "roads",
		categoryLabel: "Boulevard & Demarcations",
		tag: "Central Layout View",
		dimensionsLabel: "Allotment Starting ₹7.19 Lakh",
		description: "Central access road traversing the plotted layout with clearly lined plot parcels ready for boundary walling.",
		highlights: [
			"Transparent Phase 1 allotment at ₹1,199 / sq ft",
			"Compact 600 sq ft villas start at only ₹7.19 Lakh",
			"Wide turning radiuses suitable for SUVs and delivery trucks",
			"Independent housing cluster already developing rapidly on site"
		]
	},
	{
		id: "site-photo-5",
		src: "/site-photos/galaxy-green-actual-site-5.jpg",
		title: "Underground Utility Lines & Soil Leveling Progress",
		category: "construction",
		categoryLabel: "Civil Engineering",
		tag: "Ground Work Active",
		dimensionsLabel: "Phase 1 Fast-Track Delivery",
		description: "Active compaction and leveling machinery preparing future residential sectors with pre-laid drainage conduits.",
		highlights: [
			"Real residential buildings under active brick and pillar construction",
			"Immediate possession allows buyers to begin construction right away",
			"Only 3 km from T.S. Mishra Medical College & Hospital",
			"5 km from CCS International Airport & Amausi Metro Station"
		]
	},
	{
		id: "site-photo-6",
		src: "/site-photos/galaxy-green-airport-connectivity.jpg",
		title: "Chaudhary Charan Singh International Airport & Amausi Plots",
		category: "panorama",
		categoryLabel: "Airport & Metro Connectivity",
		tag: "Prime Airport Vicinity",
		dimensionsLabel: "5 Km from CCS International Airport",
		description: "Strategic aerial master photograph showing Chaudhary Charan Singh International Airport (Terminal 1 & 2, Runway 09/27), Kanpur Road (NH27), Amausi Metro Station, and the immediate proximity of Amausi available plots at Galaxy Green Sai Suraksha Nagar.",
		highlights: [
			"Direct proximity to CCS International Airport (LKO) & Terminals 1 & 2",
			"Immediate access to Kanpur Road (NH27) & Amausi Metro Station",
			"Rapidly appreciating high-capital growth corridor",
			"Direct expressway arterial connectivity across Lucknow & NCR"
		]
	}
];
var getGalleryPhotosFn = createServerFn({ method: "GET" }).handler(createSsrRpc("8c710ba4c68dd2ed572581dc584f419650b9e0a6aa6f12e5d0c6347969b95968"));
var uploadGalleryPhotoFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("9d6b73876cd40b51a52c7ab36aa575bd58faa97bae203d0ffe1f8d16caf4ad01"));
var deleteGalleryPhotoFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e1c9dfbebb211bc04aae75249b29da3d4165d897aeceaad3c8d64a443253e4fd"));
var PHOTOS_STORAGE_KEY = "galaxy_green_photos_v1";
async function fetchLiveGalleryPhotos() {
	try {
		const serverPhotos = await getGalleryPhotosFn();
		if (Array.isArray(serverPhotos) && serverPhotos.length > 0) {
			if (typeof window !== "undefined") localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(serverPhotos));
			return serverPhotos;
		}
	} catch (err) {
		console.warn("Using local storage fallback for photos:", err);
	}
	if (typeof window !== "undefined") {
		const saved = localStorage.getItem(PHOTOS_STORAGE_KEY);
		if (saved) try {
			return JSON.parse(saved);
		} catch {}
		localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(DEFAULT_GALLERY_PHOTOS));
	}
	return DEFAULT_GALLERY_PHOTOS;
}
function getClientToken(token) {
	if (token) return token;
	if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || void 0;
}
async function uploadLivePhoto(photoInput, token) {
	const activeToken = getClientToken(token);
	try {
		const res = await uploadGalleryPhotoFn({ data: {
			photo: photoInput,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.photo) {
			if (typeof window !== "undefined") try {
				const current = await fetchLiveGalleryPhotos();
				const updated = [res.photo, ...current.filter((p) => p.id !== res.photo.id)];
				localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(updated));
				window.dispatchEvent(new CustomEvent("gallery-updated"));
			} catch {}
			return res.photo;
		}
		if (res?.error) console.error("Failed to upload photo to database:", res.error);
	} catch (err) {
		console.error("Server photo upload error:", err);
	}
	return null;
}
async function removeLivePhoto(id, token) {
	const activeToken = getClientToken(token);
	try {
		if ((await deleteGalleryPhotoFn({ data: {
			id,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLiveGalleryPhotos()).filter((p) => p.id !== id);
				localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(updated));
				window.dispatchEvent(new CustomEvent("gallery-updated"));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server photo deletion error:", err);
	}
	return false;
}
var DEFAULT_SITE_PHOTOS = [
	{
		id: "site-photo-1",
		src: "/site-photos/galaxy-green-actual-site-1.jpg",
		title: "Ground Demarcation & Boundary Pillars",
		category: "demarcation",
		categoryLabel: "Demarcation & Registry Ready",
		tag: "Phase 1 Demarcation",
		dimensionsLabel: "Min 600 sq ft to Custom Requirements",
		description: "Clear on-ground plot boundaries with reinforced stone pillars and concrete edging. Plots start from compact 600 sq ft up to large custom residential and commercial footprints as per buyer preference.",
		highlights: [
			"Physical boundary curbing & corner pillars installed",
			"Immediate registry & mutation (Dakhil Kharij) ready",
			"Customizable plot dimensions starting from 600 sq ft",
			"Direct frontage onto wide 30ft internal access roads"
		]
	},
	{
		id: "site-photo-2",
		src: "/site-photos/galaxy-green-actual-site-2.jpg",
		title: "Wide 30-Ft Internal Road & Sunset Streetlighting",
		category: "roads",
		categoryLabel: "Internal Roads & Lighting",
		tag: "30-Ft Road Infrastructure",
		dimensionsLabel: "30-Ft Wide Internal Avenue",
		description: "Wide, leveled internal township road network illuminated by active street lighting poles. Provides comfortable two-way vehicular transit with dedicated drainage conduits and utility pathways.",
		highlights: [
			"30-ft wide internal avenue for smooth two-way driving",
			"Functional electric poles and evening streetlights active",
			"Direct connectivity to Kanpur-Lucknow Expressway (3 km)",
			"Unobstructed access for construction materials and private vehicles"
		]
	},
	{
		id: "site-photo-3",
		src: "/site-photos/galaxy-green-actual-site-3.jpg",
		title: "Elevated Township Panorama & Surrounding Greenery",
		category: "panorama",
		categoryLabel: "Township Horizon",
		tag: "Open Green Environs",
		dimensionsLabel: "Pollution-Free Eco Zone",
		description: "Panoramic elevated perspective of Sai Suraksha Nagar showing peaceful residential surroundings, lush tree lines, elevated water supply infrastructure, and serene open horizons near Amausi.",
		highlights: [
			"Overhead water reservoir ensuring reliable high-pressure water supply",
			"Clean, green environment away from city congestion",
			"Close proximity to Amausi Railway Station (2.7 km) & Market (2.5 km)",
			"Vastu-compliant residential zoning with open morning sunlight"
		]
	},
	{
		id: "site-photo-4",
		src: "/site-photos/galaxy-green-actual-site-4.jpg",
		title: "Main Access Boulevard & Plot Inventory Grid",
		category: "roads",
		categoryLabel: "Boulevard & Demarcations",
		tag: "Central Layout View",
		dimensionsLabel: "Allotment Starting ₹7.19 Lakh",
		description: "Central access road traversing the plotted layout with clearly lined plot parcels ready for boundary walling. Several independent residential homes are already actively being constructed in this sector.",
		highlights: [
			"Transparent Phase 1 allotment at ₹1,199 / sq ft",
			"Compact 600 sq ft villas start at only ₹7.19 Lakh",
			"Wide turning radiuses suitable for SUVs and delivery trucks",
			"Independent housing cluster already developing rapidly on site"
		]
	},
	{
		id: "site-photo-5",
		src: "/site-photos/galaxy-green-actual-site-5.jpg",
		title: "Active Residential Construction & Plot Edging",
		category: "construction",
		categoryLabel: "Active Construction",
		tag: "Ground Reality",
		dimensionsLabel: "Fast-Paced Site Progress",
		description: "Top-angle view displaying finished concrete boundary curbs on vacant plots alongside multi-storey brick masonry construction underway. Demonstrates authentic livability and rapid on-site pace.",
		highlights: [
			"Real residential buildings under active brick and pillar construction",
			"Immediate possession allows buyers to begin construction right away",
			"Only 3 km from T.S. Mishra Medical College & Hospital",
			"5 km from CCS International Airport & Amausi Metro Station"
		]
	},
	{
		id: "site-photo-6",
		src: "/site-photos/galaxy-green-airport-connectivity.jpg",
		title: "Chaudhary Charan Singh International Airport & Amausi Plots",
		category: "panorama",
		categoryLabel: "Airport & Metro Connectivity",
		tag: "Prime Airport Vicinity",
		dimensionsLabel: "5 Km from CCS International Airport",
		description: "Strategic aerial master photograph showing Chaudhary Charan Singh International Airport (Terminal 1 & 2, Runway 09/27), Kanpur Road (NH27), Amausi Metro Station, and the immediate proximity of Amausi available plots at Galaxy Green Sai Suraksha Nagar.",
		highlights: [
			"Direct proximity to CCS International Airport (LKO) & Terminals 1 & 2",
			"Immediate access to Kanpur Road (NH27) & Amausi Metro Station",
			"Rapidly appreciating high-capital growth corridor",
			"Direct expressway arterial connectivity across Lucknow & NCR"
		]
	}
];
function ActualSiteGallery({ onScheduleVisit }) {
	const [activeTab, setActiveTab] = (0, import_react.useState)("all");
	const [lightboxIndex, setLightboxIndex] = (0, import_react.useState)(null);
	const [photos, setPhotos] = (0, import_react.useState)(DEFAULT_SITE_PHOTOS);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		const loadPhotos = async () => {
			try {
				const live = await fetchLiveGalleryPhotos();
				if (isMounted && live && live.length > 0) {
					const enriched = live.map((photo) => {
						const defaultMatch = DEFAULT_SITE_PHOTOS.find((d) => d.id === photo.id || d.title.toLowerCase() === photo.title.toLowerCase());
						return {
							id: photo.id,
							src: photo.src,
							title: photo.title,
							category: photo.category,
							categoryLabel: photo.categoryLabel || defaultMatch?.categoryLabel || "Actual Site",
							tag: photo.tag || defaultMatch?.tag || "Live Update",
							dimensionsLabel: photo.dimensionsLabel || defaultMatch?.dimensionsLabel || "On-Ground Progress",
							description: photo.description || defaultMatch?.description || "Authentic on-site photograph of Galaxy Green township in Lucknow.",
							highlights: photo.highlights && photo.highlights.length > 0 ? photo.highlights : defaultMatch?.highlights || [
								"Physical boundary curbs & pillars installed",
								"Immediate registry & mutation (Dakhil Kharij) ready",
								"Direct frontage onto wide 30ft internal roads"
							]
						};
					});
					setPhotos(enriched);
				}
			} catch (err) {
				console.warn("Failed to load live gallery photos:", err);
			}
		};
		loadPhotos();
		const handleUpdate = () => {
			loadPhotos();
		};
		window.addEventListener("gallery-updated", handleUpdate);
		return () => {
			isMounted = false;
			window.removeEventListener("gallery-updated", handleUpdate);
		};
	}, []);
	const filteredPhotos = activeTab === "all" ? photos : photos.filter((photo) => photo.category === activeTab);
	const [galleryZoom, setGalleryZoom] = (0, import_react.useState)(1);
	const [galleryPan, setGalleryPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [isGalleryDragging, setIsGalleryDragging] = (0, import_react.useState)(false);
	const galleryDragStartRef = (0, import_react.useRef)(null);
	const resetGalleryView = (0, import_react.useCallback)(() => {
		setGalleryZoom(1);
		setGalleryPan({
			x: 0,
			y: 0
		});
	}, []);
	const openLightbox = (index) => {
		if (index >= 0 && index < filteredPhotos.length) {
			resetGalleryView();
			setLightboxIndex(index);
		}
	};
	const closeLightbox = (0, import_react.useCallback)(() => {
		resetGalleryView();
		setLightboxIndex(null);
	}, [resetGalleryView]);
	const nextPhoto = (0, import_react.useCallback)(() => {
		if (lightboxIndex === null || filteredPhotos.length === 0) return;
		resetGalleryView();
		setLightboxIndex((prev) => prev === null ? null : (prev + 1) % filteredPhotos.length);
	}, [
		lightboxIndex,
		filteredPhotos.length,
		resetGalleryView
	]);
	const prevPhoto = (0, import_react.useCallback)(() => {
		if (lightboxIndex === null || filteredPhotos.length === 0) return;
		resetGalleryView();
		setLightboxIndex((prev) => prev === null ? null : (prev - 1 + filteredPhotos.length) % filteredPhotos.length);
	}, [
		lightboxIndex,
		filteredPhotos.length,
		resetGalleryView
	]);
	(0, import_react.useEffect)(() => {
		if (lightboxIndex !== null) {
			const originalOverflow = document.body.style.overflow;
			document.body.style.overflow = "hidden";
			return () => {
				document.body.style.overflow = originalOverflow;
			};
		}
	}, [lightboxIndex]);
	const handleGalleryPointerDown = (e) => {
		if (galleryZoom <= 1) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		setIsGalleryDragging(true);
		galleryDragStartRef.current = {
			startX: e.clientX,
			startY: e.clientY,
			initialPanX: galleryPan.x,
			initialPanY: galleryPan.y
		};
	};
	const handleGalleryPointerMove = (e) => {
		if (!isGalleryDragging || !galleryDragStartRef.current) return;
		const deltaX = e.clientX - galleryDragStartRef.current.startX;
		const deltaY = e.clientY - galleryDragStartRef.current.startY;
		setGalleryPan({
			x: galleryDragStartRef.current.initialPanX + deltaX,
			y: galleryDragStartRef.current.initialPanY + deltaY
		});
	};
	const handleGalleryPointerUp = (e) => {
		if (isGalleryDragging) {
			setIsGalleryDragging(false);
			galleryDragStartRef.current = null;
			try {
				e.currentTarget.releasePointerCapture(e.pointerId);
			} catch {}
		}
	};
	const handleGalleryWheel = (e) => {
		e.preventDefault();
		const delta = e.deltaY > 0 ? -.25 : .25;
		setGalleryZoom((prev) => {
			const next = Math.min(3.5, Math.max(.75, Number((prev + delta).toFixed(2))));
			if (next <= 1) setGalleryPan({
				x: 0,
				y: 0
			});
			return next;
		});
	};
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if (lightboxIndex === null) return;
			if (e.key === "Escape") closeLightbox();
			if (e.key === "ArrowRight") nextPhoto();
			if (e.key === "ArrowLeft") prevPhoto();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		lightboxIndex,
		nextPhoto,
		prevPhoto,
		closeLightbox
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "site-gallery",
		className: "section-shell bg-background border-b border-border relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow",
								children: "05 · Ground Reality & Live Progress"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Live On-Site Photographs"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "section-title",
							children: "Actual Site Progress & Infrastructure"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-3xl text-sm md:text-base text-muted-foreground leading-relaxed",
							children: [
								"We present 100% genuine on-ground photographs of",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "Galaxy Green Sai Suraksha Nagar"
								}),
								" in Amausi, Lucknow. Witness clear boundary demarcation, 30-ft wide roads, operational streetlights, and ongoing residential constructions."
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 bg-surface/80 border border-border p-3.5 rounded-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pr-4 border-r border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-mono text-muted-foreground block",
									children: "Rate Per Sq Ft"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-xl font-display text-primary",
									children: "₹1,199"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pr-4 border-r border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-mono text-muted-foreground block",
									children: "Plot Sizing"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-sm font-display text-foreground",
									children: "600 Sq Ft to Custom"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase font-mono text-muted-foreground block",
								children: "Registry & Possession"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-xs font-mono text-emerald-400 font-semibold",
								children: "Immediate (Dakhil Kharij)"
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-wrap items-center gap-2 border-b border-border/80 pb-4",
					children: [
						{
							id: "all",
							label: "All Site Photos"
						},
						{
							id: "demarcation",
							label: "Plot Demarcation (600+ sq ft)"
						},
						{
							id: "roads",
							label: "30-Ft Roads & Streetlights"
						},
						{
							id: "construction",
							label: "Houses Under Construction"
						},
						{
							id: "panorama",
							label: "Township & Airport Connectivity"
						}
					].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setActiveTab(tab.id);
							setLightboxIndex(null);
						},
						className: `px-3.5 py-1.5 rounded-full text-xs font-mono transition-all ${activeTab === tab.id ? "bg-primary text-primary-foreground font-semibold shadow-glow" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border/60"}`,
						children: tab.label
					}, tab.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch",
					children: [
						filteredPhotos[0] && (() => {
							const hero = filteredPhotos[0];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-8 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[380px] lg:min-h-[440px]",
								onClick: () => openLightbox(0),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: hero.src,
										alt: hero.title,
										className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-md text-[11px] font-mono font-semibold bg-background/80 backdrop-blur-md text-primary border border-primary/30 shadow",
											children: hero.tag
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-9 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors shadow",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative p-6 sm:p-8 space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-xs font-mono text-primary",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hero.categoryLabel }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: hero.dimensionsLabel
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-xl sm:text-2xl font-semibold text-foreground group-hover:text-primary transition-colors",
												children: hero.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm text-muted-foreground line-clamp-2 max-w-2xl",
												children: hero.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 flex flex-wrap items-center gap-4 text-xs font-mono text-foreground/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-emerald-400" }), "Boundary Curbs Laid"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-emerald-400" }), "₹1,199 / Sq Ft Fixed Rate"]
												})]
											})
										]
									})
								]
							});
						})(),
						filteredPhotos[1] && (() => {
							const sec = filteredPhotos[1];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-4 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[320px] md:min-h-auto",
								onClick: () => openLightbox(1),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: sec.src,
										alt: sec.title,
										className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-2.5 py-0.5 rounded text-[10px] font-mono font-medium bg-background/80 backdrop-blur-md text-accent border border-accent/30",
											children: sec.tag
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-8 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative p-5 space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-mono text-primary uppercase block",
												children: sec.categoryLabel
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "font-display text-base font-semibold text-foreground group-hover:text-primary transition-colors",
												children: sec.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground line-clamp-2",
												children: sec.description
											})
										]
									})
								]
							});
						})(),
						filteredPhotos.slice(2).map((photo, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-4 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[260px]",
							onClick: () => openLightbox(idx + 2),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: photo.src,
									alt: photo.title,
									className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between pointer-events-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-2 py-0.5 rounded text-[10px] font-mono bg-background/80 backdrop-blur-md text-foreground border border-border",
										children: photo.tag
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-7 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative p-4 space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono text-primary uppercase block",
											children: photo.categoryLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-display text-sm font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1",
											children: photo.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground line-clamp-2",
											children: photo.description
										})
									]
								})
							]
						}, photo.id))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 p-5 sm:p-6 rounded-xl bg-surface border border-border flex flex-col sm:flex-row items-center justify-between gap-4 shadow-luxury",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "icon-monogram size-12 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-sm font-display text-foreground uppercase block",
							children: "Inspect These Plots In Person"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Our sales team walks you through demarcated boundary stones and shows registry documents on-site."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3 w-full sm:w-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => onScheduleVisit("On-Ground Demarcated Plot"),
							className: "w-full sm:w-auto h-11 px-6 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
							children: ["Book Personal Site Inspection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 ml-2" })]
						})
					})]
				})
			]
		}), lightboxIndex !== null && filteredPhotos[lightboxIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex flex-col justify-between p-3 sm:p-6 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] animate-in fade-in duration-200",
			role: "dialog",
			"aria-modal": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border/80 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "font-mono text-xs border-primary/40 text-primary",
							children: [
								"Photo ",
								lightboxIndex + 1,
								" of ",
								filteredPhotos.length
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-mono text-muted-foreground hidden sm:inline",
							children: filteredPhotos[lightboxIndex].categoryLabel
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 bg-surface border border-border rounded-lg p-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: () => setGalleryZoom((prev) => {
											const next = Math.max(.75, Number((prev - .25).toFixed(2)));
											if (next <= 1) setGalleryPan({
												x: 0,
												y: 0
											});
											return next;
										}),
										disabled: galleryZoom <= .75,
										className: "size-7 sm:size-8 text-foreground hover:bg-background",
										title: "Zoom Out",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-3.5 sm:size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-mono font-semibold px-1 min-w-[2.8rem] text-center",
										children: [Math.round(galleryZoom * 100), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: () => setGalleryZoom((prev) => Math.min(3.5, Number((prev + .25).toFixed(2)))),
										disabled: galleryZoom >= 3.5,
										className: "size-7 sm:size-8 text-foreground hover:bg-background",
										title: "Zoom In",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-3.5 sm:size-4" })
									}),
									(galleryZoom !== 1 || galleryPan.x !== 0 || galleryPan.y !== 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: resetGalleryView,
										className: "size-7 sm:size-8 text-muted-foreground hover:text-foreground hover:bg-background",
										title: "Reset View",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => {
									const p = filteredPhotos[lightboxIndex];
									if (p) {
										closeLightbox();
										onScheduleVisit(`${p.title} (${p.dimensionsLabel || "On-Site"})`);
									}
								},
								className: "h-8 px-3 uppercase text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 hidden sm:inline-flex",
								children: ["Inquire This Plot ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1.5" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: closeLightbox,
								className: "size-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 flex items-center justify-center my-2 sm:my-3 overflow-hidden rounded-xl border border-border/80 bg-black/70 p-2 sm:p-4 select-none touch-none",
					onPointerDown: handleGalleryPointerDown,
					onPointerMove: handleGalleryPointerMove,
					onPointerUp: handleGalleryPointerUp,
					onPointerCancel: handleGalleryPointerUp,
					onWheel: handleGalleryWheel,
					onDoubleClick: () => {
						if (galleryZoom > 1) resetGalleryView();
						else setGalleryZoom(2);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								prevPhoto();
							},
							className: "absolute left-2 sm:left-4 z-20 size-10 sm:size-12 rounded-full bg-background/85 hover:bg-background border border-border text-foreground flex items-center justify-center transition-transform hover:scale-110 active:scale-95 shadow-lg",
							"aria-label": "Previous photograph",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 sm:size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "origin-center transition-transform select-none",
							style: {
								transform: `translate3d(${galleryPan.x}px, ${galleryPan.y}px, 0) scale(${galleryZoom})`,
								transitionDuration: isGalleryDragging ? "0ms" : "200ms",
								cursor: galleryZoom > 1 ? isGalleryDragging ? "grabbing" : "grab" : "zoom-in"
							},
							title: galleryZoom > 1 ? "Drag to pan · Double-click to reset · Scroll to zoom" : "Click zoom controls, double-click, or use wheel/trackpad to zoom",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: filteredPhotos[lightboxIndex].src,
								alt: filteredPhotos[lightboxIndex].title,
								className: "max-h-[72vh] max-h-[72dvh] w-auto max-w-full object-contain rounded-lg shadow-2xl pointer-events-none select-none",
								draggable: false
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								nextPhoto();
							},
							className: "absolute right-2 sm:right-4 z-20 size-10 sm:size-12 rounded-full bg-background/85 hover:bg-background border border-border text-foreground flex items-center justify-center transition-transform hover:scale-110 active:scale-95 shadow-lg",
							"aria-label": "Next photograph",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 sm:size-6" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border/80 pt-3 max-w-5xl mx-auto w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-base sm:text-xl font-display font-semibold uppercase tracking-wide text-foreground",
									children: filteredPhotos[lightboxIndex].title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono text-primary/90 shrink-0",
									children: filteredPhotos[lightboxIndex].dimensionsLabel || "On-Ground Real State"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-muted-foreground leading-relaxed max-w-3xl",
								children: filteredPhotos[lightboxIndex].description || "Authentic on-site photograph of Galaxy Green township in Lucknow."
							}),
							Array.isArray(filteredPhotos[lightboxIndex].highlights) && filteredPhotos[lightboxIndex].highlights.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 pt-1",
								children: filteredPhotos[lightboxIndex].highlights.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), h]
								}, i))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 pt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Physical Boundary Pillars Installed"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Immediate Registry & Possession Ready"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Direct 30-Ft Internal Road Connectivity"]
									})
								]
							})
						]
					})
				})
			]
		})]
	});
}
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
function EmiRoiCalculator({ onLockPriceClick }) {
	const [plotArea, setPlotArea] = (0, import_react.useState)(600);
	const [customAreaInput, setCustomAreaInput] = (0, import_react.useState)("600");
	const [downPaymentPercent, setDownPaymentPercent] = (0, import_react.useState)(20);
	const [tenureYears, setTenureYears] = (0, import_react.useState)(10);
	const [annualInterestRate, setAnnualInterestRate] = (0, import_react.useState)(8.5);
	const BASE_RATE = 1199;
	const effectiveArea = Math.max(100, plotArea);
	const totalCost = effectiveArea * BASE_RATE;
	const downPaymentAmount = Math.round(totalCost * (downPaymentPercent / 100));
	const loanAmount = Math.max(0, totalCost - downPaymentAmount);
	const monthlyRate = annualInterestRate / 12 / 100;
	const totalMonths = Math.max(12, tenureYears * 12);
	const emi = loanAmount > 0 && monthlyRate > 0 ? Math.round(loanAmount * monthlyRate * Math.pow(1 + monthlyRate, totalMonths) / (Math.pow(1 + monthlyRate, totalMonths) - 1)) : loanAmount > 0 ? Math.round(loanAmount / totalMonths) : 0;
	const estimatedStampDuty = Math.round(totalCost * .07);
	const estimatedRegistration = Math.round(totalCost * .01);
	const totalStatutoryFees = estimatedStampDuty + estimatedRegistration;
	const estimatedFutureValue5Years = Math.round(totalCost * Math.pow(1.18, 5));
	const projectedNetGain = estimatedFutureValue5Years - totalCost;
	const formatINR = (val) => new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(val);
	const handleCustomAreaChange = (valStr) => {
		setCustomAreaInput(valStr);
		const num = parseInt(valStr, 10);
		if (!isNaN(num) && num > 0) setPlotArea(num);
	};
	const handleCustomAreaBlur = () => {
		const num = parseInt(customAreaInput, 10);
		if (isNaN(num) || num < 600) {
			setPlotArea(600);
			setCustomAreaInput("600");
		} else if (num > 15e3) {
			setPlotArea(15e3);
			setCustomAreaInput("15000");
		}
	};
	const handlePresetSelect = (area) => {
		setPlotArea(area);
		setCustomAreaInput(area.toString());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "calculator",
		className: "section-shell bg-surface border-y border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "06 · Financial Intelligence"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-primary/10 text-primary border border-primary/30",
							children: "Official Rate: ₹1,199 / Sq Ft"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "section-title",
						children: "Investment ROI & EMI Calculator"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed",
						children: [
							"Minimum allotment starts from",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "text-foreground font-medium",
								children: [
									"600 sq. ft. (",
									formatINR(719400),
									")"
								]
							}),
							", with flexible dimensions scalable up to commercial parcels and luxury multi-plot estates."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 bg-accent/10 border border-accent/30 px-4 py-2.5 rounded text-xs text-accent font-mono",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amausi Corridor 5-Yr Growth Trend: +128%" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-8 lg:grid-cols-12 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 bg-card border border-border rounded-lg p-6 sm:p-8 space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap justify-between items-center gap-2 mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Plot Area (Min 600 Sq Ft to Custom)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 600,
										max: 15e3,
										step: 50,
										value: customAreaInput,
										onChange: (e) => handleCustomAreaChange(e.target.value),
										onBlur: handleCustomAreaBlur,
										className: "w-28 h-9 text-right font-display font-semibold text-primary text-base bg-background/80"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-mono text-muted-foreground",
										children: "Sq Ft"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								value: [plotArea > 4e3 ? 4e3 : Math.max(600, plotArea)],
								min: 600,
								max: 4e3,
								step: 50,
								onValueChange: (val) => {
									const v = val[0] ?? 600;
									setPlotArea(v);
									setCustomAreaInput(v.toString());
								},
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 mt-3",
								children: [
									{
										area: 600,
										label: "600 Sq Ft (₹7.19L)"
									},
									{
										area: 800,
										label: "800 Sq Ft (₹9.59L)"
									},
									{
										area: 1e3,
										label: "1,000 Sq Ft (₹11.99L)"
									},
									{
										area: 1200,
										label: "1,200 Sq Ft (₹14.39L)"
									},
									{
										area: 1500,
										label: "1,500 Sq Ft (₹17.99L)"
									},
									{
										area: 2e3,
										label: "2,000+ Sq Ft"
									}
								].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handlePresetSelect(preset.area),
									className: `px-3 py-1.5 rounded text-[11px] font-mono transition-all cursor-pointer ${plotArea === preset.area ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border"}`,
									children: preset.label
								}, preset.area))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: [
										"Down Payment (",
										downPaymentPercent,
										"%)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-display font-semibold text-accent",
									children: formatINR(downPaymentAmount)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								value: [downPaymentPercent],
								min: 10,
								max: 70,
								step: 5,
								onValueChange: (val) => setDownPaymentPercent(val[0] ?? 20),
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10% (Booking Token)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "20% (Standard)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "50% (Lower EMI)" })
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Bank Loan Tenure"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-lg font-display font-semibold text-foreground",
									children: [
										tenureYears,
										" Years (",
										totalMonths,
										" Months)"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								value: [tenureYears],
								min: 3,
								max: 15,
								step: 1,
								onValueChange: (val) => setTenureYears(val[0] ?? 10),
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "3 Years" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10 Years (Recommended)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "15 Years" })
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Bank Loan Interest Rate"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-lg font-display font-semibold text-primary font-mono",
									children: [annualInterestRate.toFixed(2), "% p.a."]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								value: [annualInterestRate],
								min: 7,
								max: 14,
								step: .05,
								onValueChange: (val) => {
									const v = val[0] ?? 8.5;
									setAnnualInterestRate(Number(v.toFixed(2)));
								},
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "7.0% (Subsidized)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "8.5% (SBI / HDFC Standard)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "14.0% (NBFC)" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 mt-3",
								children: [
									{
										rate: 8.4,
										label: "8.40% (SBI Prime)"
									},
									{
										rate: 8.65,
										label: "8.65% (HDFC Standard)"
									},
									{
										rate: 9.25,
										label: "9.25% (Private Bank)"
									},
									{
										rate: 10.5,
										label: "10.50% (Plot Loan)"
									}
								].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAnnualInterestRate(preset.rate),
									className: `px-2.5 py-1 rounded text-[10px] font-mono transition-all cursor-pointer ${Math.abs(annualInterestRate - preset.rate) < .05 ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border"}`,
									children: preset.label
								}, preset.rate))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 border-t border-border/70 space-y-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 text-primary" }), "Estimated Registry & Stamp Duty (UP Standard ~8%)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground font-mono text-xs",
									children: formatINR(totalStatutoryFees)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-[11px] font-mono text-muted-foreground bg-background/50 p-2.5 rounded border border-border/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Stamp Duty (~7%):",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: formatINR(estimatedStampDuty)
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Registration (~1%):",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: formatINR(estimatedRegistration)
									})
								] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 flex items-start gap-2.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgePercent, { className: "size-4 text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Computed at transparent fixed base rate",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹1,199 / sq ft"
								}),
								". Pre-approved plot loans available with nationalized lenders (SBI, HDFC, PNB) up to 80% financing with immediate legal title clearance."
							] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-primary/30 rounded-lg p-6 sm:p-8 relative overflow-hidden shadow-luxury",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-12 -right-12 size-36 bg-primary/10 rounded-full blur-2xl pointer-events-none" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-widest text-primary font-mono font-semibold block",
								children: "Estimated Monthly Outflow"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-baseline gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-4xl sm:text-5xl font-display font-semibold text-foreground",
									children: formatINR(emi)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono text-muted-foreground",
									children: "/ month"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-6 h-px bg-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Plot Size Selected"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-foreground font-mono text-sm",
											children: [effectiveArea.toLocaleString(), " Sq Ft"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Total Consideration (₹1,199/sq ft)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-primary font-medium text-sm",
											children: formatINR(totalCost)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												"Down Payment (",
												downPaymentPercent,
												"%)"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-accent font-medium text-sm",
											children: formatINR(downPaymentAmount)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Financed Loan Amount"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground font-medium text-sm",
											children: formatINR(loanAmount)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Interest Rate & Tenure"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-primary font-mono text-xs font-semibold",
											children: [
												annualInterestRate.toFixed(2),
												"% p.a. · ",
												tenureYears,
												" Yrs"
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 p-4 rounded-md bg-primary/10 border border-primary/30 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs font-mono text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "uppercase flex items-center gap-1.5 font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3.5" }), " 5-Yr Projected Value"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "18% CAGR" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-2xl font-display text-primary",
											children: formatINR(estimatedFutureValue5Years)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-emerald-400 font-semibold font-mono",
											children: [
												"+",
												formatINR(projectedNetGain),
												" net gain"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground leading-relaxed",
										children: "Conservative projection anchored on Lucknow Airport expansion, Amausi Railway & Metro transit connectivity."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								onClick: () => onLockPriceClick(`${effectiveArea} sq ft`),
								className: "mt-6 w-full h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
								children: ["Lock Current ₹1,199 Rate ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-2" })]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface/80 border border-border/80 rounded p-3.5 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Pre-approved Bank Loans Available"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] text-accent font-medium",
							children: "SBI · HDFC · PNB"
						})]
					})]
				})]
			})]
		})
	});
}
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var checkDbHealthFn = createServerFn({ method: "GET" }).handler(createSsrRpc("505be61f9be0c6d90fc623b88117224ca63263ae0c12268ce4e49dcb70af582a"));
var verifyDealerPinFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e7ac86809fa5971ab2c5617edd3c6f0b3b2d480f6744776eb92f355f7285a156"));
var getAdminConfigFn = createServerFn({ method: "GET" }).handler(createSsrRpc("43cd7b54e5dc3bcb5518523224afd8375657788c242e7a28c12b315439ae2fbb"));
var updateAdminConfigFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("0962a1e2dd3197bad26b146bdd61eed6e69f7038cdd069591f142ecc8c0685c1"));
var getInquiriesFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("5e26ac6fa8f922e9958a1008e30aa59228ff5a307c4a951894aac4575e90051f"));
var submitInquiryFn = createServerFn({ method: "POST" }).validator((data) => inquirySchema.parse(data)).handler(createSsrRpc("4877a1cab4e33623d7dcfe7339376faf33cbd3233330988495f52b8680c031c9"));
var updateInquiryStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e84fb555a6cb651ec16f9488a9b44867349925588b9630f1ed87aba7f6b9c588"));
var STORAGE_KEY$1 = "galaxy_green_leads_v1";
var PIN_TOKEN_KEY = "gg_dealer_pin_signed_token";
function getClientPinToken() {
	if (typeof window === "undefined") return void 0;
	return localStorage.getItem(PIN_TOKEN_KEY) || void 0;
}
function setClientPinToken(token) {
	if (typeof window === "undefined") return;
	localStorage.setItem(PIN_TOKEN_KEY, token);
}
async function verifyDealerPin(pin) {
	const res = await verifyDealerPinFn({ data: {
		pin,
		clientPinToken: getClientPinToken()
	} });
	const typedRes = res;
	if (typedRes?.success && typedRes?.signedPinToken) setClientPinToken(typedRes.signedPinToken);
	return res;
}
async function fetchAllLeads(token) {
	if (!token) return [];
	let serverLeads = [];
	try {
		const res = await getInquiriesFn({ data: { token } });
		if (Array.isArray(res)) serverLeads = res;
	} catch (err) {
		console.warn("Error fetching leads from server:", err);
	}
	if (typeof window !== "undefined") try {
		const saved = localStorage.getItem(STORAGE_KEY$1);
		if (saved) {
			const localList = JSON.parse(saved);
			const map = /* @__PURE__ */ new Map();
			for (const item of serverLeads) map.set(item.id, item);
			for (const item of localList) if (!map.has(item.id)) map.set(item.id, item);
			return Array.from(map.values());
		}
	} catch {}
	return serverLeads;
}
async function recordNewInquiry(input) {
	let created = null;
	try {
		const res = await submitInquiryFn({ data: input });
		if (res && typeof res === "object" && "success" in res && !res.success && res.error) throw new Error(res.error);
		if (res?.inquiry) created = res.inquiry;
	} catch (err) {
		if (err instanceof Error && !err.message.includes("fetch") && !err.message.includes("Failed to execute")) throw err;
		console.warn("Server submission fallback:", err);
	}
	if (!created) created = {
		...input,
		id: `GG-2026-${Math.floor(1e3 + Math.random() * 9e3)}`,
		status: "New",
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	if (typeof window !== "undefined") try {
		const saved = localStorage.getItem(STORAGE_KEY$1);
		const list = saved ? JSON.parse(saved) : [];
		list.unshift(created);
		localStorage.setItem(STORAGE_KEY$1, JSON.stringify(list));
	} catch {}
	return created;
}
async function updateLeadStatus(id, status, token) {
	const activeToken = token || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") : void 0);
	if (!activeToken) return false;
	try {
		if ((await updateInquiryStatusFn({ data: {
			token: activeToken,
			id,
			status
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const saved = localStorage.getItem(STORAGE_KEY$1);
				if (saved) {
					const updated = JSON.parse(saved).map((item) => item.id === id ? {
						...item,
						status
					} : item);
					localStorage.setItem(STORAGE_KEY$1, JSON.stringify(updated));
				}
			} catch (err) {}
			return true;
		}
	} catch (err) {
		console.warn("Server status update error:", err);
	}
	return false;
}
function exportLeadsToCsv(leads) {
	const headers = [
		"ID",
		"Name",
		"Phone",
		"Email",
		"Plot Preference",
		"Visit Date",
		"Slot",
		"Status",
		"Created At",
		"Message"
	];
	const rows = leads.map((lead) => [
		lead.id,
		`"${lead.name.replace(/"/g, "\"\"")}"`,
		`"${lead.phone}"`,
		`"${lead.email || ""}"`,
		`"${lead.plotPreference}"`,
		`"${lead.visitDate || ""}"`,
		`"${lead.slot}"`,
		`"${lead.status}"`,
		`"${new Date(lead.createdAt).toLocaleString("en-IN")}"`,
		`"${(lead.message || "").replace(/"/g, "\"\"")}"`
	]);
	const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
	const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.setAttribute("href", url);
	link.setAttribute("download", `Galaxy_Green_Leads_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`);
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
}
var STORAGE_KEY = "gg_my_bookings_cache";
var EVENT_NAME = "gg_my_bookings_updated";
function getLocalBookings() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch (err) {
		console.warn("Failed to read local bookings cache:", err);
		return [];
	}
}
function saveLocalBooking(booking) {
	if (typeof window === "undefined") return [];
	try {
		const existing = getLocalBookings();
		const updated = [{
			...booking,
			bookedAt: booking.bookedAt || (/* @__PURE__ */ new Date()).toISOString()
		}, ...existing.filter((b) => b.id !== booking.id)].slice(0, 20);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
		window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: updated }));
		return updated;
	} catch (err) {
		console.warn("Failed to persist local booking:", err);
		return getLocalBookings();
	}
}
function removeLocalBooking(id) {
	if (typeof window === "undefined") return [];
	try {
		const updated = getLocalBookings().filter((b) => b.id !== id);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
		window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: updated }));
		return updated;
	} catch (err) {
		console.warn("Failed to remove local booking:", err);
		return getLocalBookings();
	}
}
function subscribeToBookings(callback) {
	if (typeof window === "undefined") return () => {};
	const handler = () => {
		callback(getLocalBookings());
	};
	window.addEventListener(EVENT_NAME, handler);
	window.addEventListener("storage", handler);
	return () => {
		window.removeEventListener(EVENT_NAME, handler);
		window.removeEventListener("storage", handler);
	};
}
/**
* Visit scheduling date & time validation utilities
* Ensures local timezone accuracy (immune to UTC date shift) and strict prevention of past date/time bookings
* while keeping all upcoming dates and operational future timings (7:00 AM – 7:00 PM) fully open and usable.
*/
function getLocalDateString(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseTimeHoursMinutes(timeStr) {
	if (!timeStr || typeof timeStr !== "string") return null;
	const clean = timeStr.trim();
	const colonMatch = clean.match(/(\d{1,2})[:.](\d{2})\s*(AM|PM)?/i);
	if (colonMatch && colonMatch[1] && colonMatch[2]) {
		let hours = parseInt(colonMatch[1], 10);
		const minutes = parseInt(colonMatch[2], 10);
		const meridian = colonMatch[3]?.toUpperCase();
		if (meridian === "PM" && hours < 12) hours += 12;
		if (meridian === "AM" && hours === 12) hours = 0;
		if (!meridian && hours >= 1 && hours <= 6) hours += 12;
		return {
			hours,
			minutes
		};
	}
	const hourMatch = clean.match(/^(\d{1,2})\s*(AM|PM)$/i);
	if (hourMatch && hourMatch[1] && hourMatch[2]) {
		let hours = parseInt(hourMatch[1], 10);
		const meridian = hourMatch[2].toUpperCase();
		if (meridian === "PM" && hours < 12) hours += 12;
		if (meridian === "AM" && hours === 12) hours = 0;
		return {
			hours,
			minutes: 0
		};
	}
	return null;
}
/**
* Decomposes a time string into 12-hour parts (hours 1-12, minutes 0-59, AM/PM)
*/
function splitTimeToHMP(timeStr) {
	const parsed = parseTimeHoursMinutes(timeStr);
	if (!parsed) return {
		hour12: 10,
		minute: 0,
		period: "AM"
	};
	const { hours, minutes } = parsed;
	const period = hours >= 12 ? "PM" : "AM";
	let hour12 = hours % 12;
	if (hour12 === 0) hour12 = 12;
	return {
		hour12,
		minute: minutes,
		period
	};
}
/**
* Recombines 12-hour parts into standard formatted time string, e.g. "10:30 AM"
*/
function composeHMPToTime(hour12, minute, period) {
	return `${String(hour12).padStart(2, "0")}:${String(minute).padStart(2, "0")} ${period}`;
}
/**
* Converts 12-hour time parts to 24-hour total minutes from midnight
*/
function timePartsToTotalMinutes(hour12, minute, period) {
	let h24 = hour12 % 12;
	if (period === "PM") h24 += 12;
	return h24 * 60 + minute;
}
/**
* Validates if time parts fall within daylight operational hours (7:00 AM – 7:00 PM)
*/
function isWithinOperatingHours(hour12, minute, period) {
	const totalMins = timePartsToTotalMinutes(hour12, minute, period);
	return totalMins >= 420 && totalMins <= 1140;
}
/**
* Check if a specific time has already passed for a selected date
*/
function isSpecificTimePassed(hour12, minute, period, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	return timePartsToTotalMinutes(hour12, minute, period) <= now.getHours() * 60 + now.getMinutes();
}
/**
* Checks if an entire hour (all 60 minutes) has passed for today
*/
function isHourEntirelyPassed(hour12, period, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	return timePartsToTotalMinutes(hour12, 59, period) <= now.getHours() * 60 + now.getMinutes();
}
function isTimePassedForDate(timeStr, selectedDate, now = /* @__PURE__ */ new Date()) {
	if (!selectedDate) return false;
	const todayStr = getLocalDateString(now);
	const normDate = (selectedDate.includes("T") ? selectedDate.split("T")[0] : selectedDate).trim();
	if (normDate > todayStr) return false;
	if (normDate < todayStr) return true;
	const parsed = parseTimeHoursMinutes(timeStr);
	if (!parsed) return false;
	return now.getHours() * 60 + now.getMinutes() >= parsed.hours * 60 + parsed.minutes;
}
var PRESET_SLOTS = [
	{
		id: "Morning (10:00 AM)",
		label: "10:00 AM (Morning)"
	},
	{
		id: "Afternoon (2:00 PM)",
		label: "02:00 PM (Afternoon)"
	},
	{
		id: "Evening Sunset (4:30 PM)",
		label: "04:30 PM (Evening)"
	}
];
var HOURS_LIST = [
	7,
	8,
	9,
	10,
	11,
	12,
	1,
	2,
	3,
	4,
	5,
	6,
	7
];
var MINUTES_LIST = [
	0,
	15,
	30,
	45
];
function ClockTimePicker({ value, onChange, selectedDate, className = "", compact = false }) {
	const todayStr = (0, import_react.useMemo)(() => getLocalDateString(), []);
	const isToday = (selectedDate || "").trim() === todayStr;
	const { hour12, minute, period } = (0, import_react.useMemo)(() => {
		return splitTimeToHMP(value);
	}, [value]);
	const hourAngle = (0, import_react.useMemo)(() => {
		return (hour12 % 12 + minute / 60) * 30;
	}, [hour12, minute]);
	const minuteAngle = (0, import_react.useMemo)(() => {
		return minute * 6;
	}, [minute]);
	const isCurrentTimePassed = (0, import_react.useMemo)(() => {
		return isSpecificTimePassed(hour12, minute, period, selectedDate);
	}, [
		hour12,
		minute,
		period,
		selectedDate
	]);
	const isCurrentInOperatingHours = (0, import_react.useMemo)(() => {
		return isWithinOperatingHours(hour12, minute, period);
	}, [
		hour12,
		minute,
		period
	]);
	const isAmEntirelyPassedToday = (0, import_react.useMemo)(() => {
		if (!isToday) return false;
		return (/* @__PURE__ */ new Date()).getHours() >= 12;
	}, [isToday]);
	const isPmEntirelyPassedToday = (0, import_react.useMemo)(() => {
		if (!isToday) return false;
		return (/* @__PURE__ */ new Date()).getHours() >= 19;
	}, [isToday]);
	const updateTime = (newH, newM, newP) => {
		onChange(composeHMPToTime(newH, newM, newP));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border border-primary/30 bg-surface/95 p-3.5 sm:p-4 backdrop-blur-md shadow-sm transition-all ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border/70",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-12 sm:size-14 rounded-full bg-background border-2 border-primary/50 shadow-[0_0_12px_rgba(16,185,129,0.25)] flex items-center justify-center shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-1 rounded-full border border-dashed border-border/60" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "12"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "6"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute left-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "9"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute w-1 bg-primary rounded-full origin-bottom transition-transform duration-300",
								style: {
									height: "14px",
									bottom: "50%",
									transform: `rotate(${hourAngle}deg)`
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute w-0.5 bg-amber-400 rounded-full origin-bottom transition-transform duration-300",
								style: {
									height: "18px",
									bottom: "50%",
									transform: `rotate(${minuteAngle}deg)`
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-white border border-primary z-10" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] uppercase tracking-wider font-mono font-semibold text-muted-foreground",
							children: "Visit Timing Clock"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-1 mt-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-lg sm:text-xl font-bold tracking-tight text-foreground text-glow-subtle",
							children: [
								String(hour12).padStart(2, "0"),
								" : ",
								String(minute).padStart(2, "0")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs font-bold text-primary ml-0.5 px-1.5 py-0.5 rounded bg-primary/10 border border-primary/30 uppercase",
							children: period
						})]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: isCurrentTimePassed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-destructive/15 border border-destructive/40 text-destructive text-[11px] font-mono flex items-center gap-1.5 animate-pulse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Time Passed Today" })]
					}) : !isCurrentInOperatingHours ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-amber-500/15 border border-amber-500/40 text-amber-300 text-[11px] font-mono flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Outside 7 AM – 7 PM" })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 shrink-0 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Available Slot" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase font-mono tracking-wider text-muted-foreground font-semibold",
					children: "1. Meridian:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex rounded-lg border border-border bg-background/80 p-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: isAmEntirelyPassedToday,
						onClick: () => {
							if (isAmEntirelyPassedToday) return;
							updateTime(hour12, minute, "AM");
						},
						className: `px-3 py-1 text-xs font-mono font-semibold rounded-md transition-all ${isAmEntirelyPassedToday ? "opacity-35 cursor-not-allowed line-through text-muted-foreground" : period === "AM" ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"}`,
						children: ["AM ", isAmEntirelyPassedToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] no-underline",
							children: "✕"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: isPmEntirelyPassedToday,
						onClick: () => {
							if (isPmEntirelyPassedToday) return;
							updateTime(hour12, minute, "PM");
						},
						className: `px-3 py-1 text-xs font-mono font-semibold rounded-md transition-all ${isPmEntirelyPassedToday ? "opacity-35 cursor-not-allowed line-through text-muted-foreground" : period === "PM" ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"}`,
						children: ["PM ", isPmEntirelyPassedToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] no-underline",
							children: "✕"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-[10px] font-mono text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "2. Select Hour:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: period === "AM" ? "Morning (7–11 AM)" : "Afternoon/Evening (12–7 PM)" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-6 sm:grid-cols-6 gap-1.5",
					children: HOURS_LIST.map((h, idx) => {
						const isInOps = period === "AM" ? h >= 7 && h <= 11 : h === 12 || h >= 1 && h <= 7;
						const isPassed = isHourEntirelyPassed(h, period, selectedDate);
						const isSelected = hour12 === h;
						const disabled = !isInOps || isPassed;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled,
							onClick: () => {
								if (disabled) return;
								updateTime(h, minute, period);
							},
							className: `py-1.5 px-1 rounded-md text-xs font-mono font-medium border text-center transition-all relative ${disabled ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary font-bold shadow-glow ring-1 ring-primary/40" : "bg-background/80 border-border text-foreground hover:border-primary/50 hover:bg-surface-hover"}`,
							title: !isInOps ? `Hour ${h} ${period} is outside 7 AM – 7 PM daylight visiting hours` : isPassed ? `Hour ${h} ${period} has already passed for today` : `Select ${h}:00 ${period}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[8px] block opacity-75 font-normal",
								children: period
							})]
						}, `${h}-${idx}`);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-[10px] font-mono text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "3. Select Minutes:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "15-min Intervals" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-1.5",
					children: MINUTES_LIST.map((m) => {
						const isPassed = isSpecificTimePassed(hour12, m, period, selectedDate);
						const isSelected = minute === m;
						const disabled = isPassed;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled,
							onClick: () => {
								if (disabled) return;
								updateTime(hour12, m, period);
							},
							className: `py-1.5 rounded-md text-xs font-mono font-semibold border text-center transition-all ${disabled ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary shadow-glow ring-1 ring-primary/40" : "bg-background/80 border-border text-foreground hover:border-primary/50 hover:bg-surface-hover"}`,
							title: isPassed ? `Time :${String(m).padStart(2, "0")} has passed for today` : `Set to ${String(m).padStart(2, "0")} mins`,
							children: [
								":",
								String(m).padStart(2, "0"),
								isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-[8px] no-underline",
									children: "✕"
								})
							]
						}, m);
					})
				})]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 pt-2.5 border-t border-border/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between mb-1.5 text-[10px] font-mono text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "Quick Daylight Tour Slots:"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [
						{
							label: "10:00 AM",
							h: 10,
							m: 0,
							p: "AM",
							desc: "Morning"
						},
						{
							label: "11:30 AM",
							h: 11,
							m: 30,
							p: "AM",
							desc: "Midday"
						},
						{
							label: "02:00 PM",
							h: 2,
							m: 0,
							p: "PM",
							desc: "Afternoon"
						},
						{
							label: "04:30 PM",
							h: 4,
							m: 30,
							p: "PM",
							desc: "Sunset"
						},
						{
							label: "05:30 PM",
							h: 5,
							m: 30,
							p: "PM",
							desc: "Golden Hour"
						}
					].map((slot) => {
						const isPassed = isSpecificTimePassed(slot.h, slot.m, slot.p, selectedDate);
						const isSelected = hour12 === slot.h && minute === slot.m && period === slot.p;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: isPassed,
							onClick: () => {
								if (isPassed) return;
								updateTime(slot.h, slot.m, slot.p);
							},
							className: `px-2 py-1 rounded text-[10px] font-mono border transition-all ${isPassed ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary font-bold shadow-glow" : "bg-background/80 border-border text-muted-foreground hover:text-foreground hover:border-primary/40"}`,
							children: [
								slot.label,
								" (",
								slot.desc,
								")"
							]
						}, slot.label);
					})
				})]
			})
		]
	});
}
var PHONE_NUMBER$1 = "919044412642";
var BASE_RATE = 1199;
function formatCurrency(amount) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(amount);
}
function SiteVisitModal({ open, onOpenChange, defaultPlotPreference = "600 sq ft" }) {
	const [step, setStep] = (0, import_react.useState)("form");
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [confirmedBooking, setConfirmedBooking] = (0, import_react.useState)(null);
	const todayStr = getLocalDateString();
	const tomorrowDate = /* @__PURE__ */ new Date();
	tomorrowDate.setDate(tomorrowDate.getDate() + 1);
	const tomorrowStr = getLocalDateString(tomorrowDate);
	const currentHour = (/* @__PURE__ */ new Date()).getHours();
	const currentMinute = (/* @__PURE__ */ new Date()).getMinutes();
	const isPastOperatingHours = currentHour > 18 || currentHour === 18 && currentMinute >= 30;
	const minSelectableDate = isPastOperatingHours ? tomorrowStr : todayStr;
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [visitDate, setVisitDate] = (0, import_react.useState)(() => {
		const now = /* @__PURE__ */ new Date();
		if (now.getHours() > 18 || now.getHours() === 18 && now.getMinutes() >= 30) {
			const d = /* @__PURE__ */ new Date();
			d.setDate(d.getDate() + 1);
			return getLocalDateString(d);
		}
		return getLocalDateString(now);
	});
	const [slotType, setSlotType] = (0, import_react.useState)("preset");
	const [presetSlot, setSlotPreset] = (0, import_react.useState)("Morning (10:00 AM)");
	const [customTime, setCustomTime] = (0, import_react.useState)("11:30 AM");
	const [plotMode, setPlotMode] = (0, import_react.useState)("preset");
	const [presetPlot, setPresetPlot] = (0, import_react.useState)(defaultPlotPreference);
	const [customSqFt, setCustomSqFt] = (0, import_react.useState)(2e3);
	const [customPlotType, setCustomPlotType] = (0, import_react.useState)("East Facing (Vaastu Compliant)");
	const [customPlotNotes, setCustomPlotNotes] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [websiteHoneypot, setWebsiteHoneypot] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open && defaultPlotPreference) if (defaultPlotPreference.toLowerCase().includes("custom")) {
			setPlotMode("custom");
			const matchNum = defaultPlotPreference.match(/(\d[\d,]*)/);
			if (matchNum && matchNum[1]) {
				const parsed = parseInt(matchNum[1].replace(/,/g, ""), 10);
				if (!isNaN(parsed) && parsed >= 600) setCustomSqFt(parsed);
			}
		} else {
			setPlotMode("preset");
			setPresetPlot(defaultPlotPreference);
		}
	}, [open, defaultPlotPreference]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (visitDate < minSelectableDate) setVisitDate(minSelectableDate);
	}, [
		open,
		visitDate,
		minSelectableDate
	]);
	const isToday = visitDate === todayStr;
	const allPresetsPassedToday = isToday && PRESET_SLOTS.every((slot) => isTimePassedForDate(slot.id, visitDate));
	const effectiveSlot = slotType === "custom" ? `Custom Time: ${customTime.trim() || "Client Flexible"}` : presetSlot;
	const customAllotmentCost = Math.round(customSqFt * BASE_RATE);
	const effectivePlotPreference = plotMode === "custom" ? `Custom ${customSqFt} Sq Ft (${formatCurrency(customAllotmentCost)} · ${customPlotType}${customPlotNotes ? ` · ${customPlotNotes}` : ""})` : presetPlot;
	const handleDateChange = (newDate) => {
		if (newDate && newDate < minSelectableDate) {
			setError("Visit date cannot be in the past. Please select today or an upcoming date.");
			setVisitDate(minSelectableDate);
			return;
		}
		setError("");
		setVisitDate(newDate);
		if (newDate === todayStr && slotType === "preset") {
			if (isTimePassedForDate(presetSlot, newDate)) {
				const nextAvailable = PRESET_SLOTS.find((s) => !isTimePassedForDate(s.id, newDate));
				if (nextAvailable) setSlotPreset(nextAvailable.id);
				else {
					setSlotType("custom");
					setCustomTime("05:30 PM");
				}
			}
		} else if (newDate > todayStr) {
			if (!presetSlot) setSlotPreset(PRESET_SLOTS[0]?.id || "Morning (10:00 AM)");
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (name.trim().length < 2) {
			setError("Please enter your full name.");
			return;
		}
		const cleanPhone = phone.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
			setError("Please enter a valid 10-digit Indian mobile number.");
			return;
		}
		if (!visitDate) {
			setError("Please select your preferred visit date.");
			return;
		}
		if (visitDate < minSelectableDate) {
			setError("Visit date cannot be in the past. Please select today or a future date.");
			return;
		}
		if (visitDate === todayStr) {
			if (isPastOperatingHours) {
				setError("Ground visits for today have ended (operating hours: 7:00 AM – 7:00 PM). Please select tomorrow or an upcoming date.");
				return;
			}
			if (slotType === "preset") {
				if (isTimePassedForDate(presetSlot, visitDate)) {
					setError(`The selected slot (${presetSlot}) has already passed for today. Please choose an upcoming slot or switch to tomorrow.`);
					return;
				}
			} else {
				if (!customTime.trim()) {
					setError("Please specify your preferred custom visit timing.");
					return;
				}
				const parsed = parseTimeHoursMinutes(customTime);
				if (!parsed) {
					setError("Please enter a valid visit timing (e.g. 11:30 AM or 05:00 PM).");
					return;
				}
				if (parsed.hours < 7 || parsed.hours >= 19) {
					setError("Visits are conducted between 7:00 AM and 7:00 PM. Please enter a time within operational hours.");
					return;
				}
				if (isTimePassedForDate(customTime, visitDate)) {
					setError(`The custom timing "${customTime}" has already passed for today. Please pick an upcoming time slot.`);
					return;
				}
			}
		} else if (slotType === "custom") {
			if (!customTime.trim()) {
				setError("Please specify your preferred custom visit timing.");
				return;
			}
			const parsed = parseTimeHoursMinutes(customTime);
			if (!parsed) {
				setError("Please enter a valid visit timing (e.g. 11:30 AM or 05:00 PM).");
				return;
			}
			if (parsed.hours < 7 || parsed.hours >= 19) {
				setError("Visits are conducted between 7:00 AM and 7:00 PM. Please enter a time within operational hours.");
				return;
			}
		}
		if (plotMode === "custom" && (!customSqFt || customSqFt < 600)) {
			setError("Minimum plot allotment size starts from 600 Sq Ft.");
			return;
		}
		setError("");
		setSubmitting(true);
		try {
			const created = await recordNewInquiry({
				name: name.trim(),
				phone: cleanPhone,
				plotPreference: effectivePlotPreference,
				visitDate,
				slot: effectiveSlot,
				cabPickup: false,
				pickupLocation: "On Site",
				message: message.trim(),
				website: websiteHoneypot
			});
			setConfirmedBooking(created);
			setStep("confirmed");
			saveLocalBooking({
				id: created.id,
				name: created.name,
				phone: created.phone,
				plotPreference: created.plotPreference,
				visitDate: created.visitDate,
				slot: created.slot,
				message: created.message
			});
			toast.success("Site Visit Reserved! Reference: " + created.id);
		} catch (err) {
			console.error("Site visit reservation error:", err);
			const errMsg = err instanceof Error ? err.message : "Failed to submit booking. Please try again.";
			setError(errMsg);
			toast.error(errMsg);
		} finally {
			setSubmitting(false);
		}
	};
	const openWhatsAppConfirmation = () => {
		if (!confirmedBooking) return;
		const text = [
			`Hello Vishal Singh, I have scheduled a Site Visit for Galaxy Green Sai Suraksha Nagar.`,
			`Booking Ref: ${confirmedBooking.id}`,
			`Name: ${confirmedBooking.name}`,
			`Mobile: ${confirmedBooking.phone}`,
			`Plot Preference: ${confirmedBooking.plotPreference}`,
			`Date & Slot: ${confirmedBooking.visitDate} · ${confirmedBooking.slot}`,
			confirmedBooking.message ? `Notes: ${confirmedBooking.message}` : ""
		].filter(Boolean).join("\n");
		window.open(`https://wa.me/${PHONE_NUMBER$1}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
	};
	const handleClose = () => {
		onOpenChange(false);
		setTimeout(() => {
			setStep("form");
			setError("");
		}, 300);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: handleClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "w-[calc(100vw-1rem)] sm:w-full max-w-xl bg-card border-border text-foreground p-4 sm:p-7 max-h-[min(92dvh,92vh)] overflow-y-auto pb-[max(1.25rem,env(safe-area-inset-bottom))]",
			children: step === "form" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "pr-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 sm:size-12 rounded-xl overflow-hidden shadow-glow ring-1 ring-primary/40 shrink-0 bg-[#071510]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/galaxy-green-emblem.png",
							alt: "Galaxy Green",
							width: 48,
							height: 48,
							className: "size-full object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-1.5 sm:gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "border-primary text-primary bg-primary/10 text-[10px] uppercase font-mono shrink-0",
								children: "VIP Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground font-mono truncate",
								children: "Zero Obligation · Free Guided Ground Tour"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-lg sm:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 leading-snug",
							children: "Book Your Private Site Visit"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "text-xs text-muted-foreground mt-1",
					children: "Inspect physical plot boundary pillars, review original legal registry documents, and choose custom dimensions with complete freedom."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4 mt-3",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[11px] uppercase font-mono text-muted-foreground",
							children: "Your Name *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "e.g. Rahul Sharma",
							value: name,
							onChange: (e) => setName(e.target.value),
							className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[11px] uppercase font-mono text-muted-foreground",
							children: "Mobile Number *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "numeric",
							maxLength: 10,
							placeholder: "10-digit mobile",
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-[11px] uppercase font-mono text-muted-foreground flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3 text-primary" }), " Calendar (Year / Month / Date) *"]
										}), isToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-primary font-semibold",
											children: "Today"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										min: minSelectableDate,
										value: visitDate,
										onChange: (e) => handleDateChange(e.target.value),
										className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border font-mono font-medium"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5 mt-1.5",
										children: [
											!isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleDateChange(todayStr),
												className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${visitDate === todayStr ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-surface border-border text-muted-foreground hover:text-foreground"}`,
												children: "Today"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleDateChange(tomorrowStr),
												className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${visitDate === tomorrowStr ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-surface border-border text-muted-foreground hover:text-foreground"}`,
												children: "Tomorrow"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] font-mono text-muted-foreground ml-auto",
												children: "Past dates blocked"
											})
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-[11px] uppercase font-mono text-muted-foreground flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-primary" }), " Preferred Timing *"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "7 AM – 7 PM"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-1.5 mt-1",
									children: [PRESET_SLOTS.map((slotOption) => {
										const isPassed = isTimePassedForDate(slotOption.id, visitDate);
										const isSelected = slotType === "preset" && presetSlot === slotOption.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: isPassed,
											onClick: () => {
												if (isPassed) return;
												setSlotType("preset");
												setSlotPreset(slotOption.id);
												setError("");
											},
											className: `px-2 py-2 rounded-md text-[11px] font-mono border transition-all text-center relative ${isPassed ? "opacity-35 cursor-not-allowed bg-surface/30 line-through text-muted-foreground border-border/40 hover:bg-surface/30" : isSelected ? "bg-primary text-primary-foreground border-primary font-semibold shadow-glow ring-1 ring-primary/40" : "bg-surface border-border/80 text-muted-foreground hover:text-foreground hover:bg-surface-hover hover:border-primary/40"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block leading-tight",
												children: slotOption.label
											}), isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-[9px] text-destructive/90 font-mono no-underline uppercase tracking-wider font-semibold",
												children: "Passed"
											})]
										}, slotOption.id);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: isToday && isPastOperatingHours,
										onClick: () => {
											if (isToday && isPastOperatingHours) return;
											setSlotType("custom");
											setError("");
										},
										className: `px-2 py-2 rounded-md text-[11px] font-mono border transition-all text-center ${isToday && isPastOperatingHours ? "opacity-35 cursor-not-allowed bg-surface/30 text-muted-foreground line-through" : slotType === "custom" ? "bg-primary text-primary-foreground border-primary font-semibold shadow-glow ring-1 ring-primary/40" : "bg-surface border-border/80 text-muted-foreground hover:text-foreground hover:bg-surface-hover hover:border-primary/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block leading-tight font-semibold",
											children: "🕒 Clock Selector"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[9px] opacity-80 font-mono mt-0.5",
											children: "Hours, Mins, AM/PM"
										})]
									})]
								})] })]
							}),
							isToday && allPresetsPassedToday && !isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center justify-between gap-2 animate-in fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Standard morning/afternoon slots have passed today. Use the Clock Selector below or choose tomorrow." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleDateChange(tomorrowStr),
									className: "px-2 py-1 bg-primary text-primary-foreground text-[10px] rounded font-semibold whitespace-nowrap hover:bg-primary/90",
									children: "Tomorrow →"
								})]
							}),
							isToday && isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-xs font-mono flex items-center justify-between gap-2 animate-in fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visiting hours for today have ended (7:00 AM – 7:00 PM). Please select tomorrow or an upcoming date." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleDateChange(tomorrowStr),
									className: "px-2 py-1 bg-primary text-primary-foreground text-[10px] rounded font-semibold whitespace-nowrap hover:bg-primary/90",
									children: "Book for Tomorrow →"
								})]
							}),
							slotType === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "animate-in fade-in slide-in-from-top-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockTimePicker, {
									value: customTime,
									onChange: (newTime) => {
										setCustomTime(newTime);
										setError("");
									},
									selectedDate: visitDate
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 pt-2 border-t border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[11px] uppercase font-mono text-muted-foreground",
									children: "Plot Sizing & Configuration"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono text-emerald-400",
									children: "₹1,199 / Sq Ft Base Rate"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-2",
								children: [
									{
										id: "600 sq ft",
										size: "600 Sq Ft",
										price: "₹7.19 Lakh",
										desc: "Starting"
									},
									{
										id: "800 sq ft",
										size: "800 Sq Ft",
										price: "₹9.59 Lakh",
										desc: "Compact"
									},
									{
										id: "1000 sq ft",
										size: "1,000 Sq Ft",
										price: "₹11.99 Lakh",
										desc: "Most Popular"
									},
									{
										id: "1200 sq ft",
										size: "1,200 Sq Ft",
										price: "₹14.39 Lakh",
										desc: "Duplex Villa"
									},
									{
										id: "1500 sq ft",
										size: "1,500 Sq Ft",
										price: "₹17.99 Lakh",
										desc: "Executive"
									},
									{
										id: "2000 sq ft",
										size: "2,000 Sq Ft",
										price: "₹23.98 Lakh",
										desc: "Luxury Estate"
									}
								].map((plotItem) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setPlotMode("preset");
										setPresetPlot(plotItem.id);
									},
									className: `p-2.5 rounded-lg border text-left transition-all ${plotMode === "preset" && presetPlot === plotItem.id ? "border-primary bg-primary/15 shadow-glow ring-1 ring-primary/40" : "border-border/80 bg-surface hover:bg-surface-hover hover:border-primary/40"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-display font-semibold text-foreground",
											children: plotItem.size
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-mono text-muted-foreground",
											children: plotItem.desc
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[11px] font-mono text-primary font-semibold mt-0.5",
										children: plotItem.price
									})]
								}, plotItem.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setPlotMode(plotMode === "custom" ? "preset" : "custom"),
								className: `w-full p-2.5 rounded-lg border flex items-center justify-between transition-all ${plotMode === "custom" ? "border-primary bg-primary/15 shadow-glow ring-1 ring-primary/50" : "border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-display font-semibold text-foreground",
										children: "Custom Size Requirement (Any Size On Buyer Wish)"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono text-primary border border-primary/40 px-2 py-0.5 rounded",
									children: plotMode === "custom" ? "Active" : "Click to Customize"
								})]
							}),
							plotMode === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-lg bg-surface/90 border border-primary/40 space-y-3 animate-in fade-in duration-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono font-semibold text-primary flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "size-3.5" }), " Flexible Plot Customizer"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono text-emerald-400 font-semibold",
											children: [
												formatCurrency(customAllotmentCost),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[10px] font-normal",
													children: "(@ ₹1,199/sq ft)"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 600,
												max: 25e3,
												step: 50,
												value: customSqFt,
												onChange: (e) => {
													const val = parseInt(e.target.value, 10);
													setCustomSqFt(isNaN(val) ? 600 : val);
												},
												className: "h-9 text-xs font-mono font-semibold bg-background pr-14"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute right-3 top-2.5 text-[10px] font-mono text-muted-foreground pointer-events-none",
												children: "Sq Ft"
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5 mt-2",
										children: [
											{
												sqFt: 750,
												label: "750 Sq Ft"
											},
											{
												sqFt: 1800,
												label: "1,800 Sq Ft"
											},
											{
												sqFt: 2500,
												label: "2,500 Sq Ft"
											},
											{
												sqFt: 3500,
												label: "3,500 Sq Ft"
											},
											{
												sqFt: 5e3,
												label: "5,000+ (Multi-Plot)"
											}
										].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCustomSqFt(item.sqFt),
											className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${customSqFt === item.sqFt ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background border-border text-muted-foreground hover:text-foreground"}`,
											children: item.label
										}, item.sqFt))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-[10px] uppercase font-mono text-muted-foreground flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3" }), " Orientation / Feature"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: customPlotType,
											onChange: (e) => setCustomPlotType(e.target.value),
											className: "mt-1 h-8 w-full px-2 text-[11px] bg-background border border-border rounded text-foreground focus:border-primary focus:outline-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "East Facing (Vaastu Compliant)",
													children: "East Facing (Vaastu)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Corner Plot (Dual 30ft Road)",
													children: "Corner Plot (Dual Road)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "North Facing (Prime Airflow)",
													children: "North Facing"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "West Facing (Sunset Boulevard)",
													children: "West Facing"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Adjacent Multi-Plots (Joint Family)",
													children: "Adjacent Multi-Plots"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Commercial Roadside Frontage",
													children: "Commercial Frontage"
												})
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-[10px] uppercase font-mono text-muted-foreground flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3" }), " Dimensions / Request"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "e.g. 50×50 ft, near park",
											value: customPlotNotes,
											onChange: (e) => setCustomPlotNotes(e.target.value),
											className: "mt-1 h-8 text-[11px] bg-background border-border"
										})] })]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[11px] uppercase font-mono text-muted-foreground",
						children: "Special Notes or Queries (Optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Need cab pickup, bank loan inquiry, boundary stone verification...",
						value: message,
						onChange: (e) => setMessage(e.target.value),
						className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						name: "website",
						value: websiteHoneypot,
						onChange: (e) => setWebsiteHoneypot(e.target.value),
						tabIndex: -1,
						autoComplete: "off",
						"aria-hidden": "true",
						className: "hidden",
						style: { display: "none" }
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "alert",
						className: "flex items-start gap-2.5 text-xs text-destructive bg-destructive/10 border border-destructive/30 p-2.5 rounded-lg animate-in fade-in",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium leading-relaxed",
							children: error
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: submitting,
						className: "w-full h-11 sm:h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer mt-2",
						children: [
							submitting ? "Confirming Visit..." : "Schedule Site Tour",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-2" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-2 text-[10px] text-muted-foreground font-mono",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Instant Confirmation with Managing Director Vishal Singh" })]
					})
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center py-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-16 mx-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-16 rounded-2xl overflow-hidden shadow-glow ring-2 ring-primary/40 bg-[#071510]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png",
								alt: "Galaxy Green",
								width: 64,
								height: 64,
								className: "size-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute -bottom-1 -right-1 size-6 rounded-full bg-emerald-500 text-black grid place-items-center shadow-lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "border-primary text-primary bg-primary/10 font-mono text-xs mb-2",
							children: ["Booking ID: ", confirmedBooking?.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-display uppercase tracking-tight text-foreground",
							children: "Site Visit Confirmed!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground max-w-sm mx-auto mt-1",
							children: [
								"Thank you, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: confirmedBooking?.name }),
								". Our project coordinator will contact you at +91 ",
								confirmedBooking?.phone,
								" to confirm your scheduled site visit."
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface/90 border border-border/80 rounded p-4 text-xs text-left space-y-1.5 font-mono",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Date & Slot:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-foreground font-semibold",
								children: [
									confirmedBooking?.visitDate,
									" (",
									confirmedBooking?.slot,
									")"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Plot Preference:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary font-semibold",
								children: confirmedBooking?.plotPreference
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: openWhatsAppConfirmation,
							className: "w-full sm:flex-1 h-11 uppercase tracking-wider text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white btn-shimmer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4 mr-2" }), " Open In WhatsApp"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: handleClose,
							className: "w-full sm:w-auto h-11 uppercase tracking-wider text-xs border-border",
							children: "Done"
						})]
					})
				]
			})
		})
	});
}
function BrochureModal({ open, onOpenChange }) {
	const [downloading, setDownloading] = (0, import_react.useState)(false);
	const handleDownload = async () => {
		setDownloading(true);
		try {
			const response = await fetch("/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf");
			if (!response.ok) throw new Error("File not found");
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
			toast.success("PDF brochure downloaded successfully!");
		} catch {
			const a = document.createElement("a");
			a.href = "/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			a.download = "Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			a.target = "_blank";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			toast.success("Opening PDF brochure...");
		} finally {
			setDownloading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "w-[calc(100vw-1rem)] sm:w-full max-w-2xl bg-card border-border text-foreground p-4 sm:p-8 max-h-[min(92dvh,92vh)] overflow-y-auto pb-[max(1.25rem,env(safe-area-inset-bottom))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "pr-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 sm:size-12 rounded-xl overflow-hidden shadow-glow ring-1 ring-primary/40 shrink-0 bg-[#071510]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png",
								alt: "Galaxy Green",
								width: 48,
								height: 48,
								className: "size-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 sm:gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "border-primary text-primary bg-primary/10 text-[10px] uppercase font-mono shrink-0",
									children: "Official Prospectus 2026"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground font-mono truncate",
									children: "Phase 1 Master Document"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "text-lg sm:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 leading-snug",
								children: "Galaxy Green Sai Suraksha Nagar"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground mt-1",
						children: "Complete architectural specifications, plot dimension matrix, and legal credentials for Amausi, Lucknow."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3 my-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-primary" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Road Infrastructure"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "40-ft wide grand boulevard and 30-ft internal paver lanes with drainage."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trees, { className: "size-3.5 text-primary" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Green Environment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Manicured central park, flower gardens, tree-lined walking avenues."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram-gold size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-accent" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Immediate Registry"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "100% freehold land with instant Dakhil Kharij (mutation) assurance."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram-gold size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-accent" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Prime Proximity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "5 mins from Chaudhary Charan Singh International Airport (Amausi)."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border rounded overflow-hidden text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface px-4 py-2 font-mono text-[11px] uppercase tracking-wider text-primary font-semibold border-b border-border flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phase 1 Dimension & Pricing Matrix" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground font-normal",
							children: "₹1,199 / Sq Ft"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "divide-y divide-border/60 font-mono",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "600 Sq Ft (20 × 30 ft · Compact)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary font-semibold",
									children: "₹7,19,400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "800 Sq Ft (20 × 40 ft · Standard)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹9,59,200"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,000 Sq Ft (25 × 40 ft · Popular)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary font-semibold",
									children: "₹11,99,000"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,200 Sq Ft (30 × 40 ft · Villa)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹14,38,800"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,500 Sq Ft (30 × 50 ft · Executive)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹17,98,500"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2,000 Sq Ft (40 × 50 ft · Grand Villa)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹23,98,000"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row gap-3 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleDownload,
							disabled: downloading,
							className: "w-full sm:flex-1 h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 mr-2" }), downloading ? "Preparing PDF..." : "Download Full PDF Brochure"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "w-full sm:w-auto inline-flex items-center justify-center h-12 px-4 rounded-md border border-border uppercase tracking-wider text-xs text-muted-foreground hover:text-foreground hover:bg-surface transition-colors font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 mr-1.5" }), "View PDF"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => onOpenChange(false),
							className: "w-full sm:w-auto h-12 uppercase tracking-wider text-xs border-border",
							children: "Close"
						})
					]
				})
			]
		})
	});
}
var Sheet = Dialog$1;
var SheetPortal = DialogPortal$1;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	className: cn("fixed inset-0 z-50 bg-black/85 backdrop-blur-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay$1.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, hideCloseButton = false, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [!hideCloseButton && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent$1.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle$1.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription$1.displayName;
var Tabs = Root2$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var STATUS_VARIANTS = {
	New: "border-primary text-primary bg-primary/10",
	Contacted: "border-amber-400 text-amber-300 bg-amber-400/10",
	"Visit Scheduled": "border-cyan-400 text-cyan-300 bg-cyan-400/10",
	"Site Visit Done": "border-purple-400 text-purple-300 bg-purple-400/10",
	Booked: "border-emerald-400 text-emerald-300 bg-emerald-400/20 font-bold"
};
var PLOT_STATUS_BADGES = {
	Available: "border-primary text-primary bg-primary/10",
	"Fast Selling": "border-amber-400 text-amber-300 bg-amber-400/10",
	Reserved: "border-purple-400 text-purple-300 bg-purple-400/10",
	"Sold Out": "border-destructive text-destructive bg-destructive/10 font-bold"
};
function AdminLeadsDrawer({ open, onOpenChange }) {
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(false);
	const [authToken, setAuthToken] = (0, import_react.useState)("");
	const authTokenRef = (0, import_react.useRef)("");
	const [pinInput, setPinInput] = (0, import_react.useState)("");
	const [pinError, setPinError] = (0, import_react.useState)(false);
	const [verifyingPin, setVerifyingPin] = (0, import_react.useState)(false);
	const [showPin, setShowPin] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		authTokenRef.current = authToken;
	}, [authToken]);
	const [leads, setLeads] = (0, import_react.useState)([]);
	const [loadingLeads, setLoadingLeads] = (0, import_react.useState)(false);
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [plots, setPlots] = (0, import_react.useState)([]);
	const [loadingPlots, setLoadingPlots] = (0, import_react.useState)(false);
	const [showAddPlotForm, setShowAddPlotForm] = (0, import_react.useState)(false);
	const [newPlotNumber, setNewPlotNumber] = (0, import_react.useState)("");
	const [newPlotSize, setNewPlotSize] = (0, import_react.useState)("1000");
	const [newPlotDims, setNewPlotDims] = (0, import_react.useState)("25 × 40 ft");
	const [newPlotFacing, setNewPlotFacing] = (0, import_react.useState)("East");
	const [newPlotRoad, setNewPlotRoad] = (0, import_react.useState)("30 ft Internal");
	const [newPlotRate, setNewPlotRate] = (0, import_react.useState)("1199");
	const [newPlotFeature, setNewPlotFeature] = (0, import_react.useState)("Freehold residential plot with clear title");
	const [editingPlot, setEditingPlot] = (0, import_react.useState)(null);
	const [editPlotNumber, setEditPlotNumber] = (0, import_react.useState)("");
	const [editPlotSize, setEditPlotSize] = (0, import_react.useState)("1000");
	const [editPlotDims, setEditPlotDims] = (0, import_react.useState)("25 × 40 ft");
	const [editPlotFacing, setEditPlotFacing] = (0, import_react.useState)("East");
	const [editPlotRoad, setEditPlotRoad] = (0, import_react.useState)("30 ft Internal");
	const [editPlotRate, setEditPlotRate] = (0, import_react.useState)("1199");
	const [editPlotStatus, setEditPlotStatus] = (0, import_react.useState)("Available");
	const [editPlotFeature, setEditPlotFeature] = (0, import_react.useState)("");
	const [savingPlotEdit, setSavingPlotEdit] = (0, import_react.useState)(false);
	const [galleryPhotos, setGalleryPhotos] = (0, import_react.useState)([]);
	const [loadingGallery, setLoadingGallery] = (0, import_react.useState)(false);
	const [showAddPhotoForm, setShowAddPhotoForm] = (0, import_react.useState)(false);
	const [photoTitle, setPhotoTitle] = (0, import_react.useState)("");
	const [photoCategory, setPhotoCategory] = (0, import_react.useState)("demarcation");
	const [photoSrc, setPhotoSrc] = (0, import_react.useState)("");
	const [photoDescription, setPhotoDescription] = (0, import_react.useState)("");
	const [photoDimensionsLabel, setPhotoDimensionsLabel] = (0, import_react.useState)("");
	const [uploadingPhoto, setUploadingPhoto] = (0, import_react.useState)(false);
	const [newPinInput, setNewPinInput] = (0, import_react.useState)("");
	const [confirmPinInput, setConfirmPinInput] = (0, import_react.useState)("");
	const [savingSettings, setSavingSettings] = (0, import_react.useState)(false);
	const [dbHealth, setDbHealth] = (0, import_react.useState)(null);
	const loadData = (0, import_react.useCallback)(async (tokenToUse) => {
		const activeToken = tokenToUse || authTokenRef.current;
		setLoadingPlots(true);
		setLoadingGallery(true);
		try {
			const [plotsData, photosData, , health] = await Promise.all([
				fetchLivePlots(),
				fetchLiveGalleryPhotos(),
				getAdminConfigFn(),
				checkDbHealthFn().catch(() => ({
					connected: false,
					message: "Offline"
				}))
			]);
			setPlots(plotsData);
			setGalleryPhotos(photosData);
			setDbHealth(health);
			if (activeToken) {
				setLoadingLeads(true);
				const leadsData = await fetchAllLeads(activeToken);
				setLeads(leadsData);
				setLoadingLeads(false);
			}
		} catch (err) {
			console.error(err);
		} finally {
			setLoadingPlots(false);
			setLoadingGallery(false);
			setLoadingLeads(false);
		}
	}, []);
	const handleLogout = (0, import_react.useCallback)(() => {
		setIsAuthenticated(false);
		setAuthToken("");
		authTokenRef.current = "";
		setPinInput("");
		setPinError(false);
		if (typeof window !== "undefined") {
			sessionStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_pin_signed_token");
		}
	}, []);
	const getActiveToken = (0, import_react.useCallback)(() => {
		if (authToken) return authToken;
		if (authTokenRef.current) return authTokenRef.current;
		if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || "";
		return "";
	}, [authToken]);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") {
			sessionStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_pin_signed_token");
		}
		if (!open) {
			setIsAuthenticated(false);
			setAuthToken("");
			authTokenRef.current = "";
			setPinInput("");
			setPinError(false);
		} else {
			setIsAuthenticated(false);
			setAuthToken("");
			authTokenRef.current = "";
			setPinInput("");
			setPinError(false);
			loadData();
		}
	}, [open, loadData]);
	const handlePinSubmit = async (e) => {
		e.preventDefault();
		const clean = pinInput.trim();
		if (!clean) {
			setPinError(true);
			toast.error("Please enter your security password / PIN.");
			return;
		}
		setVerifyingPin(true);
		setPinError(false);
		try {
			const res = await verifyDealerPin(clean);
			if (res?.success && res.token) {
				authTokenRef.current = res.token;
				setAuthToken(res.token);
				setIsAuthenticated(true);
				if (typeof window !== "undefined") sessionStorage.setItem("gg_dealer_token", res.token);
				setPinError(false);
				setPinInput("");
				toast.success("Admin Portal Unlocked Successfully");
				await loadData(res.token);
			} else {
				setPinError(true);
				toast.error(res?.error || "Incorrect Password / PIN. Access Denied.");
			}
		} catch {
			setPinError(true);
			toast.error("Authentication failed. Please check connection.");
		} finally {
			setVerifyingPin(false);
		}
	};
	const handleLeadStatusChange = async (id, newStatus) => {
		if (await updateLeadStatus(id, newStatus, getActiveToken())) {
			setLeads((prev) => prev.map((l) => l.id === id ? {
				...l,
				status: newStatus
			} : l));
			toast.success(`Lead ${id} marked as "${newStatus}"`);
		} else toast.error("Unable to update lead status. Please try again.");
	};
	const handlePlotStatusChange = async (id, newStatus) => {
		setPlots((prev) => prev.map((p) => p.id === id ? {
			...p,
			status: newStatus
		} : p));
		if (await setPlotStatus(id, newStatus, getActiveToken())) {
			window.dispatchEvent(new CustomEvent("plots-updated"));
			toast.success("✓ Plot status auto-saved to database");
		} else toast.error("Unable to update plot status. Please try again.");
	};
	const handleDeletePlot = async (id, number) => {
		if (!confirm(`Are you sure you want to remove Plot ${number} from the live site?`)) return;
		setPlots((prev) => prev.filter((p) => p.id !== id));
		try {
			if (await removePlot(id, getActiveToken())) {
				window.dispatchEvent(new CustomEvent("plots-updated"));
				toast.success(`Plot ${number} deleted.`);
			} else toast.error("Unable to delete plot. Please try again.");
		} catch {
			toast.error("Failed to delete plot");
		}
	};
	const handleAddNewPlot = async (e) => {
		e.preventDefault();
		if (!newPlotNumber.trim()) {
			toast.error("Please enter a plot number");
			return;
		}
		const sizeNum = parseInt(newPlotSize, 10) || 1e3;
		const rateNum = parseInt(newPlotRate, 10) || 1199;
		const created = await addLivePlot({
			number: newPlotNumber.trim().toUpperCase(),
			sizeSqFt: sizeNum,
			dimensions: newPlotDims.trim(),
			facing: newPlotFacing,
			roadWidth: newPlotRoad.trim(),
			ratePerSqFt: rateNum,
			status: "Available",
			feature: newPlotFeature.trim()
		}, getActiveToken());
		if (created) {
			setPlots((prev) => [...prev, created]);
			window.dispatchEvent(new CustomEvent("plots-updated"));
			setShowAddPlotForm(false);
			setNewPlotNumber("");
			toast.success(`Plot ${created.number} added to live website!`);
		} else toast.error("Unable to add plot. Please verify plot information and try again.");
	};
	const handleOpenEditPlot = (plot) => {
		setEditingPlot(plot);
		setEditPlotNumber(plot.number);
		setEditPlotSize(String(plot.sizeSqFt));
		setEditPlotDims(plot.dimensions);
		setEditPlotFacing(plot.facing);
		setEditPlotRoad(plot.roadWidth);
		setEditPlotRate(String(plot.ratePerSqFt));
		setEditPlotStatus(plot.status);
		setEditPlotFeature(plot.feature);
	};
	const handleSavePlotEdit = async (e) => {
		if (e) e.preventDefault();
		if (!editingPlot) return;
		if (!editPlotNumber.trim()) {
			toast.error("Plot number cannot be empty.");
			return;
		}
		setSavingPlotEdit(true);
		try {
			const updates = {
				number: editPlotNumber.trim().toUpperCase(),
				sizeSqFt: parseInt(editPlotSize, 10) || editingPlot.sizeSqFt,
				dimensions: editPlotDims.trim(),
				facing: editPlotFacing,
				roadWidth: editPlotRoad.trim(),
				ratePerSqFt: parseInt(editPlotRate, 10) || editingPlot.ratePerSqFt,
				status: editPlotStatus,
				feature: editPlotFeature.trim()
			};
			const res = await updateLivePlot(editingPlot.id, updates, getActiveToken());
			if (res) {
				setPlots((prev) => prev.map((p) => p.id === editingPlot.id ? {
					...p,
					...res
				} : p));
				window.dispatchEvent(new CustomEvent("plots-updated"));
				setEditingPlot(null);
				toast.success(`✓ Plot ${res.number} auto-saved to database!`, { duration: 4e3 });
			} else toast.error("Unable to update plot. Please try again.");
		} catch {
			toast.error("Failed to save plot updates to database.");
		} finally {
			setSavingPlotEdit(false);
		}
	};
	const handlePhotoFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (file.size > 15728640) {
			toast.error("Image file is too large. Please select a photo under 15MB.");
			return;
		}
		const reader = new FileReader();
		reader.onload = (event) => {
			const rawDataUrl = event.target?.result;
			if (!rawDataUrl) return;
			const img = new Image();
			img.onload = () => {
				try {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 1600;
					const MAX_HEIGHT = 1600;
					let { width, height } = img;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height = Math.round(height * MAX_WIDTH / width);
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width = Math.round(width * MAX_HEIGHT / height);
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					const ctx = canvas.getContext("2d");
					if (ctx) {
						ctx.drawImage(img, 0, 0, width, height);
						const compressed = canvas.toDataURL("image/jpeg", .85);
						setPhotoSrc(compressed);
					} else setPhotoSrc(rawDataUrl);
				} catch {
					setPhotoSrc(rawDataUrl);
				}
			};
			img.onerror = () => {
				setPhotoSrc(rawDataUrl);
			};
			img.src = rawDataUrl;
		};
		reader.readAsDataURL(file);
	};
	const handleUploadPhoto = async (e) => {
		e.preventDefault();
		if (!photoSrc.trim()) {
			toast.error("Please upload an image file or provide an image URL.");
			return;
		}
		if (!photoTitle.trim()) {
			toast.error("Please enter a title for the photo.");
			return;
		}
		setUploadingPhoto(true);
		try {
			const created = await uploadLivePhoto({
				src: photoSrc,
				title: photoTitle.trim(),
				category: photoCategory,
				categoryLabel: {
					demarcation: "Demarcation & Registry Ready",
					roads: "Internal Roads & Lighting",
					panorama: "Township Horizon",
					construction: "Civil Engineering"
				}[photoCategory] || "Actual Site",
				tag: photoCategory === "demarcation" ? "Boundary Pillars" : "Live Update",
				description: photoDescription.trim() || "Uploaded directly via Dealer Portal.",
				dimensionsLabel: photoDimensionsLabel.trim() || "Actual Site Progress"
			}, getActiveToken());
			if (created) {
				setGalleryPhotos((prev) => [created, ...prev]);
				setShowAddPhotoForm(false);
				setPhotoSrc("");
				setPhotoTitle("");
				setPhotoDescription("");
				setPhotoDimensionsLabel("");
				toast.success("Site photo published to live website!");
			} else toast.error("Unable to upload photo. Please try again.");
		} catch {
			toast.error("Error uploading photo. Please try again.");
		} finally {
			setUploadingPhoto(false);
		}
	};
	const handleDeletePhoto = async (id, title) => {
		if (!confirm(`Are you sure you want to remove "${title}" from the live site gallery?`)) return;
		setGalleryPhotos((prev) => prev.filter((p) => p.id !== id));
		try {
			if (await removeLivePhoto(id, getActiveToken())) toast.success("Photo removed from live gallery.");
			else toast.error("Unable to remove photo. Please try again.");
		} catch {
			toast.error("Failed to remove photo");
		}
	};
	const handleSaveSettings = async (e) => {
		e.preventDefault();
		const cleanNewPin = newPinInput.trim();
		if (!cleanNewPin) {
			toast.info("No new password entered.");
			return;
		}
		if (cleanNewPin !== confirmPinInput.trim()) {
			toast.error("New Password and Confirm Password do not match.");
			return;
		}
		if (cleanNewPin.length < 4 || cleanNewPin.length > 32) {
			toast.error("Password / PIN must be between 4 and 32 characters.");
			return;
		}
		if (!confirm("Confirm password update: Are you sure you want to change the security password? This will be permanently saved into your MySQL database and all active sessions will be logged out.")) return;
		setSavingSettings(true);
		try {
			const res = await updateAdminConfigFn({ data: {
				token: authToken || authTokenRef.current || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || "" : "") || void 0,
				newPin: cleanNewPin
			} });
			const typedRes = res;
			if (typedRes?.success) {
				if (typedRes.signedPinToken) setClientPinToken(typedRes.signedPinToken);
				handleLogout();
				setNewPinInput("");
				setConfirmPinInput("");
				toast.success("Security Password updated in MySQL database! All sessions logged out across all devices. Please enter your new password to unlock.", { duration: 7e3 });
			} else toast.error(res?.error || "Failed to update security password in database.");
		} catch {
			toast.error("Failed to save settings. Please verify database connection.");
		} finally {
			setSavingSettings(false);
		}
	};
	const filteredLeads = leads.filter((lead) => {
		const matchesStatus = filterStatus === "all" || lead.status === filterStatus;
		const matchesQuery = lead.name.toLowerCase().includes(searchQuery.toLowerCase()) || lead.phone.includes(searchQuery) || lead.plotPreference.toLowerCase().includes(searchQuery.toLowerCase());
		return matchesStatus && matchesQuery;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
			side: "right",
			hideCloseButton: true,
			className: "w-full sm:max-w-3xl bg-[#0a1410] border-l border-border/80 p-0 flex flex-col h-full text-foreground overflow-hidden shadow-2xl",
			children: !isAuthenticated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full bg-[#0a1410]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-6 py-4 border-b border-border/80 bg-[#0c1612] shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-wider text-muted-foreground font-mono",
							children: "Admin Security Access"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						className: "size-9 rounded-lg border border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/50 text-muted-foreground hover:text-foreground flex items-center justify-center transition-all active:scale-95",
						title: "Close",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0a1410]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-20 rounded-2xl overflow-hidden shadow-glow ring-2 ring-primary/40 bg-[#071510]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/galaxy-green-emblem.png",
									alt: "Galaxy Green Logo",
									width: 80,
									height: 80,
									className: "size-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -bottom-1 -right-1 size-7 rounded-full bg-surface border border-accent/60 grid place-items-center shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 text-accent" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-display uppercase tracking-tight text-foreground",
							children: "Admin Management Portal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1 max-w-sm",
							children: "Enter your secure database password to manage customer leads, live plot inventory, and site configuration."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handlePinSubmit,
							className: "mt-6 w-full max-w-xs space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: showPin ? "text" : "password",
										maxLength: 32,
										autoFocus: true,
										placeholder: "Enter Security Password / PIN",
										value: pinInput,
										onChange: (e) => setPinInput(e.target.value),
										className: `h-12 text-center text-base tracking-widest font-mono bg-[#080f0c] border pr-10 ${pinError ? "border-destructive text-destructive" : "border-border"}`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPin(!showPin),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1",
										"aria-label": showPin ? "Hide Password" : "Show Password",
										children: showPin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									disabled: verifyingPin,
									className: "w-full h-11 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 btn-shimmer rounded-lg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 mr-2" }),
										" ",
										verifyingPin ? "Verifying with Database..." : "Unlock Portal"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground font-mono flex items-center justify-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 text-emerald-400" }), " Locked by default • End-to-end encrypted"]
								})
							]
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full overflow-hidden bg-[#0a1410]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
					className: "px-4 sm:px-6 py-3.5 sm:py-4 border-b border-border/80 bg-[#0c1612] shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 sm:gap-3 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 sm:size-11 rounded-xl overflow-hidden shadow-glow ring-1 ring-primary/40 shrink-0 bg-[#071510]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/galaxy-green-emblem.png",
									alt: "Galaxy Green Logo",
									width: 44,
									height: 44,
									className: "size-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 sm:gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] sm:text-xs uppercase tracking-widest text-primary font-mono font-medium truncate",
										children: "Admin Operations Portal"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
									className: "text-base sm:text-xl lg:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 truncate",
									children: "Galaxy Green Control Hub"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 sm:gap-2.5 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => {
									handleLogout();
									toast.info("Admin Portal Locked & Logged Out");
								},
								className: "h-8 sm:h-9 px-2.5 sm:px-3.5 text-[11px] sm:text-xs border-amber-500/40 text-amber-300 hover:bg-amber-500/10 font-mono rounded-lg transition-all",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 sm:mr-1.5 text-amber-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Lock & Log Out"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sm:hidden",
										children: "Lock"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									onOpenChange(false);
								},
								className: "size-8 sm:size-9 rounded-lg border border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/50 text-muted-foreground hover:text-foreground flex items-center justify-center transition-all active:scale-95 shrink-0",
								title: "Close Admin Portal",
								"aria-label": "Close Admin Portal",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					defaultValue: "leads",
					className: "flex-1 flex flex-col overflow-hidden bg-[#0a1410]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 sm:px-6 py-2.5 sm:py-3 border-b border-border/80 bg-[#0c1612] shrink-0 overflow-x-auto scrollbar-none",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
								className: "bg-[#080f0c] border border-border/80 p-1 rounded-lg h-auto flex flex-nowrap gap-1 min-w-max sm:min-w-0 sm:w-full",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "leads",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Inquiries (",
											leads.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "plots",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Plots (",
											plots.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "gallery",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Photos (",
											galleryPhotos.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "settings",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 mr-1.5 shrink-0" }), " PIN & DB"]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "leads",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6 border-b border-border/80 bg-[#0c1612] space-y-4 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-4 gap-2.5 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase text-muted-foreground block font-mono",
												children: "Total"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-lg font-display text-primary",
												children: leads.length
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase text-muted-foreground block font-mono",
												children: "New"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-lg font-display text-amber-400",
												children: leads.filter((l) => l.status === "New").length
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase text-muted-foreground block font-mono",
												children: "Visits"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-lg font-display text-cyan-400",
												children: leads.filter((l) => l.status === "Visit Scheduled").length
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase text-muted-foreground block font-mono",
												children: "Booked"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-lg font-display text-emerald-400",
												children: leads.filter((l) => l.status === "Booked").length
											})]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Search buyer name, mobile, plot...",
											value: searchQuery,
											onChange: (e) => setSearchQuery(e.target.value),
											className: "w-full h-10 pl-9 pr-3 text-xs rounded-lg bg-[#080f0c] border border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: filterStatus,
											onChange: (e) => setFilterStatus(e.target.value),
											className: "h-10 px-3 text-xs rounded-lg bg-[#080f0c] border border-border/80 text-foreground focus:border-primary focus:outline-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "all",
													children: "All Statuses"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "New",
													children: "New"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Contacted",
													children: "Contacted"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Visit Scheduled",
													children: "Visit Scheduled"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Site Visit Done",
													children: "Site Visit Done"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Booked",
													children: "Booked"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											onClick: () => exportLeadsToCsv(leads),
											className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }), " Export CSV"]
										})]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 overflow-y-auto p-6 space-y-3 bg-[#0a1410]",
								children: filteredLeads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-center py-16 text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm",
										children: "No inquiries match your criteria."
									})
								}) : filteredLeads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "bg-[#0e1c16] border border-border/80 hover:border-primary/50 transition-all rounded-xl p-4 space-y-3 shadow-sm card-architectural",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono text-[10px] text-muted-foreground uppercase",
														children: lead.id
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-muted-foreground",
														children: "·"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-muted-foreground",
														children: new Date(lead.createdAt).toLocaleDateString("en-IN", {
															day: "numeric",
															month: "short",
															hour: "2-digit",
															minute: "2-digit"
														})
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "font-display font-semibold text-base uppercase text-foreground mt-0.5 flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-primary" }),
													" ",
													lead.name
												]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: `text-[10px] uppercase font-semibold px-2 py-0.5 ${STATUS_VARIANTS[lead.status] || ""}`,
												children: lead.status
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-background/50 p-2.5 rounded border border-border/40 font-mono",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[10px] block uppercase",
													children: "Plot"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-primary",
													children: lead.plotPreference
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[10px] block uppercase",
													children: "Visit Schedule"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													lead.visitDate || "Not chosen",
													" (",
													lead.slot,
													")"
												] })] }),
												lead.message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "col-span-full text-muted-foreground text-[11px] italic bg-surface/80 p-2 rounded",
													children: [
														"\"",
														lead.message,
														"\""
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-border/40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													asChild: true,
													size: "sm",
													variant: "outline",
													className: "h-8 px-2.5 text-xs text-primary border-primary/30",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
														href: `tel:+91${lead.phone}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 mr-1" }), " Call"]
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													asChild: true,
													size: "sm",
													className: "h-8 px-2.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-white",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
														href: `https://wa.me/91${lead.phone}?text=${encodeURIComponent(`Hello ${lead.name}, this is Vishal Singh following up on your Galaxy Green Sai Suraksha Nagar inquiry (${lead.id}).`)}`,
														target: "_blank",
														rel: "noreferrer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3 mr-1" }), " WhatsApp"]
													})
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Status:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: lead.status,
													onChange: (e) => handleLeadStatusChange(lead.id, e.target.value),
													className: "h-7 px-2 text-[11px] font-medium rounded bg-background border border-border text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "New",
															children: "New"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Contacted",
															children: "Contacted"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Visit Scheduled",
															children: "Visit Scheduled"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Site Visit Done",
															children: "Site Visit Done"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Booked",
															children: "Booked"
														})
													]
												})]
											})]
										})
									]
								}, lead.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "plots",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 border-b border-border/80 bg-[#0c1612] flex items-center justify-between shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-display uppercase text-lg text-foreground",
										children: "Live Township Inventory"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Changes made here update the public website & interactive matrix instantly."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => setShowAddPlotForm((prev) => !prev),
										className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5 mr-1.5" }), showAddPlotForm ? "Close Form" : "+ Add Real Plot"]
									})]
								}),
								showAddPlotForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAddNewPlot,
									className: "p-6 bg-[#0c1612] border-b border-border/80 space-y-4 shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "text-xs uppercase font-mono tracking-wider text-primary font-semibold",
											children: "Add New Plot to Website"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Plot Number"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. E-501",
													value: newPlotNumber,
													onChange: (e) => setNewPlotNumber(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Area (Sq Ft)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													placeholder: "1000",
													value: newPlotSize,
													onChange: (e) => setNewPlotSize(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Dimensions"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "25 × 40 ft",
													value: newPlotDims,
													onChange: (e) => setNewPlotDims(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Rate / Sq Ft (₹)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													placeholder: "1199",
													value: newPlotRate,
													onChange: (e) => setNewPlotRate(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Facing"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: newPlotFacing,
													onChange: (e) => setNewPlotFacing(e.target.value),
													className: "mt-1 h-10 w-full px-2 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "East",
															children: "East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North",
															children: "North"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Park Facing",
															children: "Park Facing"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Boulevard Corner",
															children: "Boulevard Corner"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "West",
															children: "West"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South",
															children: "South"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Road Width"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "30 ft Internal",
													value: newPlotRoad,
													onChange: (e) => setNewPlotRoad(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "col-span-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] uppercase font-mono text-muted-foreground",
														children: "Plot Highlights"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. Park facing with direct morning sun",
														value: newPlotFeature,
														onChange: (e) => setNewPlotFeature(e.target.value),
														className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											size: "sm",
											className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg",
											children: "Publish Plot to Website"
										})
									]
								}),
								editingPlot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSavePlotEdit,
									className: "p-6 border-b-2 border-primary/50 bg-[#0c2219] space-y-4 shrink-0 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pb-2 border-b border-primary/20",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
													className: "font-display uppercase text-sm font-semibold text-primary",
													children: ["Modifying Plot ", editingPlot.number]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												size: "sm",
												variant: "ghost",
												onClick: () => setEditingPlot(null),
												className: "h-7 text-xs text-muted-foreground hover:text-foreground",
												children: "Cancel"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Plot Number *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotNumber,
													onChange: (e) => setEditPlotNumber(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Size (Sq Ft) *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: editPlotSize,
													onChange: (e) => setEditPlotSize(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Dimensions *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotDims,
													onChange: (e) => setEditPlotDims(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Facing Direction"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: editPlotFacing,
													onChange: (e) => setEditPlotFacing(e.target.value),
													className: "mt-1 w-full h-9 px-3 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "East",
															children: "East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "West",
															children: "West"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North",
															children: "North"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South",
															children: "South"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North-East",
															children: "North-East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South-East",
															children: "South-East"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Road Width *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotRoad,
													onChange: (e) => setEditPlotRoad(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Rate (₹ / Sq Ft) *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: editPlotRate,
													onChange: (e) => setEditPlotRate(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Status"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: editPlotStatus,
													onChange: (e) => setEditPlotStatus(e.target.value),
													className: "mt-1 w-full h-9 px-3 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Available",
															children: "Available"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Fast Selling",
															children: "Fast Selling"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Reserved",
															children: "Reserved"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Sold Out",
															children: "Sold Out"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Plot Highlights"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotFeature,
													onChange: (e) => setEditPlotFeature(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#081812] border border-emerald-500/40 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-emerald-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Safe Database Commit:" }), " Changes write directly to MySQL database ledger and persist permanently."] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0",
												children: "Auto-Save Active"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												size: "sm",
												disabled: savingPlotEdit,
												className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg shadow-glow flex items-center gap-2",
												children: savingPlotEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 animate-spin mr-1.5" }), "Saving to Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 mr-1.5" }), "Save Changes & Auto-Commit"] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "outline",
												size: "sm",
												disabled: savingPlotEdit,
												onClick: () => setEditingPlot(null),
												className: "h-10 px-4 text-xs rounded-lg",
												children: "Cancel"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-6 space-y-3 bg-[#0a1410]",
									children: plots.map((plot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#0e1c16] border border-border/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-sm card-architectural",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
														className: "font-display font-semibold text-base text-foreground",
														children: ["Plot ", plot.number]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono text-primary font-medium",
														children: [plot.sizeSqFt.toLocaleString(), " Sq Ft"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-muted-foreground font-mono",
														children: [
															"(",
															plot.dimensions,
															")"
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-muted-foreground text-[11px]",
												children: [
													"Facing: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: plot.facing }),
													" · Road:",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: plot.roadWidth }),
													" · Rate:",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
														"₹",
														plot.ratePerSqFt,
														"/sq ft"
													] })
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: plot.status,
													onChange: (e) => handlePlotStatusChange(plot.id, e.target.value),
													className: `h-8 px-2 text-xs font-semibold rounded-lg border ${PLOT_STATUS_BADGES[plot.status] || ""}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Available",
															children: "Available"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Fast Selling",
															children: "Fast Selling"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Reserved",
															children: "Reserved"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Sold Out",
															children: "Sold Out"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													onClick: () => handleOpenEditPlot(plot),
													className: "size-8 text-primary hover:bg-primary/10 rounded-lg",
													title: `Edit Plot ${plot.number}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													onClick: () => handleDeletePlot(plot.id, plot.number),
													className: "size-8 text-destructive hover:bg-destructive/10 rounded-lg",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})
											]
										})]
									}, plot.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "gallery",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 border-b border-border/80 bg-[#0c1612] flex items-center justify-between shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-display uppercase text-lg text-foreground",
										children: "Site Development Gallery"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Upload actual ground photos or remove any photo. Live-syncs directly to the public site gallery."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => setShowAddPhotoForm((prev) => !prev),
										className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5 mr-1.5" }), showAddPhotoForm ? "Close Form" : "+ Upload Photo"]
									})]
								}),
								showAddPhotoForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleUploadPhoto,
									className: "p-6 border-b border-border/80 bg-[#0e1c16] space-y-4 shrink-0 shadow-inner",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pb-2 border-b border-border/60",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "font-display uppercase text-xs font-semibold text-primary flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }), " Add Site Progress Photo"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-muted-foreground font-mono",
												children: "Direct upload or web image URL"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 md:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Upload From Device (Phone / Laptop)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "file",
														accept: "image/*",
														onChange: handlePhotoFileChange,
														className: "mt-1 block w-full text-xs text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-primary/20 file:text-primary hover:file:bg-primary/30 cursor-pointer bg-[#080f0c] p-2 border border-border/80 rounded-lg"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Or Paste Direct Image URL"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "https://images.unsplash.com/... or data:image/...",
														value: photoSrc,
														onChange: (e) => setPhotoSrc(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg font-mono text-[11px]"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Photo Title *"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. 40 Ft Blacktop Avenue & Storm Water Line",
														value: photoTitle,
														onChange: (e) => setPhotoTitle(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
														required: true
													})] })
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
															className: "text-[10px] text-muted-foreground uppercase font-mono",
															children: "Category"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
															value: photoCategory,
															onChange: (e) => setPhotoCategory(e.target.value),
															className: "mt-1 w-full h-9 px-2 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "demarcation",
																	children: "Demarcation & Registry"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "roads",
																	children: "Internal Roads & Lighting"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "panorama",
																	children: "Township Horizon"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "construction",
																	children: "Civil Engineering"
																})
															]
														})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
															className: "text-[10px] text-muted-foreground uppercase font-mono",
															children: "Progress / Metric Tag"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															placeholder: "e.g. 40 Ft Road Completion",
															value: photoDimensionsLabel,
															onChange: (e) => setPhotoDimensionsLabel(e.target.value),
															className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
														})] })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Description / Caption"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. Concrete curb installation completed with LED illumination conduits.",
														value: photoDescription,
														onChange: (e) => setPhotoDescription(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
													})] }),
													photoSrc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 p-2 bg-[#080f0c] border border-border/80 rounded-lg",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
																src: photoSrc,
																alt: "Preview",
																className: "size-12 rounded object-cover border border-border/60"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex-1 min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "text-xs font-medium text-foreground truncate",
																	children: "Image ready to publish"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "text-[10px] text-muted-foreground font-mono",
																	children: "Will save to persistent database"
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																type: "button",
																variant: "ghost",
																size: "sm",
																onClick: () => setPhotoSrc(""),
																className: "text-xs h-7 text-destructive hover:bg-destructive/10",
																children: "Clear"
															})
														]
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: uploadingPhoto || !photoSrc.trim() || !photoTitle.trim(),
												size: "sm",
												className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg",
												children: uploadingPhoto ? "Publishing Photo..." : "Publish Photo to Live Site"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "outline",
												size: "sm",
												onClick: () => setShowAddPhotoForm(false),
												className: "h-10 px-4 text-xs rounded-lg",
												children: "Cancel"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-6 space-y-4 bg-[#0a1410]",
									children: galleryPhotos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center py-16 px-4 bg-[#0e1c16] rounded-xl border border-dashed border-border/80 space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram size-12 mx-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-6 text-muted-foreground" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
												className: "font-display uppercase text-sm text-foreground",
												children: "No Site Photos Uploaded Yet"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground max-w-sm mx-auto",
												children: "Click \"+ Upload Photo\" above to upload actual development photos from your device or via direct image link."
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
										children: galleryPhotos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] border border-border/80 rounded-xl overflow-hidden shadow-sm card-architectural flex flex-col justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative aspect-[16/10] bg-[#080f0c] overflow-hidden group",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: photo.src,
													alt: photo.title,
													className: "w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "absolute top-2 left-2 flex flex-wrap gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-black/70 backdrop-blur-md text-emerald-400 border border-emerald-500/30",
														children: photo.categoryLabel || photo.category
													}), photo.tag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-primary/80 backdrop-blur-md text-primary-foreground",
														children: photo.tag
													})]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-4 space-y-2 flex-1 flex flex-col justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
															className: "font-display font-semibold text-sm text-foreground leading-snug line-clamp-1",
															children: photo.title
														}),
														photo.dimensionsLabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] font-mono text-primary font-medium",
															children: photo.dimensionsLabel
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-muted-foreground line-clamp-2 leading-relaxed",
															children: photo.description
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "pt-3 border-t border-border/60 flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] font-mono text-muted-foreground truncate",
														children: ["ID: ", photo.id]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "ghost",
														onClick: () => handleDeletePhoto(photo.id, photo.title),
														className: "h-8 px-2.5 text-xs text-destructive hover:bg-destructive/10 rounded-lg flex items-center gap-1.5",
														title: "Remove this photo from live website",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delete Photo" })]
													})]
												})]
											})]
										}, photo.id))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "settings",
							className: "flex-1 overflow-y-auto p-6 space-y-6 m-0 bg-[#0a1410]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSaveSettings,
								className: "space-y-6 max-w-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-6 bg-[#0e1c16] border border-border/80 rounded-xl space-y-4 shadow-sm card-architectural",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "icon-monogram size-9",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4 text-emerald-400" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
														className: "font-display uppercase text-sm font-semibold text-foreground",
														children: "MySQL Database Engine"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground font-mono",
														children: dbHealth?.connected ? "Relational MySQL database connected & synchronized" : "HMAC-SHA256 Encrypted Session & Local Sync · Cloud MySQL Ready"
													})] })]
												}), dbHealth?.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-1 rounded-full text-[10px] font-mono border border-emerald-500/40 text-emerald-400 bg-emerald-950/40 flex items-center gap-1.5 shrink-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Online & Active"]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-1 rounded-full text-[10px] font-mono border border-emerald-500/40 text-emerald-400 bg-emerald-950/40 flex items-center gap-1.5 shrink-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Cloud Storage Active"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-lg bg-[#081510] border border-emerald-500/30 text-[11px] text-emerald-300/90 leading-relaxed flex items-start gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
															className: "block text-emerald-200 font-semibold",
															children: dbHealth?.connected ? "Persistent Relational Database Active" : "Cryptographic Cloud Storage Synchronized"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-muted-foreground block",
															children: dbHealth?.connected ? "All plot availability updates, dealer security PINs, and customer leads are saved directly to your MySQL database." : "Your security PIN, plot availability, and customer inquiries are encrypted and automatically synchronized."
														}),
														!dbHealth?.connected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
															className: "mt-2 text-[10px] text-muted-foreground cursor-pointer group",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
																className: "font-mono text-emerald-400/90 hover:underline inline-flex items-center gap-1",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "How to connect external cloud MySQL (optional)" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "mt-2 p-2.5 rounded bg-black/40 border border-border/60 font-mono text-[10px] space-y-1 text-muted-foreground",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "To configure MySQL database credentials, update your server .env or cPanel Node.js application environment:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "text-white bg-black/80 p-1.5 rounded border border-white/10 select-all",
																	children: "DATABASE_URL=mysql://user:password@localhost:3306/galaxy_green"
																})]
															})]
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted-foreground leading-relaxed",
												children: [
													"Every customer inquiry and booked site visit is managed in your secure pipeline (",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
														className: "text-primary font-mono text-[11px]",
														children: "galaxy_green.inquiries"
													}),
													"). You have 100% data ownership with no recurring fees, API quotas, or third-party locking."
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Stored Inquiries"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-base font-display text-primary",
															children: [leads.length, " Records"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Active Plots"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-base font-display text-emerald-400",
															children: [plots.length, " Units"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60 col-span-2 sm:col-span-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Session Security"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-xs font-mono text-foreground flex items-center gap-1 mt-0.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3 text-emerald-400" }), " HMAC-SHA256"]
														})]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Need a spreadsheet for Excel, Numbers, or offline records?" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													type: "button",
													size: "sm",
													onClick: () => exportLeadsToCsv(leads),
													disabled: leads.length === 0,
													className: "h-9 px-4 bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-semibold uppercase btn-shimmer rounded-lg shrink-0",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }),
														" Download Full CSV (",
														leads.length,
														")"
													]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-6 bg-[#0e1c16] border border-border/80 rounded-xl space-y-3.5 shadow-sm card-architectural",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "icon-monogram-gold size-9",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 text-accent" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
													className: "font-display uppercase text-sm font-semibold text-foreground",
													children: "Change Admin Security Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-muted-foreground font-mono",
													children: [
														"Bcrypt hashed authentication stored directly in MySQL (",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
															className: "text-primary",
															children: "admin_config.dealer_pin"
														}),
														")"
													]
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Set a new private security password or PIN (4-32 characters). Changing your password will immediately update the database, invalidate all active sessions, and log out all devices across your network. In the future, you must log in using the new password only."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md pt-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "New Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "password",
													maxLength: 32,
													placeholder: "Enter new password",
													value: newPinInput,
													onChange: (e) => setNewPinInput(e.target.value),
													className: "mt-1.5 h-11 text-center font-mono text-base bg-[#080f0c] border-border/80 tracking-widest rounded-lg"
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Confirm New Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "password",
													maxLength: 32,
													placeholder: "Confirm new password",
													value: confirmPinInput,
													onChange: (e) => setConfirmPinInput(e.target.value),
													className: "mt-1.5 h-11 text-center font-mono text-base bg-[#080f0c] border-border/80 tracking-widest rounded-lg"
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-muted-foreground italic",
												children: "Leave blank to keep your current security password unchanged."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 bg-[#081812] border border-emerald-500/40 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-emerald-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Safe Database Persistence:" }), " Password changes are encrypted with bcrypt and stored in MySQL."] })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0",
													children: "Bcrypt Hash Encrypted"
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										disabled: savingSettings,
										className: "h-12 px-8 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90 btn-shimmer rounded-lg shadow-glow flex items-center gap-2",
										children: savingSettings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin mr-1.5" }), "Saving to Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 mr-1.5" }), "Save Changes & Remember in Database"] })
									})
								]
							})
						})
					]
				})]
			})
		})
	});
}
function LegalTrustBadge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-primary/30 bg-card rounded-lg p-6 sm:p-8 relative overflow-hidden shadow-glow",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[10px] uppercase font-mono tracking-widest text-primary font-semibold flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Buyer Security & Title Assurance"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-display uppercase tracking-tight text-foreground mt-1",
				children: "Buy Land With Complete Peace of Mind"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase text-muted-foreground block font-mono",
							children: "Partner Banks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-xs text-foreground font-mono",
							children: "SBI · HDFC · PNB · ICICI"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-8 w-px bg-border hidden sm:block" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-primary/10 border border-primary/30 px-3 py-1.5 rounded text-xs text-primary font-mono font-semibold",
						children: "Up to 80% Financing"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6",
			children: [
				{
					icon: FileCheck,
					title: "100% Freehold Land",
					desc: "Clear individual registry with mutation (Dakhil Kharij) guarantee."
				},
				{
					icon: ShieldCheck,
					title: "Verified Title Deed",
					desc: "Clear legal search report & zero encumbrance certification."
				},
				{
					icon: Landmark,
					title: "Nationalized Bank Loans",
					desc: "Pre-approved plot purchase & home construction loans from SBI, HDFC & PNB."
				},
				{
					icon: Award,
					title: "Instant Possession",
					desc: "Demarcated on-ground boundary stones installed ready for immediate construction."
				}
			].map((item) => {
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group space-y-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "icon-monogram size-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4.5 transition-transform duration-300 group-hover:scale-110" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-display text-sm uppercase text-foreground font-semibold tracking-tight group-hover:text-primary transition-colors",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground leading-relaxed",
							children: item.desc
						})
					]
				}, item.title);
			})
		})]
	});
}
var PHONE_NUMBER = "919044412642";
function MyBookingsDrawer({ onOpenVisitModal }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [bookings, setBookings] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setBookings(getLocalBookings());
		return subscribeToBookings((updated) => {
			setBookings(updated);
		});
	}, []);
	const handleDelete = (id, e) => {
		e.stopPropagation();
		const updated = removeLocalBooking(id);
		setBookings(updated);
		toast.info("Booking removed from device memory.");
	};
	const formatDateLabel = (isoOrDate) => {
		if (!isoOrDate) return "Flexible / To be coordinated";
		try {
			const parts = isoOrDate.split("T")[0].split("-");
			if (parts.length === 3) return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)).toLocaleDateString("en-IN", {
				weekday: "short",
				day: "numeric",
				month: "short",
				year: "numeric"
			});
			return isoOrDate;
		} catch {
			return isoOrDate;
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed bottom-4 left-4 sm:bottom-6 sm:left-6 mb-[env(safe-area-inset-bottom,0px)] ml-[env(safe-area-inset-left,0px)] z-40 transition-all duration-300",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen(true),
			className: "group relative flex items-center gap-2 rounded-full border border-primary/50 bg-card/95 py-2 px-3.5 sm:px-4 shadow-luxury backdrop-blur-xl ring-1 ring-white/10 hover:border-primary hover:shadow-[0_0_25px_rgba(16,185,129,0.35)] hover:scale-105 active:scale-95 transition-all text-foreground",
			"aria-label": "View My Bookings",
			title: "My Bookings (Cached on this device)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-4 sm:size-4.5 text-primary group-hover:text-emerald-300 transition-colors" }), bookings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute -top-1 -right-1 flex h-2 w-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-emerald-500" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs font-semibold uppercase tracking-wider text-foreground",
					children: "My Bookings"
				}),
				bookings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-5 rounded-full bg-primary text-primary-foreground font-mono text-[10px] font-bold grid place-items-center shadow-sm",
					children: bookings.length
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-mono text-muted-foreground hidden xs:inline",
					children: "(0)"
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md sm:max-w-lg p-5 sm:p-6 bg-card border-border shadow-2xl rounded-2xl max-h-[85vh] flex flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
					className: "space-y-1.5 pb-3 border-b border-border/70 text-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 rounded-lg bg-primary/10 border border-primary/30 text-primary grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "font-display text-lg uppercase tracking-tight text-foreground",
								children: "My Scheduled Bookings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] font-mono text-muted-foreground",
								children: [
									"Private cache on this device (",
									bookings.length,
									" ",
									bookings.length === 1 ? "entry" : "entries",
									")"
								]
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "border-emerald-500/40 text-emerald-400 text-[10px] font-mono",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3 mr-1" }), " On-Device"]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto py-3 space-y-3.5 pr-1",
					children: bookings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-10 px-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-14 rounded-full bg-surface border border-border mx-auto grid place-items-center text-muted-foreground/60",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-7" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-display text-base uppercase text-foreground",
								children: "No Bookings Found On This Device"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground font-mono leading-relaxed max-w-sm mx-auto",
								children: "When you schedule a site tour or submit a booking inquiry, your visit date, chosen time slot, and plot preferences will be securely saved right here in your browser cache."
							}),
							onOpenVisitModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: () => {
									setOpen(false);
									onOpenVisitModal();
								},
								className: "mt-2 text-xs uppercase font-mono tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
								children: "Schedule A Visit Now →"
							})
						]
					}) : bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-primary/30 bg-surface/90 p-4 space-y-3 shadow-sm hover:border-primary/60 transition-all text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2 border-b border-border/60 pb-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-mono font-bold text-primary",
										children: ["#", b.id]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold uppercase",
										children: "Confirmed"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] font-mono text-muted-foreground mt-0.5",
									children: ["Booked: ", new Date(b.bookedAt).toLocaleString("en-IN", {
										day: "numeric",
										month: "short",
										hour: "2-digit",
										minute: "2-digit"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: (e) => handleDelete(b.id, e),
									className: "size-7 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 grid place-items-center transition-colors",
									title: "Remove from this device",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: formatDateLabel(b.visitDate)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate font-semibold",
											children: b.slot || "Morning (10:00 AM)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-muted-foreground sm:col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5 text-cyan-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground truncate",
											children: b.plotPreference
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-muted-foreground sm:col-span-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-muted-foreground shrink-0" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-foreground truncate",
												children: b.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "·"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 text-muted-foreground shrink-0" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-foreground truncate",
												children: b.phone
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pt-1 border-t border-border/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									className: "flex-1 h-8 text-[11px] font-mono font-semibold uppercase bg-emerald-600 hover:bg-emerald-500 text-white",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: `https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent(`Hello Vishal Singh, I am inquiring about my Galaxy Green booking #${b.id} for ${b.plotPreference} scheduled on ${formatDateLabel(b.visitDate)} at ${b.slot || "10:00 AM"}.`)}`,
										target: "_blank",
										rel: "noreferrer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3 mr-1.5" }), " WhatsApp MD"]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									size: "sm",
									className: "h-8 text-[11px] font-mono font-semibold uppercase border-border hover:border-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: `tel:+${PHONE_NUMBER}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 mr-1.5" }), " Hotline"]
									})
								})]
							})
						]
					}, b.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-3 border-t border-border/70 flex items-center justify-between text-[11px] font-mono text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-primary" }), " Stored in device local memory"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => setOpen(false),
						className: "h-7 text-xs font-mono",
						children: "Close"
					})]
				})
			]
		})
	})] });
}
var PHONE = "919044412642";
var MAP_URL = "https://www.google.com/maps/search/?api=1&query=Sai+Surksha+nagar%2C+QR4X%2B39W%2C+Amausi%2C+Lucknow%2C+Uttar+Pradesh+226008";
function Logo({ showMotto = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: "#home",
		className: "flex items-center gap-2 sm:gap-2.5 md:gap-3 group shrink-0 min-w-0",
		"aria-label": "Galaxy Green home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative size-9 sm:size-11 md:size-12 rounded-xl overflow-hidden shadow-glow ring-1 ring-primary/40 group-hover:ring-primary group-hover:scale-105 transition-all duration-300 shrink-0 bg-[#071510]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/galaxy-green-emblem.png",
				alt: "Galaxy Green Emblem Logo",
				width: 48,
				height: 48,
				className: "size-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col justify-center leading-tight min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "block font-display text-sm sm:text-base md:text-lg font-bold tracking-tight text-foreground group-hover:text-primary transition-colors truncate",
					children: "Galaxy Green"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[8px] sm:text-[9px] md:text-[10px] uppercase tracking-widest text-primary/90 font-mono font-medium truncate",
					children: "Sai Suraksha Nagar"
				}),
				showMotto && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[8px] sm:text-[9px] uppercase tracking-wider text-muted-foreground/80 font-mono mt-0.5 truncate",
					children: "Safe Homes | Better Tomorrow"
				})
			]
		})]
	});
}
function Index() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [siteVisitOpen, setSiteVisitOpen] = (0, import_react.useState)(false);
	const [brochureOpen, setBrochureOpen] = (0, import_react.useState)(false);
	const [adminOpen, setAdminOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") {
			if (window.location.hash === "#admin" || sessionStorage.getItem("gg_admin_open") === "true") setAdminOpen(true);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") if (adminOpen) {
			sessionStorage.setItem("gg_admin_open", "true");
			if (window.location.hash !== "#admin") window.history.replaceState(null, "", "#admin");
		} else {
			sessionStorage.removeItem("gg_admin_open");
			if (window.location.hash === "#admin") window.history.replaceState(null, "", window.location.pathname);
		}
	}, [adminOpen]);
	const [selectedPlotForVisit, setSelectedPlotForVisit] = (0, import_react.useState)("600 sq ft");
	const [airportModalOpen, setAirportModalOpen] = (0, import_react.useState)(false);
	const [airportZoom, setAirportZoom] = (0, import_react.useState)(1);
	const [airportPan, setAirportPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [isAirportDragging, setIsAirportDragging] = (0, import_react.useState)(false);
	const airportDragStartRef = (0, import_react.useRef)(null);
	const [scrolledPastHero, setScrolledPastHero] = (0, import_react.useState)(false);
	const [dockMinimized, setDockMinimized] = (0, import_react.useState)(false);
	const [contactName, setContactName] = (0, import_react.useState)("");
	const [contactPhone, setContactPhone] = (0, import_react.useState)("");
	const [contactPlot, setContactPlot] = (0, import_react.useState)("600 sq ft");
	const [customPlotArea, setCustomPlotArea] = (0, import_react.useState)(2e3);
	const [contactVisitDate, setContactVisitDate] = (0, import_react.useState)("");
	const [contactCustomTime, setContactCustomTime] = (0, import_react.useState)("");
	const [showContactClock, setShowContactClock] = (0, import_react.useState)(false);
	const [contactMessage, setContactMessage] = (0, import_react.useState)("");
	const [contactHoneypot, setContactHoneypot] = (0, import_react.useState)("");
	const [formError, setFormError] = (0, import_react.useState)("");
	const [formSubmitting, setFormSubmitting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const handleScroll = () => {
			setScrolledPastHero(window.scrollY > 400);
		};
		window.addEventListener("scroll", handleScroll, { passive: true });
		handleScroll();
		return () => window.removeEventListener("scroll", handleScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		if (menuOpen || airportModalOpen) {
			const originalOverflow = document.body.style.overflow;
			document.body.style.overflow = "hidden";
			return () => {
				document.body.style.overflow = originalOverflow;
			};
		}
	}, [menuOpen, airportModalOpen]);
	(0, import_react.useEffect)(() => {
		if (!airportModalOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") setAirportModalOpen(false);
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [airportModalOpen]);
	const resetAirportView = () => {
		setAirportZoom(1);
		setAirportPan({
			x: 0,
			y: 0
		});
	};
	const handleAirportPointerDown = (e) => {
		if (airportZoom <= 1) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		setIsAirportDragging(true);
		airportDragStartRef.current = {
			startX: e.clientX,
			startY: e.clientY,
			initialPanX: airportPan.x,
			initialPanY: airportPan.y
		};
	};
	const handleAirportPointerMove = (e) => {
		if (!isAirportDragging || !airportDragStartRef.current) return;
		const deltaX = e.clientX - airportDragStartRef.current.startX;
		const deltaY = e.clientY - airportDragStartRef.current.startY;
		setAirportPan({
			x: airportDragStartRef.current.initialPanX + deltaX,
			y: airportDragStartRef.current.initialPanY + deltaY
		});
	};
	const handleAirportPointerUp = (e) => {
		if (isAirportDragging) {
			setIsAirportDragging(false);
			airportDragStartRef.current = null;
			try {
				e.currentTarget.releasePointerCapture(e.pointerId);
			} catch {}
		}
	};
	const handleAirportWheel = (e) => {
		e.preventDefault();
		const delta = e.deltaY > 0 ? -.25 : .25;
		setAirportZoom((prev) => {
			const next = Math.min(3.5, Math.max(.75, Number((prev + delta).toFixed(2))));
			if (next <= 1) setAirportPan({
				x: 0,
				y: 0
			});
			return next;
		});
	};
	const handlePlotSelectForBooking = (plotNumber, size) => {
		setSelectedPlotForVisit(`${size} (Plot ${plotNumber})`);
		setSiteVisitOpen(true);
	};
	const handleCalculatorLock = (plotSizeText) => {
		setSelectedPlotForVisit(plotSizeText);
		setSiteVisitOpen(true);
	};
	async function submitEnquiry(event) {
		event.preventDefault();
		if (contactName.trim().length < 2) {
			setFormError("Please enter your full name.");
			return;
		}
		const cleanPhone = contactPhone.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
			setFormError("Please enter a valid 10-digit Indian mobile number.");
			return;
		}
		if (contactVisitDate) {
			const todayStr = getLocalDateString();
			if (contactVisitDate < todayStr) {
				setFormError("Preferred visit date cannot be in the past. Only present and upcoming dates are allowed.");
				return;
			}
			if (contactVisitDate === todayStr && contactCustomTime.trim()) {
				if (isTimePassedForDate(contactCustomTime.trim(), contactVisitDate)) {
					setFormError(`The selected visit timing "${contactCustomTime.trim()}" has already passed for today. Please select an upcoming time.`);
					return;
				}
			}
		}
		setFormError("");
		setFormSubmitting(true);
		try {
			const finalPlot = contactPlot === "Custom Size" ? `Custom ${customPlotArea} Sq Ft (₹${(customPlotArea * 1199 / 1e5).toFixed(2)} Lakh · Tailored Size)` : contactPlot;
			const finalSlot = contactCustomTime.trim() ? `Custom Time: ${contactCustomTime.trim()}` : "Morning (10:00 AM)";
			const createdLead = await recordNewInquiry({
				name: contactName.trim(),
				phone: cleanPhone,
				plotPreference: finalPlot,
				visitDate: contactVisitDate || void 0,
				message: contactMessage.trim(),
				slot: finalSlot,
				cabPickup: false,
				pickupLocation: "On Site",
				website: contactHoneypot
			});
			saveLocalBooking({
				id: createdLead.id,
				name: createdLead.name,
				phone: createdLead.phone,
				plotPreference: createdLead.plotPreference,
				visitDate: createdLead.visitDate,
				slot: createdLead.slot,
				message: createdLead.message
			});
			toast.success(`Inquiry Recorded! Reference ID: ${createdLead.id}`);
			const text = [
				`Hello Vishal Singh, I am interested in Galaxy Green Sai Suraksha Nagar (Ref: ${createdLead.id}).`,
				`Name: ${contactName.trim()}`,
				`Mobile: ${cleanPhone}`,
				`Plot Preference: ${finalPlot}`,
				contactCustomTime.trim() ? `Preferred Timing: ${contactCustomTime.trim()}` : "",
				contactMessage.trim() ? `Message: ${contactMessage.trim()}` : ""
			].filter(Boolean).join("\n");
			window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
			setContactName("");
			setContactPhone("");
			setContactMessage("");
		} catch (err) {
			console.error(err);
			toast.error("Could not record inquiry. Please try again.");
		} finally {
			setFormSubmitting(false);
		}
	}
	const isFloatingDockVisible = scrolledPastHero && !siteVisitOpen && !brochureOpen && !adminOpen;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "home",
		className: "min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed inset-x-0 top-0 z-50 border-b border-border/80 bg-background/85 backdrop-blur-xl transition-all pt-[env(safe-area-inset-top,0px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 sm:h-20 max-w-7xl xl:max-w-[1440px] items-center justify-between px-3.5 sm:px-6 lg:px-8 min-w-0 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 2xl:gap-2 xl:flex shrink min-w-0",
							"aria-label": "Main navigation",
							itemScope: true,
							itemType: "https://schema.org/SiteNavigationElement",
							children: [
								["About", "#about"],
								["Master Plan", "#masterplan"],
								["Live Photos", "#site-gallery"],
								["Connectivity", "#location"],
								["ROI Calculator", "#calculator"],
								["Pricing", "#pricing"],
								["FAQ", "#faq"],
								["Contact", "#contact"]
							].map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								itemProp: "url",
								className: "px-2 2xl:px-2.5 py-1 rounded text-[11px] 2xl:text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all font-medium whitespace-nowrap",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									itemProp: "name",
									children: label
								})
							}, href))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden xl:flex items-center gap-2 2xl:gap-3 shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-px bg-border/80 mx-0.5 2xl:mx-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAdminOpen(true),
									className: "h-8.5 sm:h-9 px-2.5 2xl:px-3 text-xs border-primary/40 text-primary hover:bg-primary/10 uppercase tracking-wider font-mono shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 mr-1.5" }), " Admin Portal"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setSelectedPlotForVisit("1000 sq ft");
										setSiteVisitOpen(true);
									},
									className: "h-8.5 sm:h-9 px-3 2xl:px-4 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow shrink-0 whitespace-nowrap btn-shimmer",
									children: ["Book Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 sm:gap-2.5 xl:hidden shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAdminOpen(true),
									className: "h-8 sm:h-8.5 px-2 sm:px-2.5 text-[10px] sm:text-xs border-primary/40 text-primary hover:bg-primary/10 uppercase font-mono shrink-0",
									title: "Open Admin Portal",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 mr-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "Admin"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setSelectedPlotForVisit("1000 sq ft");
										setSiteVisitOpen(true);
									},
									className: "h-8 sm:h-8.5 px-2.5 sm:px-3.5 uppercase tracking-wider text-[10px] sm:text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow shrink-0 hidden sm:inline-flex btn-shimmer",
									children: ["Book Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "size-8.5 sm:size-9 text-foreground hover:bg-surface rounded-lg",
									"aria-label": menuOpen ? "Close menu" : "Open menu",
									onClick: () => setMenuOpen((open) => !open),
									children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								})
							]
						})
					]
				}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "border-t border-border bg-background/95 backdrop-blur-2xl px-5 py-6 xl:hidden animate-in fade-in slide-in-from-top-4 shadow-2xl max-h-[calc(100dvh-4.5rem)] overflow-y-auto",
					"aria-label": "Mobile navigation",
					itemScope: true,
					itemType: "https://schema.org/SiteNavigationElement",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1 max-w-lg mx-auto",
						children: [[
							["About", "#about"],
							["Master Plan", "#masterplan"],
							["Live Photos", "#site-gallery"],
							["Connectivity", "#location"],
							["ROI Calculator", "#calculator"],
							["Pricing", "#pricing"],
							["FAQ", "#faq"],
							["Contact", "#contact"]
						].map(([label, href], idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href,
							itemProp: "url",
							onClick: () => setMenuOpen(false),
							className: "flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-surface text-sm uppercase tracking-wider text-muted-foreground hover:text-primary font-medium transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								itemProp: "name",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[10px] text-muted-foreground/60",
								children: ["0", idx + 1]
							})]
						}, label)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 mt-2 border-t border-border/80 flex flex-col gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									setMenuOpen(false);
									setSelectedPlotForVisit("1000 sq ft");
									setSiteVisitOpen(true);
								},
								className: "w-full h-11 uppercase text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
								children: ["Book Free Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => {
									setMenuOpen(false);
									setBrochureOpen(true);
								},
								className: "w-full h-11 uppercase text-xs border-border/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }), " Download E-Brochure"]
							})]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[92vh] min-h-[92dvh] items-end pt-20 sm:pt-24 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: township_entrance_default,
						alt: "Galaxy Green Sai Suraksha Nagar grand gated entrance archway in Lucknow",
						width: 1920,
						height: 1080,
						className: "absolute inset-0 h-full w-full object-cover scale-105 transition-transform duration-1000 ease-out"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-hero-overlay" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-grid opacity-25" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20 pt-28 sm:pt-36 lg:pb-24 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-glow -top-10 -left-10 opacity-75" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-4xl relative z-10 w-full min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 sm:mb-6 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/80 px-3.5 sm:px-4 py-1.5 backdrop-blur-md shadow-sm max-w-full",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] sm:text-xs uppercase tracking-widest text-primary font-mono font-medium truncate",
											children: "Phase 1 Open · Amausi Airport Growth Corridor"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "fluid-hero-title",
										children: ["Galaxy Green", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1.5 sm:mt-2 block text-emerald-gradient",
											children: "Sai Suraksha Nagar"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 sm:mt-7 max-w-2xl text-sm sm:text-base lg:text-lg leading-relaxed text-foreground/80 text-pretty",
										children: "Secure your freehold residential plot at Amausi, Lucknow—where high-yield airport connectivity meets an eco-luxury gated community. Immediate registry and bank loan approvals."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-7 sm:mt-9 flex flex-wrap gap-2.5 sm:gap-3.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "lg",
												onClick: () => {
													setSelectedPlotForVisit("1000 sq ft");
													setSiteVisitOpen(true);
												},
												className: "h-11 sm:h-13 px-5 sm:px-8 uppercase tracking-wider text-[11px] sm:text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
												children: ["Schedule Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 sm:size-4 ml-1.5 sm:ml-2" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												variant: "outline",
												className: "h-11 sm:h-13 border-foreground/30 bg-background/40 px-4 sm:px-7 uppercase tracking-wider text-[11px] sm:text-xs backdrop-blur-md hover:bg-background/60",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "#masterplan",
													children: ["Explore Master Plan ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5 sm:size-4 ml-1.5 sm:ml-2" })]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "lg",
												variant: "ghost",
												onClick: () => setBrochureOpen(true),
												className: "h-11 sm:h-13 px-4 sm:px-6 uppercase tracking-wider text-[11px] sm:text-xs border border-primary/30 text-primary bg-primary/10 hover:bg-primary/20 backdrop-blur-md",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 sm:size-4 mr-1.5 sm:mr-2" }), " E-Brochure"]
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 sm:mt-14 grid w-full max-w-4xl grid-cols-2 border border-border/80 bg-background/60 backdrop-blur-xl rounded-md divide-y sm:divide-y-0 sm:divide-x divide-border/60 sm:grid-cols-4 shadow-luxury relative z-10 min-w-0",
								children: [
									[
										"₹1,199",
										"Per Sq Ft Rate",
										"Phase 1 fixed pricing"
									],
									[
										"600+",
										"Sq Ft Min Size",
										"Up to custom requirement"
									],
									[
										"100%",
										"Freehold & Mutation",
										"Dakhil Kharij ready"
									],
									[
										"2.7 km",
										"Amausi Railway",
										"5 km to Airport & Metro"
									]
								].map(([value, label, sub]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 sm:p-5 transition-colors hover:bg-white/[0.02] min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "font-display text-xl sm:text-2xl lg:text-3xl text-primary block tracking-tight truncate",
											children: value
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-[11px] sm:text-xs uppercase font-medium text-foreground tracking-wide truncate",
											children: label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] sm:text-[10px] text-muted-foreground font-mono block mt-0.5 truncate",
											children: sub
										})
									]
								}, label))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "about",
				className: "section-shell border-b border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-6 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "01 · Prime Plotted Living"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Build The Villa You Always Envisioned"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base sm:text-lg leading-relaxed text-muted-foreground",
									children: "Galaxy Green Sai Suraksha Nagar is meticulously planned for homeowners and astute real estate investors. Spread across lush green surroundings near Chaudhary Charan Singh International Airport, our layout gives you complete architectural freedom to design your private 2-storey duplex, family estate, or lush green retirement haven."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "card-architectural group p-5 rounded-lg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram size-11 mb-3.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "size-5 transition-transform duration-300 group-hover:scale-110" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-base uppercase text-foreground font-semibold tracking-tight",
												children: "Airport Growth Hub"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
												children: "Just 5 minutes from Amausi Airport. Prime zone benefiting from Lucknow’s infrastructure surge."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "card-architectural group p-5 rounded-lg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram-gold size-11 mb-3.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-5 transition-transform duration-300 group-hover:scale-110" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-base uppercase text-foreground font-semibold tracking-tight",
												children: "Zero Legal Ambiguity"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
												children: "100% freehold land with instant registry and mutation. Bank loan assistance up to 80%."
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setSelectedPlotForVisit("1000 sq ft");
											setSiteVisitOpen(true);
										},
										className: "h-12 px-6 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
										children: ["Schedule Free On-Site Inspection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })]
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-6 relative",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-lg border border-primary/40 shadow-glow group",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: luxury_villa_concept_default,
										alt: "Modern luxury eco villa concept at Galaxy Green Sai Suraksha Nagar",
										className: "w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-6 left-6 right-6 p-4 rounded bg-background/80 backdrop-blur-md border border-border/80",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase font-mono text-primary tracking-widest block font-semibold",
												children: "Villa Concept"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-sm font-display uppercase text-foreground",
												children: "Contemporary 2-Storey Duplex on 1,500 Sq Ft"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "border-primary/50 text-primary bg-primary/10 text-[10px] font-mono",
												children: "Vastu Compliant"
											})]
										})
									})
								]
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterPlanViewer, { onSelectPlotForBooking: handlePlotSelectForBooking }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActualSiteGallery, { onScheduleVisit: (plotText) => {
				setSelectedPlotForVisit(plotText || "600 sq ft");
				setSiteVisitOpen(true);
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "location",
				className: "section-shell bg-background border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-6 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "04 · Strategic Positioning"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Direct Airport & Metro Connectivity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base leading-relaxed text-muted-foreground",
									children: "Located at Sai Suraksha Nagar, Amausi, Lucknow (PIN 226008). Benefit from premier connectivity: 2.7 km from Amausi Railway Station, 3 km from T.S. Mishra Medical College & Hospital, 3 km from Kanpur-Lucknow Expressway, 2.5 km from Main Market, and 5 km from CCS International Airport & Amausi Metro Station."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2",
									children: [
										{
											icon: TramFront,
											dist: "2.7 km",
											label: "Amausi Railway Station",
											sub: "~5 Mins · Express & Local Hub"
										},
										{
											icon: HeartPulse,
											dist: "3.0 km",
											label: "T.S. Mishra Medical College",
											sub: "~6 Mins · Hospital & Trauma"
										},
										{
											icon: Plane,
											dist: "5.0 km",
											label: "CCS International Airport",
											sub: "~8-10 Mins · Terminal 3"
										},
										{
											icon: Route,
											dist: "5.0 km",
											label: "Amausi Metro Station",
											sub: "~8-10 Mins · Red Line Link"
										},
										{
											icon: Car,
											dist: "3.0 km",
											label: "Kanpur-Lucknow Expressway",
											sub: "~5 Mins · High-Speed Link"
										},
										{
											icon: ShoppingBag,
											dist: "2.5 km",
											label: "Main Market",
											sub: "~4 Mins · Daily Essentials"
										}
									].map((item) => {
										const Icon = item.icon;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-lg bg-surface border border-border/80 text-center hover:border-primary/50 transition-all duration-300 group hover:-translate-y-1 hover:shadow-luxury",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "icon-monogram size-9 mx-auto mb-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 transition-transform duration-300 group-hover:scale-110" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "font-display text-2xl text-primary block group-hover:scale-105 transition-transform",
													children: item.dist
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-foreground uppercase block mt-1 line-clamp-1",
													children: item.label
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono block mt-0.5",
													children: item.sub
												})
											]
										}, item.label);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										className: "h-11 px-5 border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground uppercase text-xs tracking-wider",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: MAP_URL,
											target: "_blank",
											rel: "noreferrer",
											children: ["Open In Google Maps ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 ml-2" })]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setSelectedPlotForVisit("Airport Corridor Plot");
											setSiteVisitOpen(true);
										},
										className: "h-11 px-5 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
										children: ["Schedule Site Tour ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 ml-2" })]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-lg border border-border shadow-glow group cursor-pointer",
								onClick: () => {
									resetAirportView();
									setAirportModalOpen(true);
								},
								role: "button",
								tabIndex: 0,
								"aria-label": "View Chaudhary Charan Singh International Airport connectivity map in full screen HD",
								onKeyDown: (e) => {
									if (e.key === "Enter" || e.key === " ") {
										e.preventDefault();
										resetAirportView();
										setAirportModalOpen(true);
									}
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: lucknow_connectivity_default,
										alt: "Galaxy Green strategic location map and connectivity to Chaudhary Charan Singh International Airport Lucknow",
										className: "w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background/95 via-transparent to-transparent pointer-events-none" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-3.5 right-3.5 z-10 flex items-center gap-2 rounded-full border border-primary/40 bg-background/85 px-3 py-1.5 backdrop-blur-md shadow-md transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-mono font-medium uppercase tracking-wider",
											children: "Full Screen HD"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute bottom-5 left-5 right-5 p-4 rounded bg-background/80 backdrop-blur-md border border-border flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-sm font-display uppercase text-foreground",
												children: "Galaxy Green Sai Suraksha Nagar"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground font-mono mt-0.5",
												children: "QR4X+39W, Amausi, Lucknow, Uttar Pradesh 226008"
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "hidden sm:inline-flex items-center gap-1.5 text-xs font-mono text-primary font-semibold",
											children: ["Click To Enlarge ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" })]
										})]
									})
								]
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiRoiCalculator, { onLockPriceClick: handleCalculatorLock }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "section-shell bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalTrustBadge, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "section-shell bg-surface border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "05 · Ground Execution"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "On-Site Progress Tracker"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground leading-relaxed",
									children: "We believe in complete transparency. Every infrastructure component is being developed as per timeline."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "06 · Buyer Experiences"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Trusted By Families & Investors"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-card border border-border p-6 rounded space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex text-amber-400 gap-1 text-xs",
												children: "★".repeat(5)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground leading-relaxed italic",
												children: "\"Visiting the site near Amausi Airport gave us huge confidence. The road widths are actually 40 feet as promised, and the title paperwork was crystal clear. We booked a 1,500 sq ft plot for our family home.\""
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-xs text-foreground uppercase block font-display",
													children: "Dr. S. K. Rastogi"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono",
													children: "Consultant Physician · Lucknow"
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-card border border-border p-6 rounded space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex text-amber-400 gap-1 text-xs",
												children: "★".repeat(5)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground leading-relaxed italic",
												children: "\"From an investment standpoint, the proximity to the new airport terminal and Shaheed Path made this an easy choice. Vishal Singh and his team arranged immediate registry documentation without any hassle.\""
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-xs text-foreground uppercase block font-display",
													children: "Rajesh Singhania"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono",
													children: "Business Owner & Property Investor"
												})]
											})
										]
									})]
								})
							]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "pricing",
				className: "section-shell bg-background border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "07 · Phase 1 Pricing"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "section-title",
								children: "Transparent Allotment Rates"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-l-2 border-primary pl-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl font-semibold text-primary",
									children: "₹1,199 / Sq Ft"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground font-mono mt-1",
									children: "Fixed Phase 1 Base Rate · Min 600 Sq Ft to Custom Requirements"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								{
									size: "600",
									dim: "20 × 30 ft",
									total: "₹7,19,400",
									note: "Minimum entry size. Ideal for compact smart duplex or high-yield investment.",
									tag: "Starting Size",
									popular: false
								},
								{
									size: "1,000",
									dim: "25 × 40 ft",
									total: "₹11,99,000",
									note: "Most sought-after layout. Perfect for luxury 3BHK independent villa with lawn & parking.",
									tag: "Most Popular",
									popular: true
								},
								{
									size: "1,500",
									dim: "30 × 50 ft",
									total: "₹17,98,500",
									note: "Generous frontage for front lawn, two-car parking, and spacious terrace garden.",
									tag: "Executive Villa",
									popular: false
								},
								{
									size: "Custom",
									dim: "As Per Requirement",
									total: "₹1,199 / sq ft",
									note: "Tailored to your exact wish. Combine multiple plots for large commercial or luxury estates.",
									tag: "On Buyer Wish",
									popular: false
								}
							].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `relative rounded-md border p-6 bg-card flex flex-col justify-between transition-all hover:shadow-glow ${card.popular ? "border-primary shadow-glow ring-1 ring-primary/40" : "border-border"}`,
								children: [
									card.tag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `absolute right-0 top-0 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider font-mono rounded-bl ${card.popular ? "bg-primary text-primary-foreground" : "bg-surface border-b border-l border-border text-muted-foreground"}`,
										children: card.tag
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs uppercase tracking-widest text-muted-foreground font-mono",
											children: "Residential Plot"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex items-baseline gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "font-display text-4xl font-semibold text-foreground",
												children: card.size
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs uppercase font-mono text-muted-foreground",
												children: card.size === "Custom" ? "Sizes" : "Sq Ft"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground font-mono block mt-1",
											children: card.dim
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-5 h-px bg-border" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase font-mono text-muted-foreground block",
											children: "Allotment Cost"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-display text-2xl font-semibold text-primary",
											children: card.total
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-xs text-muted-foreground leading-relaxed",
											children: card.note
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => {
												setSelectedPlotForVisit(card.size === "Custom" ? "Custom Requirement" : `${card.size} sq ft`);
												setSiteVisitOpen(true);
											},
											className: "w-full h-10 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
											children: ["Reserve This Plot ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											onClick: () => setBrochureOpen(true),
											className: "w-full h-9 uppercase text-[11px] tracking-wider border-border",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3 mr-1.5" }), " Specifications"]
										})]
									})
								]
							}, card.size))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-center text-xs text-muted-foreground font-mono",
							children: "* Prices are exclusive of government registration fees and stamp duty. Bank loan financing available up to 80%."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "faq",
				className: "section-shell bg-background border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center max-w-2xl mx-auto mb-12",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "08 · Buyer Knowledge Base"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "section-title",
								children: "Frequently Asked Questions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "section-subtitle mx-auto",
								children: "Everything property buyers and NRI investors need to know about freehold land registry, bank loans, location advantages, and payment schedules at Galaxy Green."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-card border border-border rounded-xl p-6 sm:p-8 shadow-glow",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Accordion, {
							type: "single",
							collapsible: true,
							defaultValue: "item-1",
							className: "w-full divide-y divide-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-1",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Where is Galaxy Green Sai Suraksha Nagar located in Lucknow?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Galaxy Green Sai Suraksha Nagar is strategically located in Amausi, Lucknow (Plus Code: QR4X+39W, Pin 226008). Key nearby connectivity points include: Amausi Railway Station (2.7 km), T.S. Mishra Medical College & Hospital (3 km), Kanpur-Lucknow Expressway (3 km), Main Market (2.5 km), and CCS International Airport & Amausi Metro Station (5 km)."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-2",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "What are the plot sizes and rates per sq ft at Galaxy Green?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: [
											"Standard residential plots start at a transparent Phase 1 rate of ₹1,199 per sq ft. Minimum plot area starts from 600 sq ft, and maximum can be fully tailored to your wish and architectural requirements:",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
												className: "list-disc pl-5 mt-2 space-y-1 text-xs sm:text-sm font-mono text-foreground/90",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "600 Sq Ft (20 × 30 ft) — starting at ₹7.19 Lakh (Ideal budget duplex)" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "800 Sq Ft (20 × 40 ft) — starting at ₹9.59 Lakh" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1,000 Sq Ft (25 × 40 ft) — starting at ₹11.99 Lakh (Most popular 3BHK)" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1,200 Sq Ft (30 × 40 ft) — starting at ₹14.39 Lakh" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1,500 Sq Ft (30 × 50 ft) — starting at ₹17.99 Lakh (Executive villa)" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2,000 Sq Ft (40 × 50 ft) — starting at ₹23.98 Lakh (Luxury estate)" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Custom plot sizes up to 5,000+ sq ft customized as per buyer requirement" })
												]
											}),
											"Corner and wide-boulevard facing plots carry standard Preferential Location Charges (PLC)."
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-3",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Are the plots freehold with immediate registry and Dakhil Kharij?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Yes, 100%. All plots at Galaxy Green are strictly freehold with clear, unencumbered land titles. We guarantee instant registry upon payment completion along with full government land mutation (Dakhil Kharij) documentation assistance. You receive complete legal ownership rights to build or hold."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-4",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Can I avail a bank loan or easy EMI facility for plot purchase?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Yes. We have active tie-ups and verification processes with leading nationalized and private banking institutions (SBI, HDFC, ICICI, PNB, and Bank of Baroda). Eligible buyers can secure up to 75%–80% financing with low interest rates and flexible tenures up to 20 years."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-5",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "What infrastructure and amenities are provided inside the township?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: ["Galaxy Green is developed as an eco-luxury gated township featuring:", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
											className: "list-disc pl-5 mt-2 space-y-1 text-xs sm:text-sm text-foreground/90",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "30-ft and 40-ft wide paved internal concrete boulevards" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Underground drainage and sewage system" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Solar-powered street illumination and dedicated transformer power supply" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "24/7 manned security checkpoint with automated RFID barrier & CCTV" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Landscaped community park, children's play area, and open green recreational spaces" })
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-6",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "How can I schedule a personal site visit to Galaxy Green?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: [
											"You can schedule a personalized site tour directly on our website or by contacting our project sales desk at",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "tel:+919044412642",
												className: "text-primary font-semibold underline",
												children: "+91 90444 12642"
											}),
											". Our site coordinators are available daily from 9:00 AM to 6:30 PM to guide you through the property, inspect plot demarcation stones, and verify registry paperwork on-site."
										]
									})]
								})
							]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "contact",
				className: "section-shell bg-surface border-t border-border pb-28 sm:pb-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-10 lg:gap-12 lg:grid-cols-12 items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "09 · Direct Management Contact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Arrange Your Personal Site Tour"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base text-muted-foreground leading-relaxed",
									children: "Connect directly with the management team. Submit your requirement below to receive verified layout sheets, schedule a personalized site visit, or discuss custom plot boundaries."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-6 rounded-xl bg-card border border-primary/40 shadow-glow space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-11 sm:size-12 rounded-full bg-primary/10 border border-primary/30 text-primary grid place-items-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 sm:size-6" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase font-mono tracking-wider text-muted-foreground block",
													children: "Managing Director"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-display text-base sm:text-lg uppercase text-foreground font-semibold truncate",
													children: "Vishal Singh"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2.5 text-xs font-mono pt-3 border-t border-border/60",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground shrink-0",
														children: "Direct Hotline:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: "tel:+919044412642",
														className: "text-primary font-semibold hover:underline break-words",
														children: "+91 90444 12642"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground shrink-0",
														children: "Location:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground",
														children: "Amausi, Lucknow"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground shrink-0",
														children: "Site Office Hours:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground",
														children: "9:00 AM – 6:30 PM (Daily)"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											className: "w-full h-11 uppercase text-xs tracking-wider font-semibold bg-emerald-600 hover:bg-emerald-500 text-white",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `https://wa.me/${PHONE}?text=${encodeURIComponent("Hello Vishal Singh, I would like to schedule a discussion regarding Galaxy Green Sai Suraksha Nagar.")}`,
												target: "_blank",
												rel: "noreferrer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4 mr-2" }), " Chat Directly On WhatsApp"]
											})
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7 bg-card border border-border rounded-xl p-4 sm:p-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-4 mb-6 pb-3 border-b border-border/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg sm:text-xl uppercase tracking-tight text-foreground",
									children: "Send Booking Inquiry"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] sm:text-xs text-muted-foreground font-mono",
									children: "Instant Response Guaranteed"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submitEnquiry,
								className: "space-y-4",
								noValidate: true,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										name: "website",
										tabIndex: -1,
										autoComplete: "off",
										value: contactHoneypot,
										onChange: (e) => setContactHoneypot(e.target.value),
										className: "hidden",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "form-label",
											children: "Full Name *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											name: "name",
											maxLength: 80,
											autoComplete: "name",
											placeholder: "Enter your name",
											value: contactName,
											onChange: (e) => setContactName(e.target.value),
											className: "form-control"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "form-label",
											children: "Mobile Number *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											name: "phone",
											inputMode: "numeric",
											maxLength: 10,
											autoComplete: "tel",
											placeholder: "10-digit mobile",
											value: contactPhone,
											onChange: (e) => setContactPhone(e.target.value),
											className: "form-control"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-1 mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "form-label mb-0",
											children: "Plot Preference"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] sm:text-xs font-mono text-emerald-400 font-medium",
											children: "₹1,199 / Sq Ft Base"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: contactPlot,
										onChange: (e) => setContactPlot(e.target.value),
										className: "form-control block w-full px-4 text-xs font-mono",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "600 sq ft",
												children: "600 Sq Ft (₹7.19 Lakh · Starting Size)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "800 sq ft",
												children: "800 Sq Ft (₹9.59 Lakh)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1000 sq ft",
												children: "1,000 Sq Ft (₹11.99 Lakh · Most Popular)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1200 sq ft",
												children: "1,200 Sq Ft (₹14.39 Lakh)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1500 sq ft",
												children: "1,500 Sq Ft (₹17.99 Lakh)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "2000 sq ft",
												children: "2,000 Sq Ft (₹23.98 Lakh)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Custom Size",
												children: "⚡ Custom Size Requirement (Any Size On Buyer Wish)"
											})
										]
									})] }),
									contactPlot === "Custom Size" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-lg bg-surface/90 border border-primary/40 space-y-2.5 animate-in fade-in",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] font-mono text-primary font-semibold",
													children: "Custom Area (Sq Ft):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] font-mono text-emerald-400 font-semibold",
													children: [
														"Estimated: ₹",
														(customPlotArea * 1199 / 1e5).toFixed(2),
														" Lakh"
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 600,
													max: 25e3,
													step: 50,
													value: customPlotArea,
													onChange: (e) => {
														const v = parseInt(e.target.value, 10);
														setCustomPlotArea(isNaN(v) ? 600 : v);
													},
													className: "h-9 text-xs font-mono font-semibold bg-background"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-mono text-muted-foreground",
													children: "Sq Ft"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap gap-1",
												children: [
													750,
													1800,
													2500,
													3500,
													5e3
												].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setCustomPlotArea(s),
													className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${customPlotArea === s ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background border-border text-muted-foreground hover:text-foreground"}`,
													children: [s, " Sq Ft"]
												}, s))
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "form-label mb-0 flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3 text-primary" }), " Calendar (Year / Month / Date)"]
													}), contactVisitDate === getLocalDateString() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-primary font-semibold font-mono",
														children: "Today"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													min: getLocalDateString(),
													value: contactVisitDate,
													onChange: (e) => {
														const val = e.target.value;
														const minDate = getLocalDateString();
														if (val && val < minDate) {
															setFormError("Preferred visit date cannot be in the past. Only present and upcoming dates are allowed.");
															return;
														}
														setFormError("");
														setContactVisitDate(val);
													},
													className: "form-control"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-1.5 mt-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																setContactVisitDate(getLocalDateString());
																setFormError("");
															},
															className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${contactVisitDate === getLocalDateString() ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background/80 border-border text-muted-foreground hover:text-foreground"}`,
															children: "Today"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																const d = /* @__PURE__ */ new Date();
																d.setDate(d.getDate() + 1);
																setContactVisitDate(getLocalDateString(d));
																setFormError("");
															},
															className: "px-2 py-0.5 rounded text-[10px] font-mono border border-border text-muted-foreground hover:text-foreground bg-background/80 transition-all",
															children: "Tomorrow"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[9px] font-mono text-muted-foreground ml-auto",
															children: "Past dates blocked"
														})
													]
												})
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-1 mb-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "form-label mb-0 flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-primary" }), " Preferred Visit Timing"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => setShowContactClock((prev) => !prev),
														className: "text-[10px] sm:text-xs font-mono text-primary hover:underline flex items-center gap-1 font-semibold",
														children: ["🕒 ", showContactClock ? "Hide Clock" : "Open Clock Selector"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. 11:30 AM or 05:00 PM",
													value: contactCustomTime,
													onChange: (e) => {
														setContactCustomTime(e.target.value);
														setFormError("");
													},
													className: "form-control"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1 mt-1.5",
													children: [
														"10:00 AM",
														"11:30 AM",
														"02:00 PM",
														"04:30 PM",
														"05:30 PM"
													].map((t) => {
														const isPassed = isTimePassedForDate(t, contactVisitDate || getLocalDateString());
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															disabled: isPassed,
															onClick: () => {
																if (isPassed) return;
																setContactCustomTime(t);
																setFormError("");
															},
															className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${isPassed ? "opacity-35 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : contactCustomTime === t ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background/80 border-border text-muted-foreground hover:text-foreground"}`,
															children: [t, isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "ml-1 text-[8px] no-underline",
																children: "✕"
															})]
														}, t);
													})
												})
											] })]
										}), showContactClock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "animate-in fade-in slide-in-from-top-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockTimePicker, {
												value: contactCustomTime || "11:30 AM",
												onChange: (val) => {
													setContactCustomTime(val);
													setFormError("");
												},
												selectedDate: contactVisitDate || getLocalDateString(),
												compact: false
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "form-label",
										children: "Notes or Special Requirements"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										name: "message",
										maxLength: 500,
										placeholder: "Preferred visit date, questions about bank loan, corner plots, etc.",
										value: contactMessage,
										onChange: (e) => setContactMessage(e.target.value),
										className: "mt-2 min-h-28 border-border bg-background/50 text-xs"
									})] }),
									formError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										role: "alert",
										className: "text-xs text-destructive bg-destructive/10 p-2.5 rounded",
										children: formError
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										disabled: formSubmitting,
										className: "w-full h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
										children: [formSubmitting ? "Submitting Inquiry..." : "Submit Inquiry & Connect On WhatsApp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center text-[11px] text-muted-foreground font-mono",
										children: "Your inquiry is recorded in real time and opens directly with project MD Vishal Singh."
									})
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 pt-6 border-t border-border/40 flex justify-center px-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "developer-shine-box group w-full max-w-sm sm:max-w-xl p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3.5 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative size-11 rounded-xl bg-gradient-to-br from-cyan-500/25 via-blue-500/20 to-purple-600/25 border border-cyan-400/50 text-cyan-300 grid place-items-center shrink-0 shadow-[0_0_15px_rgba(6,182,212,0.35)] group-hover:shadow-[0_0_25px_rgba(6,182,212,0.65)] group-hover:border-cyan-300 transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeXml, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "absolute -top-1 -right-1 flex h-2.5 w-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs uppercase tracking-wider font-bold text-white font-mono drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]",
											children: "Developed by Aditya"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 font-semibold tracking-wider uppercase shadow-[0_0_8px_rgba(6,182,212,0.25)]",
											children: "Dev"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "mailto:23rajaditya@gmail.com",
										className: "text-xs text-slate-300 hover:text-cyan-300 font-mono flex items-center gap-1.5 transition-colors truncate mt-1 group/email",
										title: "Direct Email: 23rajaditya@gmail.com",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-cyan-400 shrink-0 group-hover/email:scale-110 transition-transform" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: "23rajaditya@gmail.com"
										})]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0 self-end sm:self-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "https://www.linkedin.com/in/rajadityaaa23/",
									target: "_blank",
									rel: "noopener noreferrer",
									className: "px-3.5 py-2 rounded-xl bg-[#0077b5]/20 hover:bg-[#0077b5]/40 border border-[#0077b5]/60 hover:border-[#0077b5] text-sky-200 hover:text-white text-xs font-mono font-semibold transition-all shadow-[0_0_12px_rgba(0,119,181,0.25)] hover:shadow-[0_0_22px_rgba(0,119,181,0.6)] flex items-center gap-1.5",
									title: "Connect with Aditya on LinkedIn",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "size-3.5 text-[#00a0dc]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "LinkedIn" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-2.5 opacity-60 ml-0.5" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:23rajaditya@gmail.com",
									className: "px-3.5 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/35 border border-cyan-400/40 hover:border-cyan-300 text-cyan-200 hover:text-white text-xs font-mono font-semibold transition-all shadow-[0_0_12px_rgba(6,182,212,0.2)] hover:shadow-[0_0_22px_rgba(6,182,212,0.6)] flex items-center gap-1.5",
									title: "Send Direct Email to Aditya",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-cyan-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mail" })]
								})]
							})]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border bg-background px-5 pt-12 pb-24 sm:pb-16 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl flex flex-col gap-8 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { showMotto: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-xs leading-relaxed text-muted-foreground",
						children: "Galaxy Green Sai Suraksha Nagar, QR4X+39W, Amausi, Lucknow, Uttar Pradesh 226008. Freehold residential plotted development."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 text-xs font-mono text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setAdminOpen(true),
								className: "text-primary hover:underline flex items-center gap-1 uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), " Admin Portal"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setBrochureOpen(true),
								className: "hover:text-foreground uppercase",
								children: "Download Brochure"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:+91${PHONE}`,
								className: "hover:text-foreground uppercase",
								children: "+91 90444 12642"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 Galaxy Green" })
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `fixed bottom-4 right-4 sm:bottom-6 sm:right-6 mb-[env(safe-area-inset-bottom,0px)] mr-[env(safe-area-inset-right,0px)] z-40 transition-all duration-300 ease-out ${isFloatingDockVisible ? "opacity-100 translate-y-0 pointer-events-auto" : "opacity-0 translate-y-6 pointer-events-none"}`,
				children: dockMinimized ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setDockMinimized(false),
					className: "flex items-center gap-2 rounded-full border border-primary/50 bg-card/95 p-1 pl-1.5 pr-3 text-xs font-semibold uppercase tracking-wider text-foreground shadow-luxury backdrop-blur-xl transition-all hover:border-primary hover:bg-card hover:scale-105 active:scale-95",
					"aria-label": "Open Luxury Concierge Desk",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/galaxy-green-emblem.png",
							alt: "Concierge",
							width: 28,
							height: 28,
							className: "size-7 rounded-full object-cover shadow-glow ring-1 ring-primary/40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display tracking-normal text-xs text-primary font-semibold",
							children: "Concierge"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5 text-emerald-400 ml-0.5" })
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-full border border-border/80 bg-card/95 p-1.5 pl-3 pr-2 shadow-luxury backdrop-blur-xl ring-1 ring-white/5 transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-2 pr-2 border-r border-border/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png",
								alt: "Galaxy Green",
								width: 20,
								height: 20,
								className: "size-5 rounded-full object-cover ring-1 ring-primary/40"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] uppercase tracking-wider text-muted-foreground",
								children: "Direct Desk"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => {
								setSelectedPlotForVisit("1000 sq ft");
								setSiteVisitOpen(true);
							},
							size: "sm",
							className: "h-9 px-3.5 rounded-full uppercase tracking-wider text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm border border-primary/50 btn-shimmer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 mr-1.5" }), " Book Visit"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "icon",
							className: "size-9 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-transform hover:scale-105",
							"aria-label": "Chat directly on WhatsApp",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `https://wa.me/${PHONE}?text=${encodeURIComponent("Hello Vishal Singh, I am interested in Galaxy Green Sai Suraksha Nagar plots.")}`,
								target: "_blank",
								rel: "noreferrer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDockMinimized(true),
							className: "size-6 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface flex items-center justify-center text-xs transition-colors ml-0.5",
							title: "Minimize Concierge",
							"aria-label": "Minimize Concierge",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyBookingsDrawer, { onOpenVisitModal: () => setSiteVisitOpen(true) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteVisitModal, {
				open: siteVisitOpen,
				onOpenChange: setSiteVisitOpen,
				defaultPlotPreference: selectedPlotForVisit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrochureModal, {
				open: brochureOpen,
				onOpenChange: setBrochureOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLeadsDrawer, {
				open: adminOpen,
				onOpenChange: setAdminOpen
			}),
			airportModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 bg-background/95 backdrop-blur-2xl flex flex-col justify-between p-3 sm:p-6 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] animate-in fade-in duration-200",
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border/80 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 sm:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "border-primary/50 text-primary bg-primary/10 font-mono text-[11px] uppercase tracking-wider",
								children: "Full Screen HD · Original Quality"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-mono text-foreground font-medium hidden md:inline",
								children: "Chaudhary Charan Singh International Airport (LKO) & Amausi Plots"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1 bg-surface border border-border rounded-lg p-0.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => setAirportZoom((prev) => {
												const next = Math.max(.75, Number((prev - .25).toFixed(2)));
												if (next <= 1) setAirportPan({
													x: 0,
													y: 0
												});
												return next;
											}),
											disabled: airportZoom <= .75,
											className: "size-7 sm:size-8 text-foreground hover:bg-background",
											title: "Zoom Out",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-3.5 sm:size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono font-semibold px-1 min-w-[2.8rem] text-center",
											children: [Math.round(airportZoom * 100), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => setAirportZoom((prev) => Math.min(3.5, Number((prev + .25).toFixed(2)))),
											disabled: airportZoom >= 3.5,
											className: "size-7 sm:size-8 text-foreground hover:bg-background",
											title: "Zoom In",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-3.5 sm:size-4" })
										}),
										(airportZoom !== 1 || airportPan.x !== 0 || airportPan.y !== 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: resetAirportView,
											className: "size-7 sm:size-8 text-muted-foreground hover:text-foreground hover:bg-background",
											title: "Reset View",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setAirportModalOpen(false);
										setSelectedPlotForVisit("Airport Vicinity Plot");
										setSiteVisitOpen(true);
									},
									className: "h-8 px-3 uppercase text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 hidden sm:inline-flex",
									children: ["Inquire Plots ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => setAirportModalOpen(false),
									className: "size-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface",
									"aria-label": "Close Full Screen View",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative flex-1 flex items-center justify-center my-2 sm:my-3 overflow-hidden rounded-xl border border-border/80 bg-black/70 p-2 sm:p-4 select-none touch-none",
						onPointerDown: handleAirportPointerDown,
						onPointerMove: handleAirportPointerMove,
						onPointerUp: handleAirportPointerUp,
						onPointerCancel: handleAirportPointerUp,
						onWheel: handleAirportWheel,
						onDoubleClick: () => {
							if (airportZoom > 1) resetAirportView();
							else setAirportZoom(2);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "origin-center transition-transform select-none",
							style: {
								transform: `translate3d(${airportPan.x}px, ${airportPan.y}px, 0) scale(${airportZoom})`,
								transitionDuration: isAirportDragging ? "0ms" : "200ms",
								cursor: airportZoom > 1 ? isAirportDragging ? "grabbing" : "grab" : "zoom-in"
							},
							title: airportZoom > 1 ? "Drag to pan · Double-click to reset · Scroll to zoom" : "Click zoom controls, double-click, or use wheel/trackpad to zoom",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/assets/lucknow-connectivity-B43LUJi1.jpg",
								alt: "Chaudhary Charan Singh International Airport (LKO) and Amausi Available Plots aerial photograph",
								className: "max-h-[72vh] max-h-[72dvh] w-auto max-w-full object-contain rounded-lg shadow-2xl pointer-events-none select-none",
								draggable: false
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-border/80 pt-3 max-w-5xl mx-auto w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-xs sm:text-sm font-display uppercase tracking-wide text-foreground block",
								children: "Chaudhary Charan Singh International Airport · Runway (09/27) · Terminals 1 & 2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] sm:text-xs text-muted-foreground font-mono mt-0.5",
								children: "Direct connectivity to Kanpur Road (NH27), Amausi Metro Station & Galaxy Green Sai Suraksha Nagar available plots."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setAirportModalOpen(false);
										setSelectedPlotForVisit("Airport Vicinity Plot");
										setSiteVisitOpen(true);
									},
									className: "sm:hidden w-full h-8 uppercase text-[11px] font-semibold bg-primary text-primary-foreground",
									children: ["Inquire Nearby Plots ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1" })]
								})
							})]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { Index as component };
