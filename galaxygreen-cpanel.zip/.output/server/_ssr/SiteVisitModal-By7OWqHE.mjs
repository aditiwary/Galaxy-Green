import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as Button, t as Badge } from "./badge-CC6878ln.mjs";
import { t as Input } from "./server-inquiries-BZCzG7ab.mjs";
import { t as Label } from "./label-C0fbpOZw.mjs";
import { o as recordNewInquiry } from "./leads-client-YV8ZcKah.mjs";
import { C as MessageCircle, G as Clock, J as CircleCheck, T as Maximize2, U as Compass, Y as CircleAlert, d as Sparkles, f as SlidersVertical, nt as Calendar, o as TriangleAlert, st as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-oBgWH-X9.mjs";
import { i as getLocalDateString, l as parseTimeHoursMinutes, s as isTimePassedForDate, t as PRESET_SLOTS, u as saveLocalBooking } from "./visit-helpers-Cila1FpI.mjs";
import { t as ClockTimePicker } from "./ClockTimePicker-CK5prHzn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SiteVisitModal-By7OWqHE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHONE_NUMBER = "919044412642";
function formatCurrency(amount) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(amount);
}
function SiteVisitModal({ open, onOpenChange, defaultPlotPreference = "600 sq ft", baseRate = 1199 }) {
	const BASE_RATE = baseRate || 1199;
	const [step, setStep] = (0, import_react.useState)("form");
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [confirmedBooking, setConfirmedBooking] = (0, import_react.useState)(null);
	const todayStr = getLocalDateString();
	const tomorrowDate = /* @__PURE__ */ new Date();
	tomorrowDate.setDate(tomorrowDate.getDate() + 1);
	const tomorrowStr = getLocalDateString(tomorrowDate);
	const currentHour = (/* @__PURE__ */ new Date()).getHours();
	const currentMinute = (/* @__PURE__ */ new Date()).getMinutes();
	const isPastOperatingHours = currentHour > 18 || currentHour === 18 && currentMinute >= 30;
	const minSelectableDate = isPastOperatingHours ? tomorrowStr : todayStr;
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [visitDate, setVisitDate] = (0, import_react.useState)(() => {
		const now = /* @__PURE__ */ new Date();
		if (now.getHours() > 18 || now.getHours() === 18 && now.getMinutes() >= 30) {
			const d = /* @__PURE__ */ new Date();
			d.setDate(d.getDate() + 1);
			return getLocalDateString(d);
		}
		return getLocalDateString(now);
	});
	const [slotType, setSlotType] = (0, import_react.useState)("preset");
	const [presetSlot, setSlotPreset] = (0, import_react.useState)("Morning (10:00 AM)");
	const [customTime, setCustomTime] = (0, import_react.useState)("11:30 AM");
	const [plotMode, setPlotMode] = (0, import_react.useState)("preset");
	const [presetPlot, setPresetPlot] = (0, import_react.useState)(defaultPlotPreference);
	const [customSqFt, setCustomSqFt] = (0, import_react.useState)(2e3);
	const [customPlotType, setCustomPlotType] = (0, import_react.useState)("East Facing (Vaastu Compliant)");
	const [customPlotNotes, setCustomPlotNotes] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [websiteHoneypot, setWebsiteHoneypot] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open && defaultPlotPreference) if (defaultPlotPreference.toLowerCase().includes("custom")) {
			setPlotMode("custom");
			const matchNum = defaultPlotPreference.match(/(\d[\d,]*)/);
			if (matchNum && matchNum[1]) {
				const parsed = parseInt(matchNum[1].replace(/,/g, ""), 10);
				if (!isNaN(parsed) && parsed >= 600) setCustomSqFt(parsed);
			}
		} else {
			setPlotMode("preset");
			setPresetPlot(defaultPlotPreference);
		}
	}, [open, defaultPlotPreference]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (visitDate < minSelectableDate) setVisitDate(minSelectableDate);
	}, [
		open,
		visitDate,
		minSelectableDate
	]);
	const isToday = visitDate === todayStr;
	const allPresetsPassedToday = isToday && PRESET_SLOTS.every((slot) => isTimePassedForDate(slot.id, visitDate));
	const effectiveSlot = slotType === "custom" ? `Custom Time: ${customTime.trim() || "Client Flexible"}` : presetSlot;
	const customAllotmentCost = Math.round(customSqFt * BASE_RATE);
	const effectivePlotPreference = plotMode === "custom" ? `Custom ${customSqFt} Sq Ft (${formatCurrency(customAllotmentCost)} · ${customPlotType}${customPlotNotes ? ` · ${customPlotNotes}` : ""})` : presetPlot;
	const handleDateChange = (newDate) => {
		if (newDate && newDate < minSelectableDate) {
			setError("Visit date cannot be in the past. Please select today or an upcoming date.");
			setVisitDate(minSelectableDate);
			return;
		}
		setError("");
		setVisitDate(newDate);
		if (newDate === todayStr && slotType === "preset") {
			if (isTimePassedForDate(presetSlot, newDate)) {
				const nextAvailable = PRESET_SLOTS.find((s) => !isTimePassedForDate(s.id, newDate));
				if (nextAvailable) setSlotPreset(nextAvailable.id);
				else {
					setSlotType("custom");
					setCustomTime("05:30 PM");
				}
			}
		} else if (newDate > todayStr) {
			if (!presetSlot) setSlotPreset(PRESET_SLOTS[0]?.id || "Morning (10:00 AM)");
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (name.trim().length < 2) {
			setError("Please enter your full name.");
			return;
		}
		const cleanPhone = phone.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
			setError("Please enter a valid 10-digit Indian mobile number.");
			return;
		}
		if (!visitDate) {
			setError("Please select your preferred visit date.");
			return;
		}
		if (visitDate < minSelectableDate) {
			setError("Visit date cannot be in the past. Please select today or a future date.");
			return;
		}
		if (visitDate === todayStr) {
			if (isPastOperatingHours) {
				setError("Ground visits for today have ended (operating hours: 7:00 AM – 7:00 PM). Please select tomorrow or an upcoming date.");
				return;
			}
			if (slotType === "preset") {
				if (isTimePassedForDate(presetSlot, visitDate)) {
					setError(`The selected slot (${presetSlot}) has already passed for today. Please choose an upcoming slot or switch to tomorrow.`);
					return;
				}
			} else {
				if (!customTime.trim()) {
					setError("Please specify your preferred custom visit timing.");
					return;
				}
				const parsed = parseTimeHoursMinutes(customTime);
				if (!parsed) {
					setError("Please enter a valid visit timing (e.g. 11:30 AM or 05:00 PM).");
					return;
				}
				if (parsed.hours < 7 || parsed.hours >= 19) {
					setError("Visits are conducted between 7:00 AM and 7:00 PM. Please enter a time within operational hours.");
					return;
				}
				if (isTimePassedForDate(customTime, visitDate)) {
					setError(`The custom timing "${customTime}" has already passed for today. Please pick an upcoming time slot.`);
					return;
				}
			}
		} else if (slotType === "custom") {
			if (!customTime.trim()) {
				setError("Please specify your preferred custom visit timing.");
				return;
			}
			const parsed = parseTimeHoursMinutes(customTime);
			if (!parsed) {
				setError("Please enter a valid visit timing (e.g. 11:30 AM or 05:00 PM).");
				return;
			}
			if (parsed.hours < 7 || parsed.hours >= 19) {
				setError("Visits are conducted between 7:00 AM and 7:00 PM. Please enter a time within operational hours.");
				return;
			}
		}
		if (plotMode === "custom" && (!customSqFt || customSqFt < 600)) {
			setError("Minimum plot allotment size starts from 600 Sq Ft.");
			return;
		}
		setError("");
		setSubmitting(true);
		try {
			const created = await recordNewInquiry({
				name: name.trim(),
				phone: cleanPhone,
				plotPreference: effectivePlotPreference,
				visitDate,
				slot: effectiveSlot,
				cabPickup: false,
				pickupLocation: "On Site",
				message: message.trim(),
				website: websiteHoneypot
			});
			setConfirmedBooking(created);
			setStep("confirmed");
			saveLocalBooking({
				id: created.id,
				name: created.name,
				phone: created.phone,
				plotPreference: created.plotPreference,
				visitDate: created.visitDate,
				slot: created.slot,
				message: created.message
			});
			toast.success("Site Visit Reserved! Reference: " + created.id);
		} catch (err) {
			console.error("Site visit reservation error:", err);
			const errMsg = err instanceof Error ? err.message : "Failed to submit booking. Please try again.";
			setError(errMsg);
			toast.error(errMsg);
		} finally {
			setSubmitting(false);
		}
	};
	const openWhatsAppConfirmation = () => {
		if (!confirmedBooking) return;
		const text = [
			`Hello Vishal Chauhan, I have scheduled a Site Visit for Galaxy Green Sai Suraksha Nagar.`,
			`Booking Ref: ${confirmedBooking.id}`,
			`Name: ${confirmedBooking.name}`,
			`Mobile: ${confirmedBooking.phone}`,
			`Plot Preference: ${confirmedBooking.plotPreference}`,
			`Date & Slot: ${confirmedBooking.visitDate} · ${confirmedBooking.slot}`,
			confirmedBooking.message ? `Notes: ${confirmedBooking.message}` : ""
		].filter(Boolean).join("\n");
		window.open(`https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
	};
	const handleClose = () => {
		onOpenChange(false);
		setTimeout(() => {
			setStep("form");
			setError("");
		}, 300);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: handleClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "w-[calc(100vw-1rem)] sm:w-full max-w-xl bg-card border-border text-foreground p-4 sm:p-7 max-h-[min(92dvh,92vh)] overflow-y-auto pb-[max(1.25rem,env(safe-area-inset-bottom))]",
			children: step === "form" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "pr-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 sm:size-12 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/50 shrink-0 bg-white/10 flex items-center justify-center p-0.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/galaxy-green-emblem.png?v=2",
							alt: "Galaxy Green Official Seal",
							width: 48,
							height: 48,
							className: "size-full object-contain"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-1.5 sm:gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "border-primary text-primary bg-primary/10 text-[10px] uppercase font-mono shrink-0",
								children: "VIP Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground font-mono truncate",
								children: "Zero Obligation · Free Guided Ground Tour"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-lg sm:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 leading-snug",
							children: "Book Your Private Site Visit"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "text-xs text-muted-foreground mt-1",
					children: "Inspect physical plot boundary pillars, review original legal registry documents, and choose custom dimensions with complete freedom."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4 mt-3",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[11px] uppercase font-mono text-muted-foreground",
							children: "Your Name *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "e.g. Rahul Sharma",
							value: name,
							onChange: (e) => setName(e.target.value),
							className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[11px] uppercase font-mono text-muted-foreground",
							children: "Mobile Number *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "numeric",
							maxLength: 10,
							placeholder: "10-digit mobile",
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-[11px] uppercase font-mono text-muted-foreground flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3 text-primary" }), " Calendar (Year / Month / Date) *"]
										}), isToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-primary font-semibold",
											children: "Today"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										min: minSelectableDate,
										value: visitDate,
										onChange: (e) => handleDateChange(e.target.value),
										className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border font-mono font-medium"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5 mt-1.5",
										children: [
											!isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleDateChange(todayStr),
												className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${visitDate === todayStr ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-surface border-border text-muted-foreground hover:text-foreground"}`,
												children: "Today"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleDateChange(tomorrowStr),
												className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${visitDate === tomorrowStr ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-surface border-border text-muted-foreground hover:text-foreground"}`,
												children: "Tomorrow"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] font-mono text-muted-foreground ml-auto",
												children: "Past dates blocked"
											})
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-[11px] uppercase font-mono text-muted-foreground flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-primary" }), " Preferred Timing *"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "7 AM – 7 PM"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-1.5 mt-1",
									children: [PRESET_SLOTS.map((slotOption) => {
										const isPassed = isTimePassedForDate(slotOption.id, visitDate);
										const isSelected = slotType === "preset" && presetSlot === slotOption.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: isPassed,
											onClick: () => {
												if (isPassed) return;
												setSlotType("preset");
												setSlotPreset(slotOption.id);
												setError("");
											},
											className: `px-2 py-2 rounded-md text-[11px] font-mono border transition-all text-center relative ${isPassed ? "opacity-35 cursor-not-allowed bg-surface/30 line-through text-muted-foreground border-border/40 hover:bg-surface/30" : isSelected ? "bg-primary text-primary-foreground border-primary font-semibold shadow-glow ring-1 ring-primary/40" : "bg-surface border-border/80 text-muted-foreground hover:text-foreground hover:bg-surface-hover hover:border-primary/40"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block leading-tight",
												children: slotOption.label
											}), isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-[9px] text-destructive/90 font-mono no-underline uppercase tracking-wider font-semibold",
												children: "Passed"
											})]
										}, slotOption.id);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: isToday && isPastOperatingHours,
										onClick: () => {
											if (isToday && isPastOperatingHours) return;
											setSlotType("custom");
											setError("");
										},
										className: `px-2 py-2 rounded-md text-[11px] font-mono border transition-all text-center ${isToday && isPastOperatingHours ? "opacity-35 cursor-not-allowed bg-surface/30 text-muted-foreground line-through" : slotType === "custom" ? "bg-primary text-primary-foreground border-primary font-semibold shadow-glow ring-1 ring-primary/40" : "bg-surface border-border/80 text-muted-foreground hover:text-foreground hover:bg-surface-hover hover:border-primary/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block leading-tight font-semibold",
											children: "🕒 Clock Selector"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[9px] opacity-80 font-mono mt-0.5",
											children: "Hours, Mins, AM/PM"
										})]
									})]
								})] })]
							}),
							isToday && allPresetsPassedToday && !isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center justify-between gap-2 animate-in fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Standard morning/afternoon slots have passed today. Use the Clock Selector below or choose tomorrow." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleDateChange(tomorrowStr),
									className: "px-2 py-1 bg-primary text-primary-foreground text-[10px] rounded font-semibold whitespace-nowrap hover:bg-primary/90",
									children: "Tomorrow →"
								})]
							}),
							isToday && isPastOperatingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-xs font-mono flex items-center justify-between gap-2 animate-in fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visiting hours for today have ended (7:00 AM – 7:00 PM). Please select tomorrow or an upcoming date." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleDateChange(tomorrowStr),
									className: "px-2 py-1 bg-primary text-primary-foreground text-[10px] rounded font-semibold whitespace-nowrap hover:bg-primary/90",
									children: "Book for Tomorrow →"
								})]
							}),
							slotType === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "animate-in fade-in slide-in-from-top-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockTimePicker, {
									value: customTime,
									onChange: (newTime) => {
										setCustomTime(newTime);
										setError("");
									},
									selectedDate: visitDate
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 pt-2 border-t border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[11px] uppercase font-mono text-muted-foreground",
									children: "Plot Sizing & Configuration"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] font-mono text-emerald-400",
									children: [
										"₹",
										BASE_RATE.toLocaleString("en-IN"),
										" / Sq Ft Base Rate"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-2",
								children: [
									{
										id: "600 sq ft",
										size: "600 Sq Ft",
										price: `₹${(600 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Starting"
									},
									{
										id: "800 sq ft",
										size: "800 Sq Ft",
										price: `₹${(800 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Compact"
									},
									{
										id: "1000 sq ft",
										size: "1,000 Sq Ft",
										price: `₹${(1e3 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Most Popular"
									},
									{
										id: "1200 sq ft",
										size: "1,200 Sq Ft",
										price: `₹${(1200 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Duplex Villa"
									},
									{
										id: "1500 sq ft",
										size: "1,500 Sq Ft",
										price: `₹${(1500 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Executive"
									},
									{
										id: "2000 sq ft",
										size: "2,000 Sq Ft",
										price: `₹${(2e3 * BASE_RATE / 1e5).toFixed(2)} Lakh`,
										desc: "Luxury Estate"
									}
								].map((plotItem) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setPlotMode("preset");
										setPresetPlot(plotItem.id);
									},
									className: `p-2.5 rounded-lg border text-left transition-all ${plotMode === "preset" && presetPlot === plotItem.id ? "border-primary bg-primary/15 shadow-glow ring-1 ring-primary/40" : "border-border/80 bg-surface hover:bg-surface-hover hover:border-primary/40"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-display font-semibold text-foreground",
											children: plotItem.size
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-mono text-muted-foreground",
											children: plotItem.desc
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[11px] font-mono text-primary font-semibold mt-0.5",
										children: plotItem.price
									})]
								}, plotItem.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setPlotMode(plotMode === "custom" ? "preset" : "custom"),
								className: `w-full p-2.5 rounded-lg border flex items-center justify-between transition-all ${plotMode === "custom" ? "border-primary bg-primary/15 shadow-glow ring-1 ring-primary/50" : "border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-display font-semibold text-foreground",
										children: "Custom Size Requirement (Any Size On Buyer Wish)"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono text-primary border border-primary/40 px-2 py-0.5 rounded",
									children: plotMode === "custom" ? "Active" : "Click to Customize"
								})]
							}),
							plotMode === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-lg bg-surface/90 border border-primary/40 space-y-3 animate-in fade-in duration-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono font-semibold text-primary flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "size-3.5" }), " Flexible Plot Customizer"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono text-emerald-400 font-semibold",
											children: [
												formatCurrency(customAllotmentCost),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[10px] font-normal",
													children: "(@ ₹1,199/sq ft)"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 600,
												max: 25e3,
												step: 50,
												value: customSqFt,
												onChange: (e) => {
													const val = parseInt(e.target.value, 10);
													setCustomSqFt(isNaN(val) ? 600 : val);
												},
												className: "h-9 text-xs font-mono font-semibold bg-background pr-14"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute right-3 top-2.5 text-[10px] font-mono text-muted-foreground pointer-events-none",
												children: "Sq Ft"
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5 mt-2",
										children: [
											{
												sqFt: 750,
												label: "750 Sq Ft"
											},
											{
												sqFt: 1800,
												label: "1,800 Sq Ft"
											},
											{
												sqFt: 2500,
												label: "2,500 Sq Ft"
											},
											{
												sqFt: 3500,
												label: "3,500 Sq Ft"
											},
											{
												sqFt: 5e3,
												label: "5,000+ (Multi-Plot)"
											}
										].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCustomSqFt(item.sqFt),
											className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${customSqFt === item.sqFt ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background border-border text-muted-foreground hover:text-foreground"}`,
											children: item.label
										}, item.sqFt))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-[10px] uppercase font-mono text-muted-foreground flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3" }), " Orientation / Feature"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: customPlotType,
											onChange: (e) => setCustomPlotType(e.target.value),
											className: "mt-1 h-8 w-full px-2 text-[11px] bg-background border border-border rounded text-foreground focus:border-primary focus:outline-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "East Facing (Vaastu Compliant)",
													children: "East Facing (Vaastu)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Corner Plot (Dual 30ft Road)",
													children: "Corner Plot (Dual Road)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "North Facing (Prime Airflow)",
													children: "North Facing"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "West Facing (Sunset Boulevard)",
													children: "West Facing"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Adjacent Multi-Plots (Joint Family)",
													children: "Adjacent Multi-Plots"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Commercial Roadside Frontage",
													children: "Commercial Frontage"
												})
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-[10px] uppercase font-mono text-muted-foreground flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3" }), " Dimensions / Request"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "e.g. 50×50 ft, near park",
											value: customPlotNotes,
											onChange: (e) => setCustomPlotNotes(e.target.value),
											className: "mt-1 h-8 text-[11px] bg-background border-border"
										})] })]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[11px] uppercase font-mono text-muted-foreground",
						children: "Special Notes or Queries (Optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Need cab pickup, bank loan inquiry, boundary stone verification...",
						value: message,
						onChange: (e) => setMessage(e.target.value),
						className: "mt-1 h-9 sm:h-10 text-xs bg-surface border-border"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						name: "website",
						value: websiteHoneypot,
						onChange: (e) => setWebsiteHoneypot(e.target.value),
						tabIndex: -1,
						autoComplete: "off",
						"aria-hidden": "true",
						className: "hidden",
						style: { display: "none" }
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "alert",
						className: "flex items-start gap-2.5 text-xs text-destructive bg-destructive/10 border border-destructive/30 p-2.5 rounded-lg animate-in fade-in",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium leading-relaxed",
							children: error
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: submitting,
						className: "w-full h-11 sm:h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer mt-2",
						children: [
							submitting ? "Confirming Visit..." : "Schedule Site Tour",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-2" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-2 text-[10px] text-muted-foreground font-mono",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Instant Confirmation with Managing Director Vishal Chauhan" })]
					})
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center py-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-16 mx-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-16 rounded-full overflow-hidden shadow-glow ring-2 ring-primary/40 bg-white/10 flex items-center justify-center p-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png?v=2",
								alt: "Galaxy Green Official Seal",
								width: 64,
								height: 64,
								className: "size-full object-contain"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute -bottom-1 -right-1 size-6 rounded-full bg-emerald-500 text-black grid place-items-center shadow-lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "border-primary text-primary bg-primary/10 font-mono text-xs mb-2",
							children: ["Booking ID: ", confirmedBooking?.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-display uppercase tracking-tight text-foreground",
							children: "Site Visit Confirmed!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground max-w-sm mx-auto mt-1",
							children: [
								"Thank you, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: confirmedBooking?.name }),
								". Our project coordinator will contact you at +91 ",
								confirmedBooking?.phone,
								" to confirm your scheduled site visit."
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface/90 border border-border/80 rounded p-4 text-xs text-left space-y-1.5 font-mono",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Date & Slot:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-foreground font-semibold",
								children: [
									confirmedBooking?.visitDate,
									" (",
									confirmedBooking?.slot,
									")"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Plot Preference:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary font-semibold",
								children: confirmedBooking?.plotPreference
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: openWhatsAppConfirmation,
							className: "w-full sm:flex-1 h-11 uppercase tracking-wider text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white btn-shimmer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4 mr-2" }), " Open In WhatsApp"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: handleClose,
							className: "w-full sm:w-auto h-11 uppercase tracking-wider text-xs border-border",
							children: "Done"
						})]
					})
				]
			})
		})
	});
}
//#endregion
export { SiteVisitModal };
