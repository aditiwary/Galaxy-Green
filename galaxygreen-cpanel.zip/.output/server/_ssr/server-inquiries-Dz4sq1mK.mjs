import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { a as setActivePinHash, c as verifySignedPinHash, i as generateAdminToken, n as createServerRpc, o as signPinHash, r as executeQuery, s as verifyAdminToken } from "./auth-token-DZLAq3Jc.mjs";
import { t as inquirySchema } from "./inquiry-types-BhnwrXC3.mjs";
import { t as bcryptjs_default } from "../_libs/bcryptjs.mjs";
import fs from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-inquiries-Dz4sq1mK.js
var pinAttemptMap = /* @__PURE__ */ new Map();
var phoneSubmissionHistory = /* @__PURE__ */ new Map();
var globalSubmissionTimestamps = [];
var memoryDealerPinHash = null;
var memoryBaseRatePerSqFt = 1199;
var memoryInquiries = [];
var checkDbHealthFn_createServerFn_handler = createServerRpc({
	id: "505be61f9be0c6d90fc623b88117224ca63263ae0c12268ce4e49dcb70af582a",
	name: "checkDbHealthFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => checkDbHealthFn.__executeServer(opts));
var checkDbHealthFn = createServerFn({ method: "GET" }).handler(checkDbHealthFn_createServerFn_handler, async () => {
	try {
		const { getDbPool } = await import("./auth-token-DZLAq3Jc.mjs").then((n) => n.t).then((n) => n.s);
		const pool = await getDbPool();
		if (!pool) return {
			connected: false,
			message: "No MySQL connection configured. Running in cloud fallback mode."
		};
		await pool.query("SELECT 1 as ping");
		return {
			connected: true,
			message: "MySQL Online & Active"
		};
	} catch (err) {
		const errorObj = err;
		return {
			connected: false,
			message: errorObj?.code === "ECONNREFUSED" ? "MySQL connection refused. Please verify database credentials in .env or cPanel Node.js settings." : `Database offline: ${errorObj?.message || "Connection failed"}`
		};
	}
});
/**
* Strips HTML tags and script injections to protect against stored XSS.
*/
function sanitizeText(str) {
	if (!str) return null;
	return str.replace(/<[^>]*>?/gm, "").replace(/[&<>"']/g, (m) => {
		switch (m) {
			case "&": return "&amp;";
			case "<": return "&lt;";
			case ">": return "&gt;";
			case "\"": return "&quot;";
			case "'": return "&#039;";
			default: return m;
		}
	}).trim();
}
function mapRowToInquiry(row) {
	let visitDateStr = void 0;
	if (row["visit_date"]) {
		if (typeof row["visit_date"] === "string") visitDateStr = row["visit_date"];
		else if (row["visit_date"] instanceof Date) visitDateStr = row["visit_date"].toISOString().slice(0, 10);
	}
	let createdAtStr = (/* @__PURE__ */ new Date()).toISOString();
	if (row["created_at"]) {
		if (typeof row["created_at"] === "string") createdAtStr = row["created_at"];
		else if (row["created_at"] instanceof Date) createdAtStr = row["created_at"].toISOString();
	}
	return {
		id: String(row["id"] || ""),
		name: String(row["name"] || ""),
		phone: String(row["phone"] || ""),
		email: row["email"] ? String(row["email"]) : void 0,
		plotPreference: String(row["plot_preference"] || "1000 sq ft"),
		visitDate: visitDateStr,
		slot: String(row["slot"] || "Morning (10:00 AM)"),
		cabPickup: Boolean(row["cab_pickup"]),
		pickupLocation: String(row["pickup_location"] || "On Site"),
		message: row["message"] ? String(row["message"]) : void 0,
		status: row["status"] || "New",
		createdAt: createdAtStr
	};
}
function trySavePinDisk(hash) {
	try {
		fs.writeFileSync("/tmp/galaxy_green_pin.json", JSON.stringify({
			hash,
			time: Date.now()
		}));
	} catch {}
}
function tryLoadPinDisk() {
	try {
		if (fs.existsSync("/tmp/galaxy_green_pin.json")) {
			const raw = fs.readFileSync("/tmp/galaxy_green_pin.json", "utf-8");
			const parsed = JSON.parse(raw);
			if (parsed?.hash) return parsed.hash;
		}
	} catch {}
	return null;
}
function trySaveInquiriesDisk(list) {
	try {
		fs.writeFileSync("/tmp/galaxy_green_inquiries.json", JSON.stringify(list));
	} catch {}
}
function tryLoadInquiriesDisk() {
	try {
		if (fs.existsSync("/tmp/galaxy_green_inquiries.json")) {
			const raw = fs.readFileSync("/tmp/galaxy_green_inquiries.json", "utf-8");
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed)) return parsed;
		}
	} catch {}
	return [];
}
var verifyDealerPinFn_createServerFn_handler = createServerRpc({
	id: "e7ac86809fa5971ab2c5617edd3c6f0b3b2d480f6744776eb92f355f7285a156",
	name: "verifyDealerPinFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => verifyDealerPinFn.__executeServer(opts));
var verifyDealerPinFn = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyDealerPinFn_createServerFn_handler, async ({ data }) => {
	const trackerKey = "dealer_portal";
	const now = Date.now();
	let tracker = pinAttemptMap.get(trackerKey);
	if (!tracker) {
		tracker = {
			count: 0,
			lockoutUntil: 0
		};
		pinAttemptMap.set(trackerKey, tracker);
	}
	if (tracker.lockoutUntil > now) return {
		success: false,
		error: `Security lockout: Too many incorrect attempts. Please wait ${Math.ceil((tracker.lockoutUntil - now) / 1e3)} seconds.`
	};
	await new Promise((r) => setTimeout(r, 250));
	let storedPin = "";
	const rows = await executeQuery("SELECT dealer_pin FROM admin_config WHERE id = 1 LIMIT 1");
	if (rows && rows.length > 0 && rows[0]?.dealer_pin) {
		storedPin = String(rows[0].dealer_pin);
		setActivePinHash(storedPin);
		memoryDealerPinHash = storedPin;
		trySavePinDisk(storedPin);
	}
	if (!storedPin) storedPin = memoryDealerPinHash || tryLoadPinDisk() || "";
	if (!storedPin && data.clientPinToken) {
		const verified = verifySignedPinHash(data.clientPinToken);
		if (verified) {
			storedPin = verified;
			memoryDealerPinHash = verified;
			setActivePinHash(verified);
			trySavePinDisk(verified);
		}
	}
	const cleanInput = String(data.pin || "").trim();
	if (!cleanInput) return {
		success: false,
		error: "Password / PIN cannot be blank."
	};
	let isPinMatch = false;
	if (storedPin.startsWith("$2b$") || storedPin.startsWith("$2a$")) isPinMatch = await bcryptjs_default.compare(cleanInput, storedPin);
	else if (storedPin.length > 0) {
		isPinMatch = cleanInput === storedPin;
		if (isPinMatch) try {
			const upgradedHash = await bcryptjs_default.hash(cleanInput, 10);
			memoryDealerPinHash = upgradedHash;
			storedPin = upgradedHash;
			setActivePinHash(upgradedHash);
			trySavePinDisk(upgradedHash);
			await executeQuery("UPDATE admin_config SET dealer_pin = ? WHERE id = 1", [upgradedHash]);
		} catch (upgradeErr) {
			console.error("Failed to upgrade plaintext PIN to bcrypt:", upgradeErr);
		}
	} else {
		isPinMatch = cleanInput === "0000";
		if (isPinMatch) try {
			const defaultHash = await bcryptjs_default.hash("0000", 10);
			memoryDealerPinHash = defaultHash;
			storedPin = defaultHash;
			setActivePinHash(defaultHash);
			trySavePinDisk(defaultHash);
			await executeQuery("UPDATE admin_config SET dealer_pin = ? WHERE id = 1", [defaultHash]);
		} catch (e) {}
	}
	if (isPinMatch) {
		pinAttemptMap.delete(trackerKey);
		setActivePinHash(storedPin);
		return {
			success: true,
			token: generateAdminToken(storedPin),
			signedPinToken: storedPin ? signPinHash(storedPin) : void 0
		};
	}
	tracker.count += 1;
	if (tracker.count >= 5) {
		tracker.lockoutUntil = now + 3e5;
		return {
			success: false,
			error: "Access locked due to 5 failed attempts. Please try again after 5 minutes."
		};
	}
	pinAttemptMap.set(trackerKey, tracker);
	return {
		success: false,
		error: `Access denied. Invalid Password / PIN. (${5 - tracker.count} attempts remaining before lockout).`
	};
});
var getAdminConfigFn_createServerFn_handler = createServerRpc({
	id: "43cd7b54e5dc3bcb5518523224afd8375657788c242e7a28c12b315439ae2fbb",
	name: "getAdminConfigFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => getAdminConfigFn.__executeServer(opts));
var getAdminConfigFn = createServerFn({ method: "GET" }).handler(getAdminConfigFn_createServerFn_handler, async () => {
	const rows = await executeQuery("SELECT base_rate_per_sq_ft FROM admin_config WHERE id = 1 LIMIT 1");
	if (rows && rows.length > 0 && rows[0]?.base_rate_per_sq_ft !== void 0) return { baseRatePerSqFt: Number(rows[0].base_rate_per_sq_ft) || memoryBaseRatePerSqFt };
	return { baseRatePerSqFt: memoryBaseRatePerSqFt };
});
var updateAdminConfigFn_createServerFn_handler = createServerRpc({
	id: "0962a1e2dd3197bad26b146bdd61eed6e69f7038cdd069591f142ecc8c0685c1",
	name: "updateAdminConfigFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => updateAdminConfigFn.__executeServer(opts));
var updateAdminConfigFn = createServerFn({ method: "POST" }).validator((data) => data).handler(updateAdminConfigFn_createServerFn_handler, async ({ data }) => {
	let isAuthorized = false;
	if (data.token && verifyAdminToken(data.token)) isAuthorized = true;
	else if (data.dealerPin) {
		const rows = await executeQuery("SELECT dealer_pin FROM admin_config WHERE id = 1 LIMIT 1");
		let storedPin = rows && rows.length > 0 && rows[0]?.dealer_pin ? String(rows[0].dealer_pin) : "";
		if (!storedPin) storedPin = memoryDealerPinHash || tryLoadPinDisk() || "";
		if (!storedPin && data.clientPinToken) storedPin = verifySignedPinHash(data.clientPinToken) || "";
		const clean = String(data.dealerPin).trim();
		if (storedPin.startsWith("$2b$") || storedPin.startsWith("$2a$")) isAuthorized = await bcryptjs_default.compare(clean, storedPin);
		else if (storedPin) isAuthorized = clean === storedPin;
		else isAuthorized = clean === "0000";
	}
	if (!isAuthorized) return {
		success: false,
		error: "Unauthorized. Please unlock the portal with your password."
	};
	if (data.newPin) {
		const cleanNew = data.newPin.trim();
		if (cleanNew.length < 4 || cleanNew.length > 32) return {
			success: false,
			error: "Password / PIN must be between 4 and 32 characters."
		};
	}
	const updates = [];
	const params = [];
	let signedPinToken = void 0;
	if (data.newPin) {
		const cleanNew = data.newPin.trim();
		const hashedPin = await bcryptjs_default.hash(cleanNew, 10);
		memoryDealerPinHash = hashedPin;
		trySavePinDisk(hashedPin);
		setActivePinHash(hashedPin);
		signedPinToken = signPinHash(hashedPin);
		updates.push("dealer_pin = ?");
		params.push(hashedPin);
	}
	if (data.baseRatePerSqFt !== void 0) {
		memoryBaseRatePerSqFt = data.baseRatePerSqFt;
		updates.push("base_rate_per_sq_ft = ?");
		params.push(data.baseRatePerSqFt);
	}
	if (updates.length === 0) return {
		success: true,
		signedPinToken
	};
	const defaultHash = memoryDealerPinHash || await bcryptjs_default.hash("0000", 10);
	await executeQuery("INSERT IGNORE INTO admin_config (id, dealer_pin, base_rate_per_sq_ft) VALUES (1, ?, 1199)", [defaultHash]);
	const sql = `UPDATE admin_config SET ${updates.join(", ")} WHERE id = 1`;
	if (await executeQuery(sql, params) === null) return {
		success: true,
		signedPinToken,
		message: "Security Password updated and synchronized across cloud portal! All sessions logged out across all devices."
	};
	return {
		success: true,
		signedPinToken,
		message: "Security Password updated in MySQL database! All sessions logged out across all devices."
	};
});
var getInquiriesFn_createServerFn_handler = createServerRpc({
	id: "5e26ac6fa8f922e9958a1008e30aa59228ff5a307c4a951894aac4575e90051f",
	name: "getInquiriesFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => getInquiriesFn.__executeServer(opts));
var getInquiriesFn = createServerFn({ method: "POST" }).validator((data) => data).handler(getInquiriesFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) {
		console.warn("[Security Alert] Unauthorized access attempt to getInquiriesFn blocked.");
		return [];
	}
	const rows = await executeQuery("SELECT * FROM inquiries ORDER BY created_at DESC");
	if (rows && Array.isArray(rows) && rows.length > 0) return rows.map(mapRowToInquiry);
	if (memoryInquiries.length === 0) {
		const disk = tryLoadInquiriesDisk();
		if (disk.length > 0) memoryInquiries.push(...disk);
	}
	return memoryInquiries;
});
var submitInquiryFn_createServerFn_handler = createServerRpc({
	id: "4877a1cab4e33623d7dcfe7339376faf33cbd3233330988495f52b8680c031c9",
	name: "submitInquiryFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => submitInquiryFn.__executeServer(opts));
var submitInquiryFn = createServerFn({ method: "POST" }).validator((data) => inquirySchema.parse(data)).handler(submitInquiryFn_createServerFn_handler, async ({ data }) => {
	if (data.website && data.website.trim().length > 0) {
		console.warn("[Bot Defense] Automated bot submission rejected via honeypot trap.");
		return {
			success: true,
			inquiry: {
				id: `GG-2026-${Math.floor(1e3 + Math.random() * 9e3)}`,
				name: sanitizeText(data.name) || "Customer",
				phone: data.phone,
				plotPreference: data.plotPreference,
				slot: data.slot,
				cabPickup: false,
				pickupLocation: "On Site",
				status: "New",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}
		};
	}
	const now = Date.now();
	const tenMinsAgo = now - 6e5;
	const phoneHistory = (phoneSubmissionHistory.get(data.phone) || []).filter((t) => t > tenMinsAgo);
	if (phoneHistory.length >= 3) return {
		success: false,
		error: "Too many submissions. Our team will contact you shortly on your provided number."
	};
	phoneHistory.push(now);
	phoneSubmissionHistory.set(data.phone, phoneHistory);
	const fiveMinsAgo = now - 3e5;
	while (globalSubmissionTimestamps.length > 0 && globalSubmissionTimestamps[0] < fiveMinsAgo) globalSubmissionTimestamps.shift();
	if (globalSubmissionTimestamps.length >= 40) return {
		success: false,
		error: "High server load. Please call us directly or retry in a few moments."
	};
	globalSubmissionTimestamps.push(now);
	if (data.visitDate && data.visitDate.trim().length > 0) {
		const cleanDate = data.visitDate.trim();
		if (!/^\d{4}-\d{2}-\d{2}$/.test(cleanDate)) return {
			success: false,
			error: "Invalid date format. Please choose a valid date in YYYY-MM-DD format."
		};
		if (cleanDate < (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA")) return {
			success: false,
			error: "Visit date cannot be in the past. Please select today or a future date."
		};
	}
	const sanitizedName = sanitizeText(data.name) || "Guest";
	const sanitizedEmail = sanitizeText(data.email) || null;
	const sanitizedPlot = sanitizeText(data.plotPreference) || "1000 sq ft";
	const sanitizedMsg = sanitizeText(data.message) || null;
	const newInquiry = {
		name: sanitizedName,
		phone: data.phone,
		email: sanitizedEmail || void 0,
		plotPreference: sanitizedPlot,
		visitDate: data.visitDate || void 0,
		slot: data.slot,
		cabPickup: false,
		pickupLocation: "On Site",
		message: sanitizedMsg || void 0,
		id: `GG-2026-${Math.floor(1e3 + Math.random() * 9e3)}`,
		status: "New",
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const res = await executeQuery(`INSERT INTO inquiries (id, name, phone, email, plot_preference, visit_date, slot, cab_pickup, pickup_location, message, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
		newInquiry.id,
		newInquiry.name,
		newInquiry.phone,
		newInquiry.email || null,
		newInquiry.plotPreference,
		newInquiry.visitDate || null,
		newInquiry.slot,
		newInquiry.cabPickup ? 1 : 0,
		newInquiry.pickupLocation,
		newInquiry.message || null,
		newInquiry.status
	]);
	memoryInquiries.unshift(newInquiry);
	trySaveInquiriesDisk(memoryInquiries);
	if (res !== null) return {
		success: true,
		inquiry: newInquiry
	};
	return {
		success: true,
		inquiry: newInquiry,
		message: "Inquiry recorded and synchronized."
	};
});
var updateInquiryStatusFn_createServerFn_handler = createServerRpc({
	id: "e84fb555a6cb651ec16f9488a9b44867349925588b9630f1ed87aba7f6b9c588",
	name: "updateInquiryStatusFn",
	filename: "src/lib/server-inquiries.ts"
}, (opts) => updateInquiryStatusFn.__executeServer(opts));
var updateInquiryStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(updateInquiryStatusFn_createServerFn_handler, async ({ data }) => {
	if (!verifyAdminToken(data.token)) return {
		success: false,
		error: "Unauthorized"
	};
	const target = memoryInquiries.find((i) => i.id === data.id);
	if (target) {
		target.status = data.status;
		trySaveInquiriesDisk(memoryInquiries);
	}
	if (await executeQuery("UPDATE inquiries SET status = ? WHERE id = ?", [data.status, data.id]) !== null) return { success: true };
	return {
		success: true,
		message: "Lead status updated and synchronized."
	};
});
//#endregion
export { checkDbHealthFn_createServerFn_handler, getAdminConfigFn_createServerFn_handler, getInquiriesFn_createServerFn_handler, submitInquiryFn_createServerFn_handler, updateAdminConfigFn_createServerFn_handler, updateInquiryStatusFn_createServerFn_handler, verifyDealerPinFn_createServerFn_handler };
