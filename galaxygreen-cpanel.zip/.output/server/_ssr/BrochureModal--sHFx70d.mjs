import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as Button, t as Badge } from "./badge-CC6878ln.mjs";
import { E as MapPin, V as Download, c as Trees, it as Building2, m as ShieldCheck, z as ExternalLink } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-oBgWH-X9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BrochureModal--sHFx70d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BrochureModal({ open, onOpenChange }) {
	const [downloading, setDownloading] = (0, import_react.useState)(false);
	const handleDownload = async () => {
		setDownloading(true);
		try {
			const response = await fetch("/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf");
			if (!response.ok) throw new Error("File not found");
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
			toast.success("PDF brochure downloaded successfully!");
		} catch {
			const a = document.createElement("a");
			a.href = "/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			a.download = "Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf";
			a.target = "_blank";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			toast.success("Opening PDF brochure...");
		} finally {
			setDownloading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "w-[calc(100vw-1rem)] sm:w-full max-w-2xl bg-card border-border text-foreground p-4 sm:p-8 max-h-[min(92dvh,92vh)] overflow-y-auto pb-[max(1.25rem,env(safe-area-inset-bottom))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "pr-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 sm:size-12 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/50 shrink-0 bg-white/10 flex items-center justify-center p-0.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png?v=2",
								alt: "Galaxy Green Official Seal",
								width: 48,
								height: 48,
								className: "size-full object-contain"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 sm:gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "border-primary text-primary bg-primary/10 text-[10px] uppercase font-mono shrink-0",
									children: "Official Prospectus 2026"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground font-mono truncate",
									children: "Phase 1 Master Document"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "text-lg sm:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 leading-snug",
								children: "Galaxy Green Sai Suraksha Nagar"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground mt-1",
						children: "Complete architectural specifications, plot dimension matrix, and legal credentials for Amausi, Lucknow."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3 my-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-primary" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Road Infrastructure"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "30 ft, 25 ft, and 22 ft paved sector roads with integrated drainage."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trees, { className: "size-3.5 text-primary" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Green Environment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Manicured central park, flower gardens, tree-lined walking avenues."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram-gold size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-accent" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Immediate Registry"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "100% freehold land with instant Dakhil Kharij (mutation) assurance."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-architectural p-3.5 rounded-lg border border-border/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "icon-monogram-gold size-8 mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-accent" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-sm uppercase text-foreground",
									children: "Prime Proximity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: "1.5 km Railway · 2 km TS Mishra · 3 km CCS Airport · 2.5 km Expressway · 4 km Metro · 500 m Market."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border rounded overflow-hidden text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface px-4 py-2 font-mono text-[11px] uppercase tracking-wider text-primary font-semibold border-b border-border flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phase 1 Dimension & Pricing Matrix" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground font-normal",
							children: "₹1,199 / Sq Ft"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "divide-y divide-border/60 font-mono",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "600 Sq Ft (20 × 30 ft · Compact)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary font-semibold",
									children: "₹7,19,400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "800 Sq Ft (20 × 40 ft · Standard)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹9,59,200"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,000 Sq Ft (25 × 40 ft · Popular)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary font-semibold",
									children: "₹11,99,000"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,200 Sq Ft (30 × 40 ft · Villa)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹14,38,800"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3 bg-background/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1,500 Sq Ft (30 × 50 ft · Executive)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹17,98,500"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2,000 Sq Ft (40 × 50 ft · Grand Villa)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹23,98,000"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row gap-3 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleDownload,
							disabled: downloading,
							className: "w-full sm:flex-1 h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 mr-2" }), downloading ? "Preparing PDF..." : "Download Full PDF Brochure"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "/Galaxy_Green_Sai_Suraksha_Nagar_Brochure.pdf",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "w-full sm:w-auto inline-flex items-center justify-center h-12 px-4 rounded-md border border-border uppercase tracking-wider text-xs text-muted-foreground hover:text-foreground hover:bg-surface transition-colors font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 mr-1.5" }), "View PDF"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => onOpenChange(false),
							className: "w-full sm:w-auto h-12 uppercase tracking-wider text-xs border-border",
							children: "Close"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { BrochureModal };
