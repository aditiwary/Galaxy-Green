import { o as __toESM, r as __exportAll$1 } from "../_runtime.mjs";
import { i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import crypto from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-token-DZLAq3Jc.js
var auth_token_DZLAq3Jc_exports = /* @__PURE__ */ __exportAll$1({
	a: () => verifySignedPinHash,
	c: () => executeQuery,
	i: () => verifyAdminToken,
	n: () => setActivePinHash,
	o: () => createServerRpc,
	r: () => signPinHash,
	s: () => db_exports,
	t: () => generateAdminToken
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var db_exports = /* @__PURE__ */ __exportAll({
	executeQuery: () => executeQuery,
	getDbPool: () => getDbPool
});
var pool = null;
var envChecked = false;
async function ensureEnv() {
	if (typeof window !== "undefined" || envChecked) return;
	envChecked = true;
	try {
		const fs = await import("node:fs");
		const envPath = (await import("node:path")).resolve(process.cwd(), ".env");
		if (fs.existsSync(envPath)) {
			const content = fs.readFileSync(envPath, "utf-8");
			for (const line of content.split("\n")) {
				const trimmed = line.trim();
				if (trimmed && !trimmed.startsWith("#")) {
					const [key, ...rest] = trimmed.split("=");
					if (key && rest.length > 0) {
						const val = rest.join("=").trim().replace(/^["']|["']$/g, "");
						if (!process.env[key.trim()]) process.env[key.trim()] = val;
					}
				}
			}
		}
	} catch {}
	if (!process.env["DATABASE_URL"] && !process.env["MYSQL_HOST"]) process.env["DATABASE_URL"] = "mysql://root@localhost:3306/galaxy_green";
}
var tablesEnsured = false;
async function ensureTablesExist(p) {
	if (tablesEnsured) return;
	tablesEnsured = true;
	try {
		await p.execute(`
      CREATE TABLE IF NOT EXISTS \`plots\` (
        \`id\` VARCHAR(64) NOT NULL,
        \`number\` VARCHAR(32) NOT NULL,
        \`size_sq_ft\` INT UNSIGNED NOT NULL,
        \`dimensions\` VARCHAR(64) NOT NULL,
        \`facing\` ENUM('East', 'North', 'Park Facing', 'Boulevard Corner', 'West', 'South') NOT NULL,
        \`road_width\` VARCHAR(64) NOT NULL DEFAULT '30 ft Internal',
        \`rate_per_sq_ft\` DECIMAL(10, 2) NOT NULL DEFAULT 1199.00,
        \`status\` ENUM('Available', 'Fast Selling', 'Reserved', 'Sold Out') NOT NULL DEFAULT 'Available',
        \`feature\` TEXT NOT NULL,
        \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uk_plot_number\` (\`number\`),
        KEY \`idx_plot_status\` (\`status\`),
        KEY \`idx_plot_size\` (\`size_sq_ft\`),
        KEY \`idx_plot_facing\` (\`facing\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
		await p.execute(`
      CREATE TABLE IF NOT EXISTS \`inquiries\` (
        \`id\` VARCHAR(64) NOT NULL,
        \`name\` VARCHAR(100) NOT NULL,
        \`phone\` VARCHAR(20) NOT NULL,
        \`email\` VARCHAR(150) DEFAULT NULL,
        \`plot_preference\` VARCHAR(100) NOT NULL DEFAULT '1000 sq ft',
        \`visit_date\` DATE DEFAULT NULL,
        \`slot\` VARCHAR(50) NOT NULL DEFAULT 'Morning (10:00 AM)',
        \`cab_pickup\` TINYINT(1) NOT NULL DEFAULT 0,
        \`pickup_location\` VARCHAR(150) NOT NULL DEFAULT 'On Site',
        \`message\` TEXT DEFAULT NULL,
        \`status\` ENUM('New', 'Contacted', 'Visit Scheduled', 'Site Visit Done', 'Booked') NOT NULL DEFAULT 'New',
        \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        KEY \`idx_inquiry_phone\` (\`phone\`),
        KEY \`idx_inquiry_status\` (\`status\`),
        KEY \`idx_inquiry_created_at\` (\`created_at\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
		await p.execute(`
      CREATE TABLE IF NOT EXISTS \`admin_config\` (
        \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`dealer_pin\` VARCHAR(255) NOT NULL DEFAULT '$2b$10$Wrh1A0qrl8UaDHSNPlgZveCf2IU9hXWTTAzh7WLHQ7umENxSbjqda',
        \`base_rate_per_sq_ft\` DECIMAL(10, 2) NOT NULL DEFAULT 1199.00,
        \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
		await p.execute(`
      CREATE TABLE IF NOT EXISTS \`gallery_photos\` (
        \`id\` VARCHAR(64) NOT NULL,
        \`src\` LONGTEXT NOT NULL,
        \`title\` VARCHAR(150) NOT NULL,
        \`category\` VARCHAR(50) NOT NULL DEFAULT 'demarcation',
        \`category_label\` VARCHAR(100) NOT NULL DEFAULT 'Actual Site',
        \`tag\` VARCHAR(100) NOT NULL DEFAULT 'Live Photo',
        \`description\` TEXT,
        \`dimensions_label\` VARCHAR(100) DEFAULT NULL,
        \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        KEY \`idx_photo_category\` (\`category\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
		await p.execute("INSERT IGNORE INTO admin_config (id, dealer_pin, base_rate_per_sq_ft) VALUES (1, '$2b$10$Wrh1A0qrl8UaDHSNPlgZveCf2IU9hXWTTAzh7WLHQ7umENxSbjqda', 1199.00)");
		const [photosCount] = await p.execute("SELECT COUNT(*) as count FROM gallery_photos");
		if (photosCount && photosCount[0] && Number(photosCount[0].count) === 0) for (const photo of [
			[
				"site-photo-1",
				"/site-photos/galaxy-green-actual-site-1.jpg",
				"Ground Demarcation & Boundary Pillars",
				"demarcation",
				"Demarcation & Registry Ready",
				"Phase 1 Demarcation",
				"Clear on-ground plot boundaries with reinforced stone pillars and concrete edging. Plots start from compact 600 sq ft up to large custom footprints.",
				"Min 600 sq ft to Custom Requirements"
			],
			[
				"site-photo-2",
				"/site-photos/galaxy-green-actual-site-2.jpg",
				"Wide 30-Ft Internal Road & Sunset Streetlighting",
				"roads",
				"Internal Roads & Lighting",
				"30-Ft Road Infrastructure",
				"Wide, leveled internal township road network illuminated by active street lighting poles with utility pathways.",
				"30-Ft Wide Internal Avenue"
			],
			[
				"site-photo-3",
				"/site-photos/galaxy-green-actual-site-3.jpg",
				"Elevated Township Panorama & Surrounding Greenery",
				"panorama",
				"Township Horizon",
				"Open Green Environs",
				"Panoramic elevated perspective of Sai Suraksha Nagar showing peaceful residential surroundings and overhead water infrastructure.",
				"Pollution-Free Eco Zone"
			],
			[
				"site-photo-4",
				"/site-photos/galaxy-green-actual-site-4.jpg",
				"Main Access Boulevard & Plot Inventory Grid",
				"roads",
				"Boulevard & Demarcations",
				"Central Layout View",
				"Central access road traversing the plotted layout with clearly lined plot parcels ready for boundary walling.",
				"Allotment Starting ₹7.19 Lakh"
			],
			[
				"site-photo-5",
				"/site-photos/galaxy-green-actual-site-5.jpg",
				"Underground Utility Lines & Soil Leveling Progress",
				"construction",
				"Civil Engineering",
				"Ground Work Active",
				"Active compaction and leveling machinery preparing future residential sectors with pre-laid drainage conduits.",
				"Phase 1 Fast-Track Delivery"
			]
		]) await p.execute("INSERT IGNORE INTO gallery_photos (id, src, title, category, category_label, tag, description, dimensions_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", photo);
	} catch (err) {
		console.error("[MySQL Schema Init Warning]:", err);
	}
}
async function getDbPool() {
	if (typeof window !== "undefined") return null;
	if (pool) return pool;
	await ensureEnv();
	try {
		const mysql = await import("../_libs/mysql2+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const connectionUri = process.env["DATABASE_URL"] || process.env["MYSQL_URL"];
		if (connectionUri) {
			const isLocalhost = connectionUri.includes("localhost") || connectionUri.includes("127.0.0.1");
			const poolConfig = {
				uri: connectionUri,
				waitForConnections: true,
				connectionLimit: 10,
				queueLimit: 0,
				enableKeepAlive: true,
				keepAliveInitialDelay: 0
			};
			if (!isLocalhost && !connectionUri.includes("ssl=")) poolConfig.ssl = { rejectUnauthorized: false };
			pool = mysql.createPool(poolConfig);
		} else {
			const config = {
				host: process.env["MYSQL_HOST"] || "localhost",
				port: process.env["MYSQL_PORT"] ? parseInt(process.env["MYSQL_PORT"], 10) : 3306,
				user: process.env["MYSQL_USER"] || "root",
				password: process.env["MYSQL_PASSWORD"] || "",
				database: process.env["MYSQL_DATABASE"] || "galaxy_green",
				waitForConnections: true,
				connectionLimit: 10,
				queueLimit: 0,
				enableKeepAlive: true,
				keepAliveInitialDelay: 0
			};
			pool = mysql.createPool(config);
		}
		if (pool) await ensureTablesExist(pool);
		return pool;
	} catch (err) {
		console.error("Failed to initialize MySQL connection pool:", err);
		return null;
	}
}
async function executeQuery(sql, params = []) {
	try {
		const db = await getDbPool();
		if (!db) {
			console.error("[MySQL Error] Database connection pool is not available.");
			return null;
		}
		const sanitizedParams = params.map((p) => p === void 0 ? null : p);
		const [results] = await db.execute(sql, sanitizedParams);
		return results;
	} catch (err) {
		console.error("[MySQL Query Error]:", err);
		return null;
	}
}
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SECRET = process.env["ADMIN_SESSION_SECRET"] || "gg_dealer_session_secret_2026_secured";
var currentPinFingerprint = "";
var sessionRevocationTimestamp = 0;
function getFingerprint(hashOrPin) {
	return crypto.createHash("sha256").update(hashOrPin).digest("hex").slice(0, 16);
}
function setActivePinHash(hash) {
	currentPinFingerprint = getFingerprint(hash);
}
/**
* Generates a tamper-proof HMAC admin session token valid for 24 hours.
* Binds the token to the active PIN hash fingerprint so changing the PIN immediately
* invalidates all active sessions across all devices and networks.
*/
function generateAdminToken(pinHash) {
	const timestamp = Date.now();
	const fp = pinHash ? getFingerprint(pinHash) : currentPinFingerprint || "live";
	const payload = `admin_${timestamp}_${fp}`;
	return `${timestamp}_${fp}_${crypto.createHmac("sha256", SECRET).update(payload).digest("hex")}`;
}
/**
* Verifies the validity, expiration, cryptographic signature, and PIN-binding
* of an admin session token.
*/
function verifyAdminToken(token, expectedPinHash) {
	if (!token || typeof token !== "string") return false;
	const parts = token.split("_");
	if (parts.length === 3) {
		const [timeStr, fp, expectedHmac] = parts;
		if (!timeStr || !fp || !expectedHmac) return false;
		const time = parseInt(timeStr, 10);
		if (isNaN(time) || Date.now() - time > 864e5 || time > Date.now() + 6e4) return false;
		if (sessionRevocationTimestamp > 0 && time < sessionRevocationTimestamp) return false;
		const payload = `admin_${timeStr}_${fp}`;
		const actualHmac = crypto.createHmac("sha256", SECRET).update(payload).digest("hex");
		let isValidHmac = false;
		try {
			isValidHmac = crypto.timingSafeEqual(Buffer.from(actualHmac), Buffer.from(expectedHmac));
		} catch {
			return false;
		}
		if (!isValidHmac) return false;
		if (expectedPinHash) {
			if (fp !== getFingerprint(expectedPinHash)) return false;
		}
		return true;
	}
	if (parts.length === 2) {
		if (sessionRevocationTimestamp > 0) return false;
		const [timeStr, expectedHmac] = parts;
		if (!timeStr || !expectedHmac) return false;
		const time = parseInt(timeStr, 10);
		if (isNaN(time) || Date.now() - time > 864e5) return false;
		const actualHmac = crypto.createHmac("sha256", SECRET).update(`admin_${timeStr}`).digest("hex");
		try {
			return crypto.timingSafeEqual(Buffer.from(actualHmac), Buffer.from(expectedHmac));
		} catch {
			return false;
		}
	}
	return false;
}
/**
* Signs a bcrypt PIN hash with server HMAC to allow secure client-side persistence
* across stateless serverless instances when an external database is offline.
*/
function signPinHash(bcryptHash) {
	const signature = crypto.createHmac("sha256", SECRET).update(`pinhash_${bcryptHash}`).digest("hex");
	return `${Buffer.from(bcryptHash).toString("base64url")}.${signature}`;
}
/**
* Validates a signed PIN hash token and returns the verified bcrypt hash.
* Returns null if the signature is invalid or tampered.
*/
function verifySignedPinHash(token) {
	if (!token || typeof token !== "string") return null;
	const parts = token.split(".");
	if (parts.length !== 2) return null;
	const [payload, signature] = parts;
	if (!payload || !signature) return null;
	try {
		const bcryptHash = Buffer.from(payload, "base64url").toString("utf-8");
		const expectedSig = crypto.createHmac("sha256", SECRET).update(`pinhash_${bcryptHash}`).digest("hex");
		if (crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) return bcryptHash;
	} catch {
		return null;
	}
	return null;
}
//#endregion
export { setActivePinHash as a, verifySignedPinHash as c, generateAdminToken as i, createServerRpc as n, signPinHash as o, executeQuery as r, verifyAdminToken as s, auth_token_DZLAq3Jc_exports as t };
