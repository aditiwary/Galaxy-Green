import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as Button, r as cn, t as Badge } from "./badge-CC6878ln.mjs";
import { r as checkDbHealthFn, s as getAdminConfigFn, t as Input, u as updateAdminConfigFn } from "./server-inquiries-BZCzG7ab.mjs";
import { t as Label } from "./label-C0fbpOZw.mjs";
import { c as updateLeadStatus, i as fetchAllLeads, l as updateMarketBaseRate, n as deleteLead, r as exportLeadsToCsv, s as setClientPinToken, t as adminAddLead, u as verifyDealerPin } from "./leads-client-YV8ZcKah.mjs";
import { a as removePlot, c as uploadLivePhoto, i as removeLivePhoto, n as fetchLiveGalleryPhotos, o as setPlotStatus, r as fetchLivePlots, s as updateLivePlot, t as addLivePlot } from "./photos-client-CPnJd4S3.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { $ as Check, C as MessageCircle, D as Lock, H as Database, J as CircleCheck, L as Eye, M as Image$1, R as EyeOff, S as Pencil, V as Download, W as CloudUpload, a as User, h as Search, i as X, j as KeyRound, k as Layers, l as Trash2, m as ShieldCheck, q as CirclePlus, tt as Camera, v as RefreshCw, x as Phone } from "../_libs/lucide-react.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AdminLeadsDrawer-BPNuqqqA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/85 backdrop-blur-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, hideCloseButton = false, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [!hideCloseButton && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var STATUS_VARIANTS = {
	New: "border-primary text-primary bg-primary/10",
	Contacted: "border-amber-400 text-amber-300 bg-amber-400/10",
	"Visit Scheduled": "border-cyan-400 text-cyan-300 bg-cyan-400/10",
	"Site Visit Done": "border-purple-400 text-purple-300 bg-purple-400/10",
	Booked: "border-emerald-400 text-emerald-300 bg-emerald-400/20 font-bold"
};
var PLOT_STATUS_BADGES = {
	Available: "border-primary text-primary bg-primary/10",
	"Fast Selling": "border-amber-400 text-amber-300 bg-amber-400/10",
	Reserved: "border-purple-400 text-purple-300 bg-purple-400/10",
	"Sold Out": "border-destructive text-destructive bg-destructive/10 font-bold"
};
function AdminLeadsDrawer({ open, onOpenChange }) {
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(false);
	const [authToken, setAuthToken] = (0, import_react.useState)("");
	const authTokenRef = (0, import_react.useRef)("");
	const [pinInput, setPinInput] = (0, import_react.useState)("");
	const [pinError, setPinError] = (0, import_react.useState)(false);
	const [verifyingPin, setVerifyingPin] = (0, import_react.useState)(false);
	const [showPin, setShowPin] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		authTokenRef.current = authToken;
	}, [authToken]);
	const [leads, setLeads] = (0, import_react.useState)([]);
	const [loadingLeads, setLoadingLeads] = (0, import_react.useState)(false);
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [showAddLeadForm, setShowAddLeadForm] = (0, import_react.useState)(false);
	const [newLeadName, setNewLeadName] = (0, import_react.useState)("");
	const [newLeadPhone, setNewLeadPhone] = (0, import_react.useState)("");
	const [newLeadEmail, setNewLeadEmail] = (0, import_react.useState)("");
	const [newLeadPlot, setNewLeadPlot] = (0, import_react.useState)("1000 sq ft");
	const [newLeadDate, setNewLeadDate] = (0, import_react.useState)("");
	const [newLeadSlot, setNewLeadSlot] = (0, import_react.useState)("Morning (10:00 AM)");
	const [newLeadStatus, setNewLeadStatus] = (0, import_react.useState)("New");
	const [newLeadMessage, setNewLeadMessage] = (0, import_react.useState)("");
	const [addingLead, setAddingLead] = (0, import_react.useState)(false);
	const [baseMarketRate, setBaseMarketRate] = (0, import_react.useState)(1199);
	const [newMarketRateInput, setNewMarketRateInput] = (0, import_react.useState)("1199");
	const [updatePlotsWithMarketRate, setUpdatePlotsWithMarketRate] = (0, import_react.useState)(false);
	const [savingMarketRate, setSavingMarketRate] = (0, import_react.useState)(false);
	const [plots, setPlots] = (0, import_react.useState)([]);
	const [loadingPlots, setLoadingPlots] = (0, import_react.useState)(false);
	const [showAddPlotForm, setShowAddPlotForm] = (0, import_react.useState)(false);
	const [newPlotNumber, setNewPlotNumber] = (0, import_react.useState)("");
	const [newPlotSize, setNewPlotSize] = (0, import_react.useState)("1000");
	const [newPlotDims, setNewPlotDims] = (0, import_react.useState)("25 × 40 ft");
	const [newPlotFacing, setNewPlotFacing] = (0, import_react.useState)("East");
	const [newPlotRoad, setNewPlotRoad] = (0, import_react.useState)("30 ft Internal");
	const [newPlotRate, setNewPlotRate] = (0, import_react.useState)("1199");
	const [newPlotFeature, setNewPlotFeature] = (0, import_react.useState)("Freehold residential plot with clear title");
	const [newPlotIsNagarNigam, setNewPlotIsNagarNigam] = (0, import_react.useState)(false);
	const [editingPlot, setEditingPlot] = (0, import_react.useState)(null);
	const [editPlotNumber, setEditPlotNumber] = (0, import_react.useState)("");
	const [editPlotSize, setEditPlotSize] = (0, import_react.useState)("1000");
	const [editPlotDims, setEditPlotDims] = (0, import_react.useState)("25 × 40 ft");
	const [editPlotFacing, setEditPlotFacing] = (0, import_react.useState)("East");
	const [editPlotRoad, setEditPlotRoad] = (0, import_react.useState)("30 ft Internal");
	const [editPlotRate, setEditPlotRate] = (0, import_react.useState)("1199");
	const [editPlotStatus, setEditPlotStatus] = (0, import_react.useState)("Available");
	const [editPlotFeature, setEditPlotFeature] = (0, import_react.useState)("");
	const [editPlotIsNagarNigam, setEditPlotIsNagarNigam] = (0, import_react.useState)(false);
	const [savingPlotEdit, setSavingPlotEdit] = (0, import_react.useState)(false);
	const [galleryPhotos, setGalleryPhotos] = (0, import_react.useState)([]);
	const [loadingGallery, setLoadingGallery] = (0, import_react.useState)(false);
	const [showAddPhotoForm, setShowAddPhotoForm] = (0, import_react.useState)(false);
	const [photoTitle, setPhotoTitle] = (0, import_react.useState)("");
	const [photoCategory, setPhotoCategory] = (0, import_react.useState)("demarcation");
	const [photoSrc, setPhotoSrc] = (0, import_react.useState)("");
	const [photoDescription, setPhotoDescription] = (0, import_react.useState)("");
	const [photoDimensionsLabel, setPhotoDimensionsLabel] = (0, import_react.useState)("");
	const [uploadingPhoto, setUploadingPhoto] = (0, import_react.useState)(false);
	const [newPinInput, setNewPinInput] = (0, import_react.useState)("");
	const [confirmPinInput, setConfirmPinInput] = (0, import_react.useState)("");
	const [savingSettings, setSavingSettings] = (0, import_react.useState)(false);
	const [dbHealth, setDbHealth] = (0, import_react.useState)(null);
	const loadData = (0, import_react.useCallback)(async (tokenToUse) => {
		const activeToken = tokenToUse || authTokenRef.current;
		setLoadingPlots(true);
		setLoadingGallery(true);
		try {
			const [plotsData, photosData, configData, health] = await Promise.all([
				fetchLivePlots(),
				fetchLiveGalleryPhotos(),
				getAdminConfigFn(),
				checkDbHealthFn().catch(() => ({
					connected: false,
					message: "Offline"
				}))
			]);
			setPlots(plotsData);
			setGalleryPhotos(photosData);
			setDbHealth(health);
			if (configData?.baseRatePerSqFt) {
				setBaseMarketRate(configData.baseRatePerSqFt);
				setNewMarketRateInput(String(configData.baseRatePerSqFt));
			}
			if (activeToken) {
				setLoadingLeads(true);
				const leadsData = await fetchAllLeads(activeToken);
				setLeads(leadsData);
				setLoadingLeads(false);
			}
		} catch (err) {
			console.error(err);
		} finally {
			setLoadingPlots(false);
			setLoadingGallery(false);
			setLoadingLeads(false);
		}
	}, []);
	const handleLogout = (0, import_react.useCallback)(() => {
		setIsAuthenticated(false);
		setAuthToken("");
		authTokenRef.current = "";
		setPinInput("");
		setPinError(false);
		if (typeof window !== "undefined") {
			sessionStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_pin_signed_token");
		}
	}, []);
	const getActiveToken = (0, import_react.useCallback)(() => {
		if (authToken) return authToken;
		if (authTokenRef.current) return authTokenRef.current;
		if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || "";
		return "";
	}, [authToken]);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") {
			sessionStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_token");
			localStorage.removeItem("gg_dealer_pin_signed_token");
		}
		if (!open) {
			setIsAuthenticated(false);
			setAuthToken("");
			authTokenRef.current = "";
			setPinInput("");
			setPinError(false);
		} else {
			setIsAuthenticated(false);
			setAuthToken("");
			authTokenRef.current = "";
			setPinInput("");
			setPinError(false);
			loadData();
		}
	}, [open, loadData]);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const handleLeadsUpdated = async () => {
			const token = getActiveToken();
			if (token && isAuthenticated) try {
				const freshLeads = await fetchAllLeads(token);
				setLeads(freshLeads);
			} catch (e) {
				console.warn("Failed to auto-refresh leads:", e);
			}
		};
		window.addEventListener("gg_leads_updated", handleLeadsUpdated);
		return () => {
			window.removeEventListener("gg_leads_updated", handleLeadsUpdated);
		};
	}, [getActiveToken, isAuthenticated]);
	const handlePinSubmit = async (e) => {
		e.preventDefault();
		const clean = pinInput.trim();
		if (!clean) {
			setPinError(true);
			toast.error("Please enter your security password / PIN.");
			return;
		}
		setVerifyingPin(true);
		setPinError(false);
		try {
			const res = await verifyDealerPin(clean);
			if (res?.success && res.token) {
				authTokenRef.current = res.token;
				setAuthToken(res.token);
				setIsAuthenticated(true);
				if (typeof window !== "undefined") sessionStorage.setItem("gg_dealer_token", res.token);
				setPinError(false);
				setPinInput("");
				toast.success("Admin Portal Unlocked Successfully");
				await loadData(res.token);
			} else {
				setPinError(true);
				toast.error(res?.error || "Incorrect Password / PIN. Access Denied.");
			}
		} catch {
			setPinError(true);
			toast.error("Authentication failed. Please check connection.");
		} finally {
			setVerifyingPin(false);
		}
	};
	const handleLeadStatusChange = async (id, newStatus) => {
		if (await updateLeadStatus(id, newStatus, getActiveToken())) {
			setLeads((prev) => prev.map((l) => l.id === id ? {
				...l,
				status: newStatus
			} : l));
			toast.success(`Lead ${id} marked as "${newStatus}"`);
		} else toast.error("Unable to update lead status. Please try again.");
	};
	const handleDeleteLead = async (id, name) => {
		if (!confirm(`Are you sure you want to permanently delete inquiry from "${name}" (${id})?`)) return;
		const token = getActiveToken();
		if (await deleteLead(id, token)) {
			setLeads((prev) => prev.filter((l) => l.id !== id));
			toast.success(`Inquiry ${id} permanently removed.`);
		} else toast.error("Failed to delete inquiry. Please try again.");
	};
	const handleAdminAddLead = async (e) => {
		e.preventDefault();
		if (newLeadName.trim().length < 2) {
			toast.error("Please enter buyer name.");
			return;
		}
		const cleanPhone = newLeadPhone.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
			toast.error("Please enter a valid 10-digit Indian mobile number.");
			return;
		}
		setAddingLead(true);
		try {
			const created = await adminAddLead({
				name: newLeadName.trim(),
				phone: cleanPhone,
				email: newLeadEmail.trim() || void 0,
				plotPreference: newLeadPlot,
				visitDate: newLeadDate || void 0,
				slot: newLeadSlot,
				status: newLeadStatus,
				message: newLeadMessage.trim() || void 0
			}, getActiveToken());
			if (created) {
				setLeads((prev) => [created, ...prev]);
				setShowAddLeadForm(false);
				setNewLeadName("");
				setNewLeadPhone("");
				setNewLeadEmail("");
				setNewLeadMessage("");
				setNewLeadDate("");
				toast.success(`Inquiry created successfully! Ref: ${created.id}`);
			} else toast.error("Failed to create inquiry. Please try again.");
		} catch {
			toast.error("Error creating inquiry.");
		} finally {
			setAddingLead(false);
		}
	};
	const handleUpdateMarketRate = async (e) => {
		e.preventDefault();
		const parsed = parseInt(newMarketRateInput, 10);
		if (isNaN(parsed) || parsed < 100 || parsed > 5e4) {
			toast.error("Please enter a valid rate between ₹100 and ₹50,000 per Sq Ft.");
			return;
		}
		setSavingMarketRate(true);
		try {
			const res = await updateMarketBaseRate(parsed, updatePlotsWithMarketRate, getActiveToken());
			if (res.success && res.rate) {
				setBaseMarketRate(res.rate);
				setNewMarketRateInput(String(res.rate));
				if (updatePlotsWithMarketRate) {
					const freshPlots = await fetchLivePlots();
					setPlots(freshPlots);
					window.dispatchEvent(new CustomEvent("plots-updated"));
				}
				toast.success(`Market Base Rate updated to ₹${res.rate.toLocaleString("en-IN")} / Sq Ft!`);
			} else toast.error(res.message || "Failed to update market rate.");
		} catch {
			toast.error("Failed to update market base rate.");
		} finally {
			setSavingMarketRate(false);
		}
	};
	const handlePlotStatusChange = async (id, newStatus) => {
		setPlots((prev) => prev.map((p) => p.id === id ? {
			...p,
			status: newStatus
		} : p));
		if (await setPlotStatus(id, newStatus, getActiveToken())) {
			window.dispatchEvent(new CustomEvent("plots-updated"));
			toast.success("✓ Plot status auto-saved to database");
		} else toast.error("Unable to update plot status. Please try again.");
	};
	const handleDeletePlot = async (id, number) => {
		if (!confirm(`Are you sure you want to remove Plot ${number} from the live site?`)) return;
		setPlots((prev) => prev.filter((p) => p.id !== id));
		try {
			if (await removePlot(id, getActiveToken())) {
				window.dispatchEvent(new CustomEvent("plots-updated"));
				toast.success(`Plot ${number} deleted.`);
			} else toast.error("Unable to delete plot. Please try again.");
		} catch {
			toast.error("Failed to delete plot");
		}
	};
	const handleAddNewPlot = async (e) => {
		e.preventDefault();
		if (!newPlotNumber.trim()) {
			toast.error("Please enter a plot number");
			return;
		}
		const sizeNum = parseInt(newPlotSize, 10) || 1e3;
		const rateNum = parseInt(newPlotRate, 10) || 1199;
		const input = {
			number: newPlotNumber.trim().toUpperCase(),
			sizeSqFt: sizeNum,
			dimensions: newPlotDims.trim(),
			facing: newPlotFacing,
			roadWidth: newPlotRoad.trim(),
			ratePerSqFt: rateNum,
			status: "Available",
			feature: newPlotFeature.trim(),
			isNagarNigam: newPlotIsNagarNigam
		};
		const created = await addLivePlot(input, getActiveToken());
		if (created) {
			setPlots((prev) => [...prev, created]);
			window.dispatchEvent(new CustomEvent("plots-updated"));
			setShowAddPlotForm(false);
			setNewPlotNumber("");
			setNewPlotIsNagarNigam(false);
			toast.success(`Plot ${created.number} added to live website!`);
		} else toast.error("Unable to add plot. Please verify plot information and try again.");
	};
	const handleOpenEditPlot = (plot) => {
		setEditingPlot(plot);
		setEditPlotNumber(plot.number);
		setEditPlotSize(String(plot.sizeSqFt));
		setEditPlotDims(plot.dimensions);
		setEditPlotFacing(plot.facing);
		setEditPlotRoad(plot.roadWidth);
		setEditPlotRate(String(plot.ratePerSqFt));
		setEditPlotStatus(plot.status);
		setEditPlotFeature(plot.feature);
		setEditPlotIsNagarNigam(Boolean(plot.isNagarNigam));
	};
	const handleSavePlotEdit = async (e) => {
		if (e) e.preventDefault();
		if (!editingPlot) return;
		if (!editPlotNumber.trim()) {
			toast.error("Plot number cannot be empty.");
			return;
		}
		setSavingPlotEdit(true);
		try {
			const updates = {
				number: editPlotNumber.trim().toUpperCase(),
				sizeSqFt: parseInt(editPlotSize, 10) || editingPlot.sizeSqFt,
				dimensions: editPlotDims.trim(),
				facing: editPlotFacing,
				roadWidth: editPlotRoad.trim(),
				ratePerSqFt: parseInt(editPlotRate, 10) || editingPlot.ratePerSqFt,
				status: editPlotStatus,
				feature: editPlotFeature.trim(),
				isNagarNigam: editPlotIsNagarNigam
			};
			const res = await updateLivePlot(editingPlot.id, updates, getActiveToken());
			if (res) {
				setPlots((prev) => prev.map((p) => p.id === editingPlot.id ? {
					...p,
					...res
				} : p));
				window.dispatchEvent(new CustomEvent("plots-updated"));
				setEditingPlot(null);
				toast.success(`✓ Plot ${res.number} auto-saved to database!`, { duration: 4e3 });
			} else toast.error("Unable to update plot. Please try again.");
		} catch {
			toast.error("Failed to save plot updates to database.");
		} finally {
			setSavingPlotEdit(false);
		}
	};
	const handlePhotoFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (file.size > 15728640) {
			toast.error("Image file is too large. Please select a photo under 15MB.");
			return;
		}
		const reader = new FileReader();
		reader.onload = (event) => {
			const rawDataUrl = event.target?.result;
			if (!rawDataUrl) return;
			const img = new Image();
			img.onload = () => {
				try {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 1600;
					const MAX_HEIGHT = 1600;
					let { width, height } = img;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height = Math.round(height * MAX_WIDTH / width);
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width = Math.round(width * MAX_HEIGHT / height);
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					const ctx = canvas.getContext("2d");
					if (ctx) {
						ctx.drawImage(img, 0, 0, width, height);
						const compressed = canvas.toDataURL("image/jpeg", .85);
						setPhotoSrc(compressed);
					} else setPhotoSrc(rawDataUrl);
				} catch {
					setPhotoSrc(rawDataUrl);
				}
			};
			img.onerror = () => {
				setPhotoSrc(rawDataUrl);
			};
			img.src = rawDataUrl;
		};
		reader.readAsDataURL(file);
	};
	const handleUploadPhoto = async (e) => {
		e.preventDefault();
		if (!photoSrc.trim()) {
			toast.error("Please upload an image file or provide an image URL.");
			return;
		}
		if (!photoTitle.trim()) {
			toast.error("Please enter a title for the photo.");
			return;
		}
		setUploadingPhoto(true);
		try {
			const created = await uploadLivePhoto({
				src: photoSrc,
				title: photoTitle.trim(),
				category: photoCategory,
				categoryLabel: {
					demarcation: "Demarcation & Registry Ready",
					roads: "Internal Roads & Lighting",
					panorama: "Township Horizon",
					construction: "Civil Engineering"
				}[photoCategory] || "Actual Site",
				tag: photoCategory === "demarcation" ? "Boundary Pillars" : "Live Update",
				description: photoDescription.trim() || "Uploaded directly via Dealer Portal.",
				dimensionsLabel: photoDimensionsLabel.trim() || "Actual Site Progress"
			}, getActiveToken());
			if (created) {
				setGalleryPhotos((prev) => [created, ...prev]);
				setShowAddPhotoForm(false);
				setPhotoSrc("");
				setPhotoTitle("");
				setPhotoDescription("");
				setPhotoDimensionsLabel("");
				toast.success("Site photo published to live website!");
			} else toast.error("Unable to upload photo. Please try again.");
		} catch {
			toast.error("Error uploading photo. Please try again.");
		} finally {
			setUploadingPhoto(false);
		}
	};
	const handleDeletePhoto = async (id, title) => {
		if (!confirm(`Are you sure you want to remove "${title}" from the live site gallery?`)) return;
		setGalleryPhotos((prev) => prev.filter((p) => p.id !== id));
		try {
			if (await removeLivePhoto(id, getActiveToken())) toast.success("Photo removed from live gallery.");
			else toast.error("Unable to remove photo. Please try again.");
		} catch {
			toast.error("Failed to remove photo");
		}
	};
	const handleSaveSettings = async (e) => {
		e.preventDefault();
		const cleanNewPin = newPinInput.trim();
		if (!cleanNewPin) {
			toast.info("No new password entered.");
			return;
		}
		if (cleanNewPin !== confirmPinInput.trim()) {
			toast.error("New Password and Confirm Password do not match.");
			return;
		}
		if (cleanNewPin.length < 4 || cleanNewPin.length > 32) {
			toast.error("Password / PIN must be between 4 and 32 characters.");
			return;
		}
		if (!confirm("Confirm password update: Are you sure you want to change the security password? This will be permanently saved into your MySQL database and all active sessions will be logged out.")) return;
		setSavingSettings(true);
		try {
			const activeToken = authToken || authTokenRef.current || (typeof window !== "undefined" ? sessionStorage.getItem("gg_dealer_token") || "" : "");
			const res = await updateAdminConfigFn({ data: {
				token: activeToken || void 0,
				newPin: cleanNewPin
			} });
			const typedRes = res;
			if (typedRes?.success) {
				if (typedRes.signedPinToken) setClientPinToken(typedRes.signedPinToken);
				handleLogout();
				setNewPinInput("");
				setConfirmPinInput("");
				toast.success("Security Password updated in MySQL database! All sessions logged out across all devices. Please enter your new password to unlock.", { duration: 7e3 });
			} else toast.error(res?.error || "Failed to update security password in database.");
		} catch {
			toast.error("Failed to save settings. Please verify database connection.");
		} finally {
			setSavingSettings(false);
		}
	};
	const filteredLeads = leads.filter((lead) => {
		const matchesStatus = filterStatus === "all" || lead.status === filterStatus;
		const matchesQuery = lead.name.toLowerCase().includes(searchQuery.toLowerCase()) || lead.phone.includes(searchQuery) || lead.plotPreference.toLowerCase().includes(searchQuery.toLowerCase());
		return matchesStatus && matchesQuery;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
			side: "right",
			hideCloseButton: true,
			className: "w-full sm:max-w-3xl bg-[#0a1410] border-l border-border/80 p-0 flex flex-col h-full text-foreground overflow-hidden shadow-2xl",
			children: !isAuthenticated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full bg-[#0a1410]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-6 py-4 border-b border-border/80 bg-[#0c1612] shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-wider text-muted-foreground font-mono",
							children: "Admin Security Access"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						className: "size-9 rounded-lg border border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/50 text-muted-foreground hover:text-foreground flex items-center justify-center transition-all active:scale-95",
						title: "Close",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0a1410]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-20 rounded-full overflow-hidden shadow-glow ring-2 ring-primary/40 bg-white/10 flex items-center justify-center p-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/galaxy-green-emblem.png?v=2",
									alt: "Galaxy Green Logo",
									width: 80,
									height: 80,
									className: "size-full object-contain"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -bottom-1 -right-1 size-7 rounded-full bg-surface border border-accent/60 grid place-items-center shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 text-accent" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-display uppercase tracking-tight text-foreground",
							children: "Admin Management Portal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1 max-w-sm",
							children: "Enter your secure database password to manage customer leads, live plot inventory, and site configuration."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handlePinSubmit,
							className: "mt-6 w-full max-w-xs space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: showPin ? "text" : "password",
										maxLength: 32,
										autoFocus: true,
										placeholder: "Enter Security Password / PIN",
										value: pinInput,
										onChange: (e) => setPinInput(e.target.value),
										className: `h-12 text-center text-base tracking-widest font-mono bg-[#080f0c] border pr-10 ${pinError ? "border-destructive text-destructive" : "border-border"}`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPin(!showPin),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1",
										"aria-label": showPin ? "Hide Password" : "Show Password",
										children: showPin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									disabled: verifyingPin,
									className: "w-full h-11 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 btn-shimmer rounded-lg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 mr-2" }),
										" ",
										verifyingPin ? "Verifying with Database..." : "Unlock Portal"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground font-mono flex items-center justify-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 text-emerald-400" }), " Locked by default • End-to-end encrypted"]
								})
							]
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full overflow-hidden bg-[#0a1410]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
					className: "px-4 sm:px-6 py-3.5 sm:py-4 border-b border-border/80 bg-[#0c1612] shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 sm:gap-3 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 sm:size-11 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/50 shrink-0 bg-white/10 flex items-center justify-center p-0.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/galaxy-green-emblem.png?v=2",
									alt: "Galaxy Green Logo",
									width: 44,
									height: 44,
									className: "size-full object-contain"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 sm:gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] sm:text-xs uppercase tracking-widest text-primary font-mono font-medium truncate",
										children: "Admin Operations Portal"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
									className: "text-base sm:text-xl lg:text-2xl font-display uppercase tracking-tight text-foreground mt-0.5 truncate",
									children: "Galaxy Green Control Hub"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 sm:gap-2.5 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => {
									handleLogout();
									toast.info("Admin Portal Locked & Logged Out");
								},
								className: "h-8 sm:h-9 px-2.5 sm:px-3.5 text-[11px] sm:text-xs border-amber-500/40 text-amber-300 hover:bg-amber-500/10 font-mono rounded-lg transition-all",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 sm:mr-1.5 text-amber-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Lock & Log Out"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sm:hidden",
										children: "Lock"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									onOpenChange(false);
								},
								className: "size-8 sm:size-9 rounded-lg border border-border/80 bg-surface/80 hover:bg-surface hover:border-primary/50 text-muted-foreground hover:text-foreground flex items-center justify-center transition-all active:scale-95 shrink-0",
								title: "Close Admin Portal",
								"aria-label": "Close Admin Portal",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					defaultValue: "leads",
					className: "flex-1 flex flex-col overflow-hidden bg-[#0a1410]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 sm:px-6 py-2.5 sm:py-3 border-b border-border/80 bg-[#0c1612] shrink-0 overflow-x-auto scrollbar-none",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
								className: "bg-[#080f0c] border border-border/80 p-1 rounded-lg h-auto flex flex-nowrap gap-1 min-w-max sm:min-w-0 sm:w-full",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "leads",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Inquiries (",
											leads.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "plots",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Plots (",
											plots.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "gallery",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5 mr-1.5 shrink-0" }),
											" Photos (",
											galleryPhotos.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "settings",
										className: "flex-1 py-1.5 sm:py-2 px-2.5 sm:px-3 text-[11px] sm:text-xs uppercase font-semibold data-[state=active]:bg-primary/15 data-[state=active]:text-primary data-[state=active]:border data-[state=active]:border-primary/40 rounded-md transition-all whitespace-nowrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 mr-1.5 shrink-0" }), " PIN & DB"]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "leads",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 border-b border-border/80 bg-[#0c1612] space-y-4 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-4 gap-2.5 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase text-muted-foreground block font-mono",
													children: "Total"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-lg font-display text-primary",
													children: leads.length
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase text-muted-foreground block font-mono",
													children: "New"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-lg font-display text-amber-400",
													children: leads.filter((l) => l.status === "New").length
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase text-muted-foreground block font-mono",
													children: "Visits"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-lg font-display text-cyan-400",
													children: leads.filter((l) => l.status === "Visit Scheduled").length
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#0e1c16] p-2.5 rounded-lg border border-border/80 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase text-muted-foreground block font-mono",
													children: "Booked"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-lg font-display text-emerald-400",
													children: leads.filter((l) => l.status === "Booked").length
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												placeholder: "Search buyer name, mobile, plot...",
												value: searchQuery,
												onChange: (e) => setSearchQuery(e.target.value),
												className: "w-full h-10 pl-9 pr-3 text-xs rounded-lg bg-[#080f0c] border border-border/80 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: filterStatus,
													onChange: (e) => setFilterStatus(e.target.value),
													className: "h-10 px-3 text-xs rounded-lg bg-[#080f0c] border border-border/80 text-foreground focus:border-primary focus:outline-none",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "all",
															children: "All Statuses"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "New",
															children: "New"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Contacted",
															children: "Contacted"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Visit Scheduled",
															children: "Visit Scheduled"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Site Visit Done",
															children: "Site Visit Done"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Booked",
															children: "Booked"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													size: "sm",
													onClick: () => exportLeadsToCsv(leads),
													className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }), " Export CSV"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													size: "sm",
													onClick: () => setShowAddLeadForm((prev) => !prev),
													className: "h-10 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs uppercase font-semibold rounded-lg flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5" }), showAddLeadForm ? "Close Form" : "+ Add Inquiry"]
												})
											]
										})]
									})]
								}),
								showAddLeadForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAdminAddLead,
									className: "p-6 bg-[#0c1612] border-b border-border/80 space-y-4 shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "text-xs uppercase font-mono tracking-wider text-emerald-400 font-semibold flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5" }), " Add New Inquiry / Booking Request"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-mono text-muted-foreground",
												children: "Admin Direct Entry"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Client Name *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. Ramesh Sharma",
													value: newLeadName,
													onChange: (e) => setNewLeadName(e.target.value),
													required: true,
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Phone Number (10 digits) *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "9876543210",
													value: newLeadPhone,
													onChange: (e) => setNewLeadPhone(e.target.value),
													required: true,
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Email Address"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "email",
													placeholder: "client@example.com",
													value: newLeadEmail,
													onChange: (e) => setNewLeadEmail(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Plot Preference"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. Plot A-101 / Custom 1500 sqft",
													value: newLeadPlot,
													onChange: (e) => setNewLeadPlot(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Visit Date"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: newLeadDate,
													onChange: (e) => setNewLeadDate(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Time Slot"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. 10:30 AM",
													value: newLeadSlot,
													onChange: (e) => setNewLeadSlot(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Initial Status"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: newLeadStatus,
													onChange: (e) => setNewLeadStatus(e.target.value),
													className: "mt-1 w-full h-9 px-3 text-xs rounded-lg bg-[#080f0c] border border-border/80 text-foreground focus:border-primary focus:outline-none",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "New",
															children: "New"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Contacted",
															children: "Contacted"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Visit Scheduled",
															children: "Visit Scheduled"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Site Visit Done",
															children: "Site Visit Done"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Booked",
															children: "Booked"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "sm:col-span-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] uppercase font-mono text-muted-foreground",
														children: "Notes / Message"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "Special requirements, budget or meeting notes",
														value: newLeadMessage,
														onChange: (e) => setNewLeadMessage(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg text-foreground"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-end gap-2 pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "sm",
												onClick: () => setShowAddLeadForm(false),
												className: "h-8 text-xs text-muted-foreground hover:text-foreground",
												children: "Cancel"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: addingLead,
												size: "sm",
												className: "h-8 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg",
												children: addingLead ? "Adding..." : "Save Inquiry"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-6 space-y-3 bg-[#0a1410]",
									children: filteredLeads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-center py-16 text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: "No inquiries match your criteria."
										})
									}) : filteredLeads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-[#0e1c16] border border-border/80 hover:border-primary/50 transition-all rounded-xl p-4 space-y-3 shadow-sm card-architectural",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono text-[10px] text-muted-foreground uppercase",
															children: lead.id
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-muted-foreground",
															children: "·"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-muted-foreground",
															children: new Date(lead.createdAt).toLocaleDateString("en-IN", {
																day: "numeric",
																month: "short",
																hour: "2-digit",
																minute: "2-digit"
															})
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "font-display font-semibold text-base uppercase text-foreground mt-0.5 flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-primary" }),
														" ",
														lead.name
													]
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: `text-[10px] uppercase font-semibold px-2 py-0.5 ${STATUS_VARIANTS[lead.status] || ""}`,
													children: lead.status
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-background/50 p-2.5 rounded border border-border/40 font-mono",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[10px] block uppercase",
														children: "Plot"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
														className: "text-primary",
														children: lead.plotPreference
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[10px] block uppercase",
														children: "Visit Schedule"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														lead.visitDate || "Not chosen",
														" (",
														lead.slot,
														")"
													] })] }),
													lead.message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "col-span-full text-muted-foreground text-[11px] italic bg-surface/80 p-2 rounded",
														children: [
															"\"",
															lead.message,
															"\""
														]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-border/40",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														asChild: true,
														size: "sm",
														variant: "outline",
														className: "h-8 px-2.5 text-xs text-primary border-primary/30",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
															href: `tel:+91${lead.phone}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 mr-1" }), " Call"]
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														asChild: true,
														size: "sm",
														className: "h-8 px-2.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-white",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
															href: `https://wa.me/91${lead.phone}?text=${encodeURIComponent(`Hello ${lead.name}, this is Vishal Chauhan following up on your Galaxy Green Sai Suraksha Nagar inquiry (${lead.id}).`)}`,
															target: "_blank",
															rel: "noreferrer",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3 mr-1" }), " WhatsApp"]
														})
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-muted-foreground uppercase font-mono",
															children: "Status:"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
															value: lead.status,
															onChange: (e) => handleLeadStatusChange(lead.id, e.target.value),
															className: "h-7 px-2 text-[11px] font-medium rounded bg-background border border-border text-foreground",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "New",
																	children: "New"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "Contacted",
																	children: "Contacted"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "Visit Scheduled",
																	children: "Visit Scheduled"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "Site Visit Done",
																	children: "Site Visit Done"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "Booked",
																	children: "Booked"
																})
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
															type: "button",
															size: "sm",
															variant: "ghost",
															onClick: () => handleDeleteLead(lead.id, lead.name),
															className: "h-7 px-2 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 border border-rose-900/40 rounded transition-colors",
															title: "Delete inquiry",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3 mr-1" }), " Delete"]
														})
													]
												})]
											})
										]
									}, lead.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "plots",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 border-b border-border/80 bg-[#0c1612] flex items-center justify-between shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-display uppercase text-lg text-foreground",
										children: "Live Township Inventory"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Changes made here update the public website & interactive matrix instantly."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => setShowAddPlotForm((prev) => !prev),
										className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5 mr-1.5" }), showAddPlotForm ? "Close Form" : "+ Add Real Plot"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 px-6 bg-[#0e2118] border-b border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-0.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-mono tracking-wider uppercase text-emerald-400 font-semibold flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 animate-pulse" }),
													" ",
													"Current Base Market Rate"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "outline",
												className: "text-xs font-mono font-bold border-emerald-500/40 text-emerald-300 bg-emerald-950/40 px-2 py-0.5",
												children: [
													"₹",
													baseMarketRate.toLocaleString("en-IN"),
													" / Sq Ft"
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground",
											children: [
												"Controls the website minimum base price (currently ₹",
												baseMarketRate.toLocaleString("en-IN"),
												"), plots starting price, and ROI/EMI calculations."
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: handleUpdateMarketRate,
										className: "flex flex-wrap items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-mono text-muted-foreground",
														children: "₹"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "number",
														min: "100",
														step: "1",
														value: newMarketRateInput,
														onChange: (e) => setNewMarketRateInput(e.target.value),
														placeholder: String(baseMarketRate),
														className: "w-24 h-9 text-xs font-mono font-bold bg-[#080f0c] border-emerald-500/40 text-emerald-300 focus:border-emerald-400 rounded-lg text-center"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-mono text-muted-foreground",
														children: "/sqft"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex items-center gap-1.5 cursor-pointer text-[11px] font-mono text-muted-foreground hover:text-foreground select-none",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: updatePlotsWithMarketRate,
													onChange: (e) => setUpdatePlotsWithMarketRate(e.target.checked),
													className: "rounded border-border bg-[#080f0c] text-emerald-500 focus:ring-emerald-500 size-3.5"
												}), "Sync Active Plots"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: savingMarketRate,
												size: "sm",
												className: "h-9 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs uppercase font-semibold rounded-lg",
												children: savingMarketRate ? "Saving..." : "Update Rate"
											})
										]
									})]
								}),
								showAddPlotForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAddNewPlot,
									className: "p-6 bg-[#0c1612] border-b border-border/80 space-y-4 shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "text-xs uppercase font-mono tracking-wider text-primary font-semibold",
											children: "Add New Plot to Website"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Plot Number"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. E-501",
													value: newPlotNumber,
													onChange: (e) => setNewPlotNumber(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Area (Sq Ft)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													placeholder: "1000",
													value: newPlotSize,
													onChange: (e) => setNewPlotSize(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Dimensions"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "25 × 40 ft",
													value: newPlotDims,
													onChange: (e) => setNewPlotDims(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Rate / Sq Ft (₹)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													placeholder: "1199",
													value: newPlotRate,
													onChange: (e) => setNewPlotRate(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Facing"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: newPlotFacing,
													onChange: (e) => setNewPlotFacing(e.target.value),
													className: "mt-1 h-10 w-full px-2 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "East",
															children: "East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North",
															children: "North"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Park Facing",
															children: "Park Facing"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Boulevard Corner",
															children: "Boulevard Corner"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "West",
															children: "West"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South",
															children: "South"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Road Width"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "30 ft Internal",
													value: newPlotRoad,
													onChange: (e) => setNewPlotRoad(e.target.value),
													className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "col-span-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] uppercase font-mono text-muted-foreground",
														children: "Plot Highlights"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. Park facing with direct morning sun",
														value: newPlotFeature,
														onChange: (e) => setNewPlotFeature(e.target.value),
														className: "mt-1 h-10 text-xs bg-[#080f0c] border-border/80 rounded-lg"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "col-span-2 sm:col-span-4 bg-[#080f0c] p-3 rounded-lg border border-border/80 flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														htmlFor: "new-plot-nagar-nigam",
														className: "flex items-center gap-2.5 cursor-pointer select-none",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															id: "new-plot-nagar-nigam",
															type: "checkbox",
															checked: newPlotIsNagarNigam,
															onChange: (e) => setNewPlotIsNagarNigam(e.target.checked),
															className: "size-4 rounded border-border accent-emerald-500 cursor-pointer"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-semibold text-foreground block",
															children: "Inside Nagar Nigam"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[11px] text-muted-foreground block",
															children: newPlotIsNagarNigam ? "Selected: Front view will display \"Inside Nagar Nigam · This plot is inside the Nagar Nigam\"" : "Unticked: Will display nothing on frontend (outside Nagar Nigam)"
														})] })]
													}), newPlotIsNagarNigam && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] uppercase font-mono font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 rounded",
														children: "Inside Nagar Nigam"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											size: "sm",
											className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg",
											children: "Publish Plot to Website"
										})
									]
								}),
								editingPlot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSavePlotEdit,
									className: "p-6 border-b-2 border-primary/50 bg-[#0c2219] space-y-4 shrink-0 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pb-2 border-b border-primary/20",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
													className: "font-display uppercase text-sm font-semibold text-primary",
													children: ["Modifying Plot ", editingPlot.number]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												size: "sm",
												variant: "ghost",
												onClick: () => setEditingPlot(null),
												className: "h-7 text-xs text-muted-foreground hover:text-foreground",
												children: "Cancel"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Plot Number *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotNumber,
													onChange: (e) => setEditPlotNumber(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Size (Sq Ft) *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: editPlotSize,
													onChange: (e) => setEditPlotSize(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Dimensions *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotDims,
													onChange: (e) => setEditPlotDims(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Facing Direction"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: editPlotFacing,
													onChange: (e) => setEditPlotFacing(e.target.value),
													className: "mt-1 w-full h-9 px-3 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "East",
															children: "East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "West",
															children: "West"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North",
															children: "North"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South",
															children: "South"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "North-East",
															children: "North-East"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "South-East",
															children: "South-East"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Road Width *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotRoad,
													onChange: (e) => setEditPlotRoad(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Rate (₹ / Sq Ft) *"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: editPlotRate,
													onChange: (e) => setEditPlotRate(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
													required: true
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Status"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: editPlotStatus,
													onChange: (e) => setEditPlotStatus(e.target.value),
													className: "mt-1 w-full h-9 px-3 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Available",
															children: "Available"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Fast Selling",
															children: "Fast Selling"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Reserved",
															children: "Reserved"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Sold Out",
															children: "Sold Out"
														})
													]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													children: "Plot Highlights"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: editPlotFeature,
													onChange: (e) => setEditPlotFeature(e.target.value),
													className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "col-span-2 sm:col-span-4 bg-[#080f0c] p-3 rounded-lg border border-border/80 flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														htmlFor: "edit-plot-nagar-nigam",
														className: "flex items-center gap-2.5 cursor-pointer select-none",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															id: "edit-plot-nagar-nigam",
															type: "checkbox",
															checked: editPlotIsNagarNigam,
															onChange: (e) => setEditPlotIsNagarNigam(e.target.checked),
															className: "size-4 rounded border-border accent-emerald-500 cursor-pointer"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-semibold text-foreground block",
															children: "Inside Nagar Nigam"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[11px] text-muted-foreground block",
															children: editPlotIsNagarNigam ? "Selected: Front view will display \"Inside Nagar Nigam · This plot is inside the Nagar Nigam\"" : "Unticked: Will display nothing on frontend (outside Nagar Nigam)"
														})] })]
													}), editPlotIsNagarNigam && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] uppercase font-mono font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 rounded",
														children: "Inside Nagar Nigam"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#081812] border border-emerald-500/40 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-emerald-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Safe Database Commit:" }), " Changes write directly to MySQL database ledger and persist permanently."] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0",
												children: "Auto-Save Active"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												size: "sm",
												disabled: savingPlotEdit,
												className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg shadow-glow flex items-center gap-2",
												children: savingPlotEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 animate-spin mr-1.5" }), "Saving to Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 mr-1.5" }), "Save Changes & Auto-Commit"] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "outline",
												size: "sm",
												disabled: savingPlotEdit,
												onClick: () => setEditingPlot(null),
												className: "h-10 px-4 text-xs rounded-lg",
												children: "Cancel"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-6 space-y-3 bg-[#0a1410]",
									children: plots.map((plot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#0e1c16] border border-border/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-sm card-architectural",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 flex-wrap",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
														className: "font-display font-semibold text-base text-foreground",
														children: ["Plot ", plot.number]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono text-primary font-medium",
														children: [plot.sizeSqFt.toLocaleString(), " Sq Ft"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-muted-foreground font-mono",
														children: [
															"(",
															plot.dimensions,
															")"
														]
													}),
													plot.isNagarNigam && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] uppercase font-mono font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded",
														children: "Inside Nagar Nigam"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-muted-foreground text-[11px]",
												children: [
													"Facing: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: plot.facing }),
													" · Road:",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: plot.roadWidth }),
													" · Rate:",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
														"₹",
														plot.ratePerSqFt,
														"/sq ft"
													] })
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: plot.status,
													onChange: (e) => handlePlotStatusChange(plot.id, e.target.value),
													className: `h-8 px-2 text-xs font-semibold rounded-lg border ${PLOT_STATUS_BADGES[plot.status] || ""}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Available",
															children: "Available"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Fast Selling",
															children: "Fast Selling"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Reserved",
															children: "Reserved"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
															value: "Sold Out",
															children: "Sold Out"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													onClick: () => handleOpenEditPlot(plot),
													className: "size-8 text-primary hover:bg-primary/10 rounded-lg",
													title: `Edit Plot ${plot.number}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													onClick: () => handleDeletePlot(plot.id, plot.number),
													className: "size-8 text-destructive hover:bg-destructive/10 rounded-lg",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})
											]
										})]
									}, plot.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "gallery",
							className: "flex-1 flex flex-col overflow-hidden p-0 m-0 bg-[#0a1410]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 border-b border-border/80 bg-[#0c1612] flex items-center justify-between shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-display uppercase text-lg text-foreground",
										children: "Site Development Gallery"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Upload actual ground photos or remove any photo. Live-syncs directly to the public site gallery."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => setShowAddPhotoForm((prev) => !prev),
										className: "h-10 px-4 bg-primary text-primary-foreground text-xs uppercase font-semibold btn-shimmer rounded-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-3.5 mr-1.5" }), showAddPhotoForm ? "Close Form" : "+ Upload Photo"]
									})]
								}),
								showAddPhotoForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleUploadPhoto,
									className: "p-6 border-b border-border/80 bg-[#0e1c16] space-y-4 shrink-0 shadow-inner",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pb-2 border-b border-border/60",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "font-display uppercase text-xs font-semibold text-primary flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }), " Add Site Progress Photo"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-muted-foreground font-mono",
												children: "Direct upload or web image URL"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 md:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Upload From Device (Phone / Laptop)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "file",
														accept: "image/*",
														onChange: handlePhotoFileChange,
														className: "mt-1 block w-full text-xs text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-primary/20 file:text-primary hover:file:bg-primary/30 cursor-pointer bg-[#080f0c] p-2 border border-border/80 rounded-lg"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Or Paste Direct Image URL"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "https://images.unsplash.com/... or data:image/...",
														value: photoSrc,
														onChange: (e) => setPhotoSrc(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg font-mono text-[11px]"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Photo Title *"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. 40 Ft Blacktop Avenue & Storm Water Line",
														value: photoTitle,
														onChange: (e) => setPhotoTitle(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg",
														required: true
													})] })
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
															className: "text-[10px] text-muted-foreground uppercase font-mono",
															children: "Category"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
															value: photoCategory,
															onChange: (e) => setPhotoCategory(e.target.value),
															className: "mt-1 w-full h-9 px-2 text-xs bg-[#080f0c] border border-border/80 rounded-lg text-foreground",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "demarcation",
																	children: "Demarcation & Registry"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "roads",
																	children: "Internal Roads & Lighting"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "panorama",
																	children: "Township Horizon"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: "construction",
																	children: "Civil Engineering"
																})
															]
														})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
															className: "text-[10px] text-muted-foreground uppercase font-mono",
															children: "Progress / Metric Tag"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															placeholder: "e.g. 40 Ft Road Completion",
															value: photoDimensionsLabel,
															onChange: (e) => setPhotoDimensionsLabel(e.target.value),
															className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
														})] })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-[10px] text-muted-foreground uppercase font-mono",
														children: "Description / Caption"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "e.g. Concrete curb installation completed with LED illumination conduits.",
														value: photoDescription,
														onChange: (e) => setPhotoDescription(e.target.value),
														className: "mt-1 h-9 text-xs bg-[#080f0c] border-border/80 rounded-lg"
													})] }),
													photoSrc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 p-2 bg-[#080f0c] border border-border/80 rounded-lg",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
																src: photoSrc,
																alt: "Preview",
																className: "size-12 rounded object-cover border border-border/60"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex-1 min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "text-xs font-medium text-foreground truncate",
																	children: "Image ready to publish"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "text-[10px] text-muted-foreground font-mono",
																	children: "Will save to persistent database"
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																type: "button",
																variant: "ghost",
																size: "sm",
																onClick: () => setPhotoSrc(""),
																className: "text-xs h-7 text-destructive hover:bg-destructive/10",
																children: "Clear"
															})
														]
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: uploadingPhoto || !photoSrc.trim() || !photoTitle.trim(),
												size: "sm",
												className: "h-10 px-5 bg-primary text-primary-foreground uppercase text-xs font-semibold btn-shimmer rounded-lg",
												children: uploadingPhoto ? "Publishing Photo..." : "Publish Photo to Live Site"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "outline",
												size: "sm",
												onClick: () => setShowAddPhotoForm(false),
												className: "h-10 px-4 text-xs rounded-lg",
												children: "Cancel"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-y-auto p-6 space-y-4 bg-[#0a1410]",
									children: galleryPhotos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center py-16 px-4 bg-[#0e1c16] rounded-xl border border-dashed border-border/80 space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram size-12 mx-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-6 text-muted-foreground" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
												className: "font-display uppercase text-sm text-foreground",
												children: "No Site Photos Uploaded Yet"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground max-w-sm mx-auto",
												children: "Click \"+ Upload Photo\" above to upload actual development photos from your device or via direct image link."
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
										children: galleryPhotos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#0e1c16] border border-border/80 rounded-xl overflow-hidden shadow-sm card-architectural flex flex-col justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative aspect-[16/10] bg-[#080f0c] overflow-hidden group",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: photo.src,
													alt: photo.title,
													className: "w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "absolute top-2 left-2 flex flex-wrap gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-black/70 backdrop-blur-md text-emerald-400 border border-emerald-500/30",
														children: photo.categoryLabel || photo.category
													}), photo.tag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-primary/80 backdrop-blur-md text-primary-foreground",
														children: photo.tag
													})]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-4 space-y-2 flex-1 flex flex-col justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
															className: "font-display font-semibold text-sm text-foreground leading-snug line-clamp-1",
															children: photo.title
														}),
														photo.dimensionsLabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] font-mono text-primary font-medium",
															children: photo.dimensionsLabel
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-muted-foreground line-clamp-2 leading-relaxed",
															children: photo.description
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "pt-3 border-t border-border/60 flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] font-mono text-muted-foreground truncate",
														children: ["ID: ", photo.id]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "ghost",
														onClick: () => handleDeletePhoto(photo.id, photo.title),
														className: "h-8 px-2.5 text-xs text-destructive hover:bg-destructive/10 rounded-lg flex items-center gap-1.5",
														title: "Remove this photo from live website",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delete Photo" })]
													})]
												})]
											})]
										}, photo.id))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "settings",
							className: "flex-1 overflow-y-auto p-6 space-y-6 m-0 bg-[#0a1410]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSaveSettings,
								className: "space-y-6 max-w-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-6 bg-[#0e1c16] border border-border/80 rounded-xl space-y-4 shadow-sm card-architectural",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "icon-monogram size-9",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4 text-emerald-400" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
														className: "font-display uppercase text-sm font-semibold text-foreground",
														children: "MySQL Database Engine"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground font-mono",
														children: dbHealth?.connected ? "Relational MySQL database connected & synchronized" : "HMAC-SHA256 Encrypted Session & Local Sync · Cloud MySQL Ready"
													})] })]
												}), dbHealth?.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-1 rounded-full text-[10px] font-mono border border-emerald-500/40 text-emerald-400 bg-emerald-950/40 flex items-center gap-1.5 shrink-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Online & Active"]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-1 rounded-full text-[10px] font-mono border border-emerald-500/40 text-emerald-400 bg-emerald-950/40 flex items-center gap-1.5 shrink-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Cloud Storage Active"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-lg bg-[#081510] border border-emerald-500/30 text-[11px] text-emerald-300/90 leading-relaxed flex items-start gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
															className: "block text-emerald-200 font-semibold",
															children: dbHealth?.connected ? "Persistent Relational Database Active" : "Cryptographic Cloud Storage Synchronized"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-muted-foreground block",
															children: dbHealth?.connected ? "All plot availability updates, dealer security PINs, and customer leads are saved directly to your MySQL database." : "Your security PIN, plot availability, and customer inquiries are encrypted and automatically synchronized."
														}),
														!dbHealth?.connected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
															className: "mt-2 text-[10px] text-muted-foreground cursor-pointer group",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
																className: "font-mono text-emerald-400/90 hover:underline inline-flex items-center gap-1",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "How to connect external cloud MySQL (optional)" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "mt-2 p-2.5 rounded bg-black/40 border border-border/60 font-mono text-[10px] space-y-1 text-muted-foreground",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "To configure MySQL database credentials, update your server .env or cPanel Node.js application environment:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "text-white bg-black/80 p-1.5 rounded border border-white/10 select-all",
																	children: "DATABASE_URL=mysql://user:password@localhost:3306/galaxy_green"
																})]
															})]
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted-foreground leading-relaxed",
												children: [
													"Every customer inquiry and booked site visit is managed in your secure pipeline (",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
														className: "text-primary font-mono text-[11px]",
														children: "galaxy_green.inquiries"
													}),
													"). You have 100% data ownership with no recurring fees, API quotas, or third-party locking."
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Stored Inquiries"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-base font-display text-primary",
															children: [leads.length, " Records"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Active Plots"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-base font-display text-emerald-400",
															children: [plots.length, " Units"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#080f0c] p-3 rounded-lg border border-border/60 col-span-2 sm:col-span-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] uppercase font-mono text-muted-foreground block",
															children: "Session Security"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
															className: "text-xs font-mono text-foreground flex items-center gap-1 mt-0.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3 text-emerald-400" }), " HMAC-SHA256"]
														})]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Need a spreadsheet for Excel, Numbers, or offline records?" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													type: "button",
													size: "sm",
													onClick: () => exportLeadsToCsv(leads),
													disabled: leads.length === 0,
													className: "h-9 px-4 bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-semibold uppercase btn-shimmer rounded-lg shrink-0",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }),
														" Download Full CSV (",
														leads.length,
														")"
													]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-6 bg-[#0e1c16] border border-border/80 rounded-xl space-y-3.5 shadow-sm card-architectural",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "icon-monogram-gold size-9",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 text-accent" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
													className: "font-display uppercase text-sm font-semibold text-foreground",
													children: "Change Admin Security Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-muted-foreground font-mono",
													children: [
														"Bcrypt hashed authentication stored directly in MySQL (",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
															className: "text-primary",
															children: "admin_config.dealer_pin"
														}),
														")"
													]
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Set a new private security password or PIN (4-32 characters). Changing your password will immediately update the database, invalidate all active sessions, and log out all devices across your network. In the future, you must log in using the new password only."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md pt-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "New Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "password",
													maxLength: 32,
													placeholder: "Enter new password",
													value: newPinInput,
													onChange: (e) => setNewPinInput(e.target.value),
													className: "mt-1.5 h-11 text-center font-mono text-base bg-[#080f0c] border-border/80 tracking-widest rounded-lg"
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] uppercase font-mono text-muted-foreground",
													children: "Confirm New Password / PIN"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "password",
													maxLength: 32,
													placeholder: "Confirm new password",
													value: confirmPinInput,
													onChange: (e) => setConfirmPinInput(e.target.value),
													className: "mt-1.5 h-11 text-center font-mono text-base bg-[#080f0c] border-border/80 tracking-widest rounded-lg"
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-muted-foreground italic",
												children: "Leave blank to keep your current security password unchanged."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 bg-[#081812] border border-emerald-500/40 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-emerald-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Safe Database Persistence:" }), " Password changes are encrypted with bcrypt and stored in MySQL."] })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0",
													children: "Bcrypt Hash Encrypted"
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										disabled: savingSettings,
										className: "h-12 px-8 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90 btn-shimmer rounded-lg shadow-glow flex items-center gap-2",
										children: savingSettings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin mr-1.5" }), "Saving to Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 mr-1.5" }), "Save Changes & Remember in Database"] })
									})
								]
							})
						})
					]
				})]
			})
		})
	});
}
//#endregion
export { AdminLeadsDrawer };
