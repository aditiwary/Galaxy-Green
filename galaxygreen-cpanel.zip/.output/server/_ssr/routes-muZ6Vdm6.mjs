import { o as __toESM } from "../_runtime.mjs";
import { a as Trigger2, b as require_react, i as Root2, n as Header, r as Item, t as Content2, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as Button, r as cn, t as Badge } from "./badge-CC6878ln.mjs";
import { t as Input } from "./server-inquiries-BZCzG7ab.mjs";
import { a as fetchMarketBaseRate, o as recordNewInquiry } from "./leads-client-YV8ZcKah.mjs";
import { n as fetchLiveGalleryPhotos, r as fetchLivePlots } from "./photos-client-CPnJd4S3.mjs";
import { $ as Check, A as Landmark, B as Droplets, C as MessageCircle, D as Lock, E as MapPin, G as Clock, I as FileCheck, J as CircleCheck, N as HeartPulse, P as FileText, Q as ChevronDown, T as Maximize2, U as Compass, V as Download, X as ChevronRight, Z as ChevronLeft, _ as RotateCcw, a as User, at as BadgePercent, b as Plane, c as Trees, ct as ArrowDown, d as Sparkles, et as Car, g as Route, i as X, it as Building2, m as ShieldCheck, n as ZoomIn, nt as Calendar, ot as Award, p as ShoppingBag, r as Zap, rt as CalendarCheck, s as TrendingUp, st as ArrowRight, t as ZoomOut, tt as Camera, u as TramFront, w as Menu, z as ExternalLink } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-oBgWH-X9.mjs";
import { t as Textarea } from "./textarea-CHsQRKv8.mjs";
import { f as subscribeToBookings, i as getLocalDateString, r as getLocalBookings, s as isTimePassedForDate, u as saveLocalBooking } from "./visit-helpers-Cila1FpI.mjs";
import { t as ClockTimePicker } from "./ClockTimePicker-CK5prHzn.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-muZ6Vdm6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var township_entrance_default = "/assets/township-entrance-x7-uqFp1.jpg";
var luxury_villa_concept_default = "/assets/luxury-villa-concept-Sn-U05g1.jpg";
var lucknow_connectivity_default = "/assets/lucknow-connectivity-D3tu17Py.jpg";
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
function MasterPlanViewer({ onSelectPlotForBooking }) {
	const [plots, setPlots] = (0, import_react.useState)([]);
	const [selectedSizeFilter, setSelectedSizeFilter] = (0, import_react.useState)("all");
	const [activePlot, setActivePlot] = (0, import_react.useState)(null);
	const loadPlots = async () => {
		try {
			const data = await fetchLivePlots();
			setPlots(data);
		} catch (err) {
			console.error("Error loading plots:", err);
		}
	};
	(0, import_react.useEffect)(() => {
		loadPlots();
		const handleUpdate = () => loadPlots();
		window.addEventListener("plots-updated", handleUpdate);
		return () => window.removeEventListener("plots-updated", handleUpdate);
	}, []);
	const filteredPlots = plots.filter((p) => {
		if (selectedSizeFilter === "all") return true;
		if (selectedSizeFilter === "nagar-nigam") return Boolean(p.isNagarNigam);
		if (selectedSizeFilter === "1000") return p.sizeSqFt === 1e3;
		if (selectedSizeFilter === "1500") return p.sizeSqFt >= 1200 && p.sizeSqFt <= 1500;
		if (selectedSizeFilter === "2000+") return p.sizeSqFt >= 2e3;
		if (selectedSizeFilter === "corner") return p.facing === "Boulevard Corner";
		return true;
	});
	const formatINR = (val) => new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(val);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "masterplan",
		className: "section-shell bg-background border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "02 · Township Master Plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "section-title",
							children: "Interactive Plot Matrix & Layout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base text-muted-foreground leading-relaxed",
							children: "Explore demarcated freehold residential plots in Phase 1. Each parcel features direct wide-road access, underground electrification conduits, and instant registry eligibility."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 bg-primary/10 border border-primary/30 px-3.5 py-2 rounded text-xs text-primary font-mono",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phase 1: 72% Sold Out" })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex flex-wrap gap-2 pb-2 border-b border-border/50",
					children: [
						{
							id: "all",
							label: "All Available Plots"
						},
						{
							id: "nagar-nigam",
							label: "Inside Nagar Nigam"
						},
						{
							id: "1000",
							label: "1,000 Sq Ft (₹11.99 Lakh)"
						},
						{
							id: "1500",
							label: "1,200 - 1,500 Sq Ft"
						},
						{
							id: "2000+",
							label: "2,000+ Sq Ft (Grand Villa)"
						},
						{
							id: "corner",
							label: "Boulevard & Corner Plots"
						}
					].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSelectedSizeFilter(tab.id),
						className: `px-4 py-2 text-xs uppercase tracking-wider rounded transition-all font-medium ${selectedSizeFilter === tab.id ? "bg-primary text-primary-foreground font-semibold shadow-glow" : "bg-surface/80 text-muted-foreground hover:text-foreground hover:bg-surface border border-border"}`,
						children: tab.label
					}, tab.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: filteredPlots.map((plot) => {
						const totalPrice = plot.sizeSqFt * plot.ratePerSqFt;
						Math.round(totalPrice * .1);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							onClick: () => setActivePlot(plot),
							className: `card-architectural group p-6 rounded-xl relative overflow-hidden cursor-pointer ${plot.status === "Reserved" ? "opacity-75" : plot.status === "Fast Selling" ? "border-accent/60 bg-gradient-to-b from-accent/5 to-card" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs uppercase tracking-widest text-primary font-bold",
										children: ["Plot ", plot.number]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: `text-[10px] uppercase font-semibold tracking-wider ${plot.status === "Available" ? "border-primary/50 text-primary bg-primary/10" : plot.status === "Fast Selling" ? "border-accent text-accent bg-accent/15" : "border-muted text-muted-foreground bg-muted/20"}`,
										children: plot.status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-3xl font-display font-semibold text-foreground tracking-tight",
											children: plot.sizeSqFt.toLocaleString()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs uppercase text-muted-foreground font-mono",
											children: "Sq Ft"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground font-mono mt-0.5",
										children: ["Dim: ", plot.dimensions]
									})]
								}),
								plot.isNagarNigam && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 px-2.5 py-1.5 rounded-md bg-emerald-500/10 border border-emerald-500/30 flex flex-col gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-emerald-400 text-[11px] font-semibold uppercase tracking-wider font-mono",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 inline-block rounded-full bg-emerald-400 animate-pulse will-change-transform" }), "Inside Nagar Nigam"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-emerald-200/90 font-medium leading-snug",
										children: "This plot is inside the Nagar Nigam"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-4 h-px bg-border/60" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Orientation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-foreground flex items-center gap-1 font-medium",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3 text-primary" }),
													" ",
													plot.facing
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Road Access" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground font-medium",
												children: plot.roadWidth
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Base Rate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-primary font-medium",
												children: [
													"₹",
													plot.ratePerSqFt,
													" / sq ft"
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 pt-3 border-t border-border/80 flex items-end justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Estimated Value"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-lg font-display text-primary",
										children: formatINR(totalPrice)
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-primary flex items-center gap-1 font-medium group-hover:translate-x-0.5 transition-transform",
										children: ["Inspect ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
									})]
								})
							]
						}, plot.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
					open: !!activePlot,
					onOpenChange: (open) => !open && setActivePlot(null),
					children: activePlot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-w-xl bg-card border-border text-foreground p-6 sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "border-primary text-primary bg-primary/10",
										children: "Phase 1 Verified"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground font-mono",
										children: "Freehold Title · Ready For Registry"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
									className: "text-2xl font-display uppercase tracking-tight text-foreground mt-2",
									children: [
										"Plot ",
										activePlot.number,
										" · ",
										activePlot.sizeSqFt.toLocaleString(),
										" Sq Ft"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
									className: "text-sm text-muted-foreground",
									children: activePlot.feature
								})
							] }),
							activePlot.isNagarNigam && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 px-3.5 py-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/40 flex items-start gap-2.5 text-xs text-emerald-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/30 animate-pulse shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-emerald-400 uppercase font-mono tracking-wider text-xs block",
									children: "Inside Nagar Nigam"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-200/90 text-xs font-medium",
									children: "This plot is inside the Nagar Nigam"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3 my-5 p-4 rounded bg-surface/90 border border-border/60 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Dimensions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground text-sm font-medium",
										children: activePlot.dimensions
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Facing Direction"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-foreground text-sm font-medium flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3.5 text-primary" }),
											" ",
											activePlot.facing
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Frontage Road"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground text-sm font-medium",
										children: activePlot.roadWidth
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase text-muted-foreground block font-mono",
										children: "Booking Token (10%)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-accent text-sm font-medium",
										children: formatINR(Math.round(activePlot.sizeSqFt * activePlot.ratePerSqFt * .1))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2 pt-2 border-t border-border/40 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Total Plot Consideration:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-xl font-display text-primary",
											children: formatINR(activePlot.sizeSqFt * activePlot.ratePerSqFt)
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-xs text-muted-foreground bg-background/50 p-3 rounded border border-border/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Immediate registry and mutation (Dakhil Kharij) documentation ready" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bank loan pre-approved up to 80% with SBI, HDFC & PNB" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Demarcated boundary pillars installed on ground" })]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row items-center gap-3 mt-4 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "w-full sm:flex-1 h-12 uppercase tracking-wider text-xs bg-primary text-primary-foreground font-semibold hover:bg-primary/90 btn-shimmer",
									onClick: () => {
										const num = activePlot.number;
										const sz = `${activePlot.sizeSqFt} sq ft`;
										setActivePlot(null);
										onSelectPlotForBooking(num, sz);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 mr-2" }), " Book This Plot Now"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "w-full sm:w-auto h-12 uppercase tracking-wider text-xs border-border hover:bg-surface",
									onClick: () => setActivePlot(null),
									children: "Close"
								})]
							})
						]
					})
				})
			]
		})
	});
}
var DEFAULT_SITE_PHOTOS = [
	{
		id: "site-photo-1",
		src: "/site-photos/galaxy-green-actual-site-1.jpg",
		title: "Ground Demarcation & Boundary Pillars",
		category: "demarcation",
		categoryLabel: "Demarcation & Registry Ready",
		tag: "Phase 1 Demarcation",
		dimensionsLabel: "Min 600 sq ft to Custom Requirements",
		description: "Clear on-ground plot boundaries with reinforced stone pillars and concrete edging. Plots start from compact 600 sq ft up to large custom residential and commercial footprints as per buyer preference.",
		highlights: [
			"Physical boundary curbing & corner pillars installed",
			"Immediate registry & mutation (Dakhil Kharij) ready",
			"Customizable plot dimensions starting from 600 sq ft",
			"Direct frontage onto wide 30ft internal access roads"
		]
	},
	{
		id: "site-photo-2",
		src: "/site-photos/galaxy-green-actual-site-2.jpg",
		title: "Wide 30-Ft Internal Road & Sunset Streetlighting",
		category: "roads",
		categoryLabel: "Internal Roads & Lighting",
		tag: "30-Ft Road Infrastructure",
		dimensionsLabel: "30-Ft Wide Internal Avenue",
		description: "Wide, leveled internal township road network illuminated by active street lighting poles. Provides comfortable two-way vehicular transit with dedicated drainage conduits and utility pathways.",
		highlights: [
			"30-ft wide internal avenue for smooth two-way driving",
			"Functional electric poles and evening streetlights active",
			"Direct connectivity to Kanpur-Lucknow Expressway (3 km)",
			"Unobstructed access for construction materials and private vehicles"
		]
	},
	{
		id: "site-photo-3",
		src: "/site-photos/galaxy-green-actual-site-3.jpg",
		title: "Elevated Township Panorama & Surrounding Greenery",
		category: "panorama",
		categoryLabel: "Township Horizon",
		tag: "Open Green Environs",
		dimensionsLabel: "Pollution-Free Eco Zone",
		description: "Panoramic elevated perspective of Sai Suraksha Nagar showing peaceful residential surroundings, lush tree lines, elevated water supply infrastructure, and serene open horizons near Amausi.",
		highlights: [
			"Overhead water reservoir ensuring reliable high-pressure water supply",
			"Clean, green environment away from city congestion",
			"Close proximity to Railway Station (1.5 km) & Main Market (500 m)",
			"Vastu-compliant residential zoning with open morning sunlight"
		]
	},
	{
		id: "site-photo-4",
		src: "/site-photos/galaxy-green-actual-site-4.jpg",
		title: "Main Access Boulevard & Plot Inventory Grid",
		category: "roads",
		categoryLabel: "Boulevard & Demarcations",
		tag: "Central Layout View",
		dimensionsLabel: "Allotment Starting ₹7.19 Lakh",
		description: "Central access road traversing the plotted layout with clearly lined plot parcels ready for boundary walling. Several independent residential homes are already actively being constructed in this sector.",
		highlights: [
			"Transparent Phase 1 allotment at ₹1,199 / sq ft",
			"Compact 600 sq ft villas start at only ₹7.19 Lakh",
			"Wide turning radiuses suitable for SUVs and delivery trucks",
			"Independent housing cluster already developing rapidly on site"
		]
	},
	{
		id: "site-photo-5",
		src: "/site-photos/galaxy-green-actual-site-5.jpg",
		title: "Active Residential Construction & Plot Edging",
		category: "construction",
		categoryLabel: "Active Construction",
		tag: "Ground Reality",
		dimensionsLabel: "Fast-Paced Site Progress",
		description: "Top-angle view displaying finished concrete boundary curbs on vacant plots alongside multi-storey brick masonry construction underway. Demonstrates authentic livability and rapid on-site pace.",
		highlights: [
			"Real residential buildings under active brick and pillar construction",
			"Immediate possession allows buyers to begin construction right away",
			"Only 2 km from TS Mishra Medical College & Hospital",
			"3 km from CCS Airport & 4 km from Metro Station"
		]
	},
	{
		id: "site-photo-6",
		src: "/site-photos/galaxy-green-airport-connectivity.jpg",
		title: "Chaudhary Charan Singh International Airport & Amausi Plots",
		category: "panorama",
		categoryLabel: "Airport & Metro Connectivity",
		tag: "Prime Airport Vicinity",
		dimensionsLabel: "3 Km from CCS International Airport",
		description: "Strategic aerial master photograph showing Chaudhary Charan Singh International Airport (Terminal 1 & 2, Runway 09/27), Kanpur Road (NH27), Amausi Metro Station, and the immediate proximity of Amausi available plots at Galaxy Green Sai Suraksha Nagar.",
		highlights: [
			"Direct proximity to CCS International Airport (LKO) & Terminals 1 & 2",
			"Immediate access to Kanpur Road (NH27) & Amausi Metro Station",
			"Rapidly appreciating high-capital growth corridor",
			"Direct expressway arterial connectivity across Lucknow & NCR"
		]
	}
];
function ActualSiteGallery({ onScheduleVisit }) {
	const [activeTab, setActiveTab] = (0, import_react.useState)("all");
	const [lightboxIndex, setLightboxIndex] = (0, import_react.useState)(null);
	const [photos, setPhotos] = (0, import_react.useState)(DEFAULT_SITE_PHOTOS);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		const loadPhotos = async () => {
			try {
				const live = await fetchLiveGalleryPhotos();
				if (isMounted && live && live.length > 0) {
					const enriched = live.map((photo) => {
						const defaultMatch = DEFAULT_SITE_PHOTOS.find((d) => d.id === photo.id || d.title.toLowerCase() === photo.title.toLowerCase());
						return {
							id: photo.id,
							src: photo.src,
							title: photo.title,
							category: photo.category,
							categoryLabel: photo.categoryLabel || defaultMatch?.categoryLabel || "Actual Site",
							tag: photo.tag || defaultMatch?.tag || "Live Update",
							dimensionsLabel: photo.dimensionsLabel || defaultMatch?.dimensionsLabel || "On-Ground Progress",
							description: photo.description || defaultMatch?.description || "Authentic on-site photograph of Galaxy Green township in Lucknow.",
							highlights: photo.highlights && photo.highlights.length > 0 ? photo.highlights : defaultMatch?.highlights || [
								"Physical boundary curbs & pillars installed",
								"Immediate registry & mutation (Dakhil Kharij) ready",
								"Direct frontage onto wide 30ft internal roads"
							]
						};
					});
					setPhotos(enriched);
				}
			} catch (err) {
				console.warn("Failed to load live gallery photos:", err);
			}
		};
		loadPhotos();
		const handleUpdate = () => {
			loadPhotos();
		};
		window.addEventListener("gallery-updated", handleUpdate);
		return () => {
			isMounted = false;
			window.removeEventListener("gallery-updated", handleUpdate);
		};
	}, []);
	const filteredPhotos = activeTab === "all" ? photos : photos.filter((photo) => photo.category === activeTab);
	const [galleryZoom, setGalleryZoom] = (0, import_react.useState)(1);
	const [galleryPan, setGalleryPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [isGalleryDragging, setIsGalleryDragging] = (0, import_react.useState)(false);
	const galleryDragStartRef = (0, import_react.useRef)(null);
	const resetGalleryView = (0, import_react.useCallback)(() => {
		setGalleryZoom(1);
		setGalleryPan({
			x: 0,
			y: 0
		});
	}, []);
	const openLightbox = (index) => {
		if (index >= 0 && index < filteredPhotos.length) {
			resetGalleryView();
			setLightboxIndex(index);
		}
	};
	const closeLightbox = (0, import_react.useCallback)(() => {
		resetGalleryView();
		setLightboxIndex(null);
	}, [resetGalleryView]);
	const nextPhoto = (0, import_react.useCallback)(() => {
		if (lightboxIndex === null || filteredPhotos.length === 0) return;
		resetGalleryView();
		setLightboxIndex((prev) => prev === null ? null : (prev + 1) % filteredPhotos.length);
	}, [
		lightboxIndex,
		filteredPhotos.length,
		resetGalleryView
	]);
	const prevPhoto = (0, import_react.useCallback)(() => {
		if (lightboxIndex === null || filteredPhotos.length === 0) return;
		resetGalleryView();
		setLightboxIndex((prev) => prev === null ? null : (prev - 1 + filteredPhotos.length) % filteredPhotos.length);
	}, [
		lightboxIndex,
		filteredPhotos.length,
		resetGalleryView
	]);
	(0, import_react.useEffect)(() => {
		if (lightboxIndex !== null) {
			const originalOverflow = document.body.style.overflow;
			document.body.style.overflow = "hidden";
			return () => {
				document.body.style.overflow = originalOverflow;
			};
		}
	}, [lightboxIndex]);
	const handleGalleryPointerDown = (e) => {
		if (galleryZoom <= 1) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		setIsGalleryDragging(true);
		galleryDragStartRef.current = {
			startX: e.clientX,
			startY: e.clientY,
			initialPanX: galleryPan.x,
			initialPanY: galleryPan.y
		};
	};
	const handleGalleryPointerMove = (e) => {
		if (!isGalleryDragging || !galleryDragStartRef.current) return;
		const deltaX = e.clientX - galleryDragStartRef.current.startX;
		const deltaY = e.clientY - galleryDragStartRef.current.startY;
		setGalleryPan({
			x: galleryDragStartRef.current.initialPanX + deltaX,
			y: galleryDragStartRef.current.initialPanY + deltaY
		});
	};
	const handleGalleryPointerUp = (e) => {
		if (isGalleryDragging) {
			setIsGalleryDragging(false);
			galleryDragStartRef.current = null;
			try {
				e.currentTarget.releasePointerCapture(e.pointerId);
			} catch {}
		}
	};
	const handleGalleryWheel = (e) => {
		e.preventDefault();
		const delta = e.deltaY > 0 ? -.25 : .25;
		setGalleryZoom((prev) => {
			const next = Math.min(3.5, Math.max(.75, Number((prev + delta).toFixed(2))));
			if (next <= 1) setGalleryPan({
				x: 0,
				y: 0
			});
			return next;
		});
	};
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if (lightboxIndex === null) return;
			if (e.key === "Escape") closeLightbox();
			if (e.key === "ArrowRight") nextPhoto();
			if (e.key === "ArrowLeft") prevPhoto();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		lightboxIndex,
		nextPhoto,
		prevPhoto,
		closeLightbox
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "site-gallery",
		className: "section-shell bg-background border-b border-border relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow",
								children: "05 · Ground Reality & Live Progress"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), "Live On-Site Photographs"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "section-title",
							children: "Actual Site Progress & Infrastructure"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-3xl text-sm md:text-base text-muted-foreground leading-relaxed",
							children: [
								"We present 100% genuine on-ground photographs of",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "Galaxy Green Sai Suraksha Nagar"
								}),
								" in Amausi, Lucknow. Witness clear boundary demarcation, 30-ft wide roads, operational streetlights, and ongoing residential constructions."
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 xs:grid-cols-3 divide-y xs:divide-y-0 xs:divide-x divide-border/60 bg-surface/80 border border-border p-3 rounded-lg gap-2 xs:gap-0 min-w-0 w-full lg:w-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pb-2 xs:pb-0 xs:pr-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-mono text-muted-foreground block",
									children: "Rate Per Sq Ft"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-lg xs:text-xl font-display text-primary",
									children: "₹1,199"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "py-2 xs:py-0 xs:px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-mono text-muted-foreground block",
									children: "Plot Sizing"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-sm font-display text-foreground block truncate",
									children: "600 Sq Ft to Custom"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 xs:pt-0 xs:pl-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-mono text-muted-foreground block",
									children: "Registry & Possession"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-xs font-mono text-emerald-400 font-semibold block truncate",
									children: "Immediate (Dakhil Kharij)"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-wrap items-center gap-2 border-b border-border/80 pb-4",
					children: [
						{
							id: "all",
							label: "All Site Photos"
						},
						{
							id: "demarcation",
							label: "Plot Demarcation (600+ sq ft)"
						},
						{
							id: "roads",
							label: "30-Ft Roads & Streetlights"
						},
						{
							id: "construction",
							label: "Houses Under Construction"
						},
						{
							id: "panorama",
							label: "Township & Airport Connectivity"
						}
					].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setActiveTab(tab.id);
							setLightboxIndex(null);
						},
						className: `px-3.5 py-1.5 rounded-full text-xs font-mono transition-all ${activeTab === tab.id ? "bg-primary text-primary-foreground font-semibold shadow-glow" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border/60"}`,
						children: tab.label
					}, tab.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch",
					children: [
						filteredPhotos[0] && (() => {
							const hero = filteredPhotos[0];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-8 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[380px] lg:min-h-[440px]",
								onClick: () => openLightbox(0),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: hero.src,
										alt: hero.title,
										className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-md text-[11px] font-mono font-semibold bg-background/80 backdrop-blur-md text-primary border border-primary/30 shadow",
											children: hero.tag
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-9 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors shadow",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative p-6 sm:p-8 space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-xs font-mono text-primary",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hero.categoryLabel }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: hero.dimensionsLabel
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-xl sm:text-2xl font-semibold text-foreground group-hover:text-primary transition-colors",
												children: hero.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm text-muted-foreground line-clamp-2 max-w-2xl",
												children: hero.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 flex flex-wrap items-center gap-4 text-xs font-mono text-foreground/80",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-emerald-400" }), "Boundary Curbs Laid"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-emerald-400" }), "₹1,199 / Sq Ft Fixed Rate"]
												})]
											})
										]
									})
								]
							});
						})(),
						filteredPhotos[1] && (() => {
							const sec = filteredPhotos[1];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-4 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[320px] md:min-h-auto",
								onClick: () => openLightbox(1),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: sec.src,
										alt: sec.title,
										className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-2.5 py-0.5 rounded text-[10px] font-mono font-medium bg-background/80 backdrop-blur-md text-accent border border-accent/30",
											children: sec.tag
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-8 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative p-5 space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-mono text-primary uppercase block",
												children: sec.categoryLabel
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "font-display text-base font-semibold text-foreground group-hover:text-primary transition-colors",
												children: sec.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground line-clamp-2",
												children: sec.description
											})
										]
									})
								]
							});
						})(),
						filteredPhotos.slice(2).map((photo, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-4 group relative rounded-xl overflow-hidden border border-border bg-card shadow-glow cursor-pointer flex flex-col justify-end min-h-[260px]",
							onClick: () => openLightbox(idx + 2),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: photo.src,
									alt: photo.title,
									className: "absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-700"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between pointer-events-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-2 py-0.5 rounded text-[10px] font-mono bg-background/80 backdrop-blur-md text-foreground border border-border",
										children: photo.tag
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-7 rounded-full bg-background/80 backdrop-blur-md border border-border flex items-center justify-center text-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative p-4 space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono text-primary uppercase block",
											children: photo.categoryLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-display text-sm font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1",
											children: photo.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground line-clamp-2",
											children: photo.description
										})
									]
								})
							]
						}, photo.id))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 p-5 sm:p-6 rounded-xl bg-surface border border-border flex flex-col sm:flex-row items-center justify-between gap-4 shadow-luxury",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "icon-monogram size-12 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-sm font-display text-foreground uppercase block",
							children: "Inspect These Plots In Person"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Our sales team walks you through demarcated boundary stones and shows registry documents on-site."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3 w-full sm:w-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => onScheduleVisit("On-Ground Demarcated Plot"),
							className: "w-full sm:w-auto h-11 px-6 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
							children: ["Book Personal Site Inspection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 ml-2" })]
						})
					})]
				})
			]
		}), lightboxIndex !== null && filteredPhotos[lightboxIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex flex-col justify-between p-3 sm:p-6 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] animate-in fade-in duration-200",
			role: "dialog",
			"aria-modal": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border/80 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "font-mono text-xs border-primary/40 text-primary",
							children: [
								"Photo ",
								lightboxIndex + 1,
								" of ",
								filteredPhotos.length
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-mono text-muted-foreground hidden sm:inline",
							children: filteredPhotos[lightboxIndex].categoryLabel
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 bg-surface border border-border rounded-lg p-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: () => setGalleryZoom((prev) => {
											const next = Math.max(.75, Number((prev - .25).toFixed(2)));
											if (next <= 1) setGalleryPan({
												x: 0,
												y: 0
											});
											return next;
										}),
										disabled: galleryZoom <= .75,
										className: "size-7 sm:size-8 text-foreground hover:bg-background",
										title: "Zoom Out",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-3.5 sm:size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-mono font-semibold px-1 min-w-[2.8rem] text-center",
										children: [Math.round(galleryZoom * 100), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: () => setGalleryZoom((prev) => Math.min(3.5, Number((prev + .25).toFixed(2)))),
										disabled: galleryZoom >= 3.5,
										className: "size-7 sm:size-8 text-foreground hover:bg-background",
										title: "Zoom In",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-3.5 sm:size-4" })
									}),
									(galleryZoom !== 1 || galleryPan.x !== 0 || galleryPan.y !== 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										onClick: resetGalleryView,
										className: "size-7 sm:size-8 text-muted-foreground hover:text-foreground hover:bg-background",
										title: "Reset View",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => {
									const p = filteredPhotos[lightboxIndex];
									if (p) {
										closeLightbox();
										onScheduleVisit(`${p.title} (${p.dimensionsLabel || "On-Site"})`);
									}
								},
								className: "h-8 px-3 uppercase text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 hidden sm:inline-flex",
								children: ["Inquire This Plot ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1.5" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: closeLightbox,
								className: "size-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 flex items-center justify-center my-2 sm:my-3 overflow-hidden rounded-xl border border-border/80 bg-black/70 p-2 sm:p-4 select-none touch-none",
					onPointerDown: handleGalleryPointerDown,
					onPointerMove: handleGalleryPointerMove,
					onPointerUp: handleGalleryPointerUp,
					onPointerCancel: handleGalleryPointerUp,
					onWheel: handleGalleryWheel,
					onDoubleClick: () => {
						if (galleryZoom > 1) resetGalleryView();
						else setGalleryZoom(2);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								prevPhoto();
							},
							className: "absolute left-2 sm:left-4 z-20 size-10 sm:size-12 rounded-full bg-background/85 hover:bg-background border border-border text-foreground flex items-center justify-center transition-transform hover:scale-110 active:scale-95 shadow-lg",
							"aria-label": "Previous photograph",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 sm:size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "origin-center transition-transform select-none",
							style: {
								transform: `translate3d(${galleryPan.x}px, ${galleryPan.y}px, 0) scale(${galleryZoom})`,
								transitionDuration: isGalleryDragging ? "0ms" : "200ms",
								cursor: galleryZoom > 1 ? isGalleryDragging ? "grabbing" : "grab" : "zoom-in"
							},
							title: galleryZoom > 1 ? "Drag to pan · Double-click to reset · Scroll to zoom" : "Click zoom controls, double-click, or use wheel/trackpad to zoom",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: filteredPhotos[lightboxIndex].src,
								alt: filteredPhotos[lightboxIndex].title,
								className: "max-h-[72vh] max-h-[72dvh] w-auto max-w-full object-contain rounded-lg shadow-2xl pointer-events-none select-none",
								draggable: false
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								nextPhoto();
							},
							className: "absolute right-2 sm:right-4 z-20 size-10 sm:size-12 rounded-full bg-background/85 hover:bg-background border border-border text-foreground flex items-center justify-center transition-transform hover:scale-110 active:scale-95 shadow-lg",
							"aria-label": "Next photograph",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 sm:size-6" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border/80 pt-3 max-w-5xl mx-auto w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-base sm:text-xl font-display font-semibold uppercase tracking-wide text-foreground",
									children: filteredPhotos[lightboxIndex].title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono text-primary/90 shrink-0",
									children: filteredPhotos[lightboxIndex].dimensionsLabel || "On-Ground Real State"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-muted-foreground leading-relaxed max-w-3xl",
								children: filteredPhotos[lightboxIndex].description || "Authentic on-site photograph of Galaxy Green township in Lucknow."
							}),
							Array.isArray(filteredPhotos[lightboxIndex].highlights) && filteredPhotos[lightboxIndex].highlights.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 pt-1",
								children: filteredPhotos[lightboxIndex].highlights.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), h]
								}, i))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 pt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Physical Boundary Pillars Installed"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Immediate Registry & Possession Ready"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-surface/90 border border-border/80 text-[11px] font-mono text-foreground shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-400 shrink-0" }), "Direct 30-Ft Internal Road Connectivity"]
									})
								]
							})
						]
					})
				})
			]
		})]
	});
}
var Slider = import_react.forwardRef(({ className, thumbAriaLabel, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
		"aria-label": thumbAriaLabel || props["aria-label"] || "Slider control",
		className: "block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
	})]
}));
Slider.displayName = Slider$1.displayName;
function EmiRoiCalculator({ onLockPriceClick, baseRate = 1199 }) {
	const [plotArea, setPlotArea] = (0, import_react.useState)(600);
	const [customAreaInput, setCustomAreaInput] = (0, import_react.useState)("600");
	const [downPaymentPercent, setDownPaymentPercent] = (0, import_react.useState)(20);
	const [tenureYears, setTenureYears] = (0, import_react.useState)(10);
	const [annualInterestRate, setAnnualInterestRate] = (0, import_react.useState)(8.5);
	const BASE_RATE = baseRate || 1199;
	const effectiveArea = Math.max(100, plotArea);
	const totalCost = effectiveArea * BASE_RATE;
	const downPaymentAmount = Math.round(totalCost * (downPaymentPercent / 100));
	const loanAmount = Math.max(0, totalCost - downPaymentAmount);
	const monthlyRate = annualInterestRate / 12 / 100;
	const totalMonths = Math.max(12, tenureYears * 12);
	const emi = loanAmount > 0 && monthlyRate > 0 ? Math.round(loanAmount * monthlyRate * Math.pow(1 + monthlyRate, totalMonths) / (Math.pow(1 + monthlyRate, totalMonths) - 1)) : loanAmount > 0 ? Math.round(loanAmount / totalMonths) : 0;
	const estimatedStampDuty = Math.round(totalCost * .07);
	const estimatedRegistration = Math.round(totalCost * .01);
	const totalStatutoryFees = estimatedStampDuty + estimatedRegistration;
	const estimatedFutureValue5Years = Math.round(totalCost * Math.pow(1.18, 5));
	const projectedNetGain = estimatedFutureValue5Years - totalCost;
	const formatINR = (val) => new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(val);
	const handleCustomAreaChange = (valStr) => {
		setCustomAreaInput(valStr);
		const num = parseInt(valStr, 10);
		if (!isNaN(num) && num > 0) setPlotArea(num);
	};
	const handleCustomAreaBlur = () => {
		const num = parseInt(customAreaInput, 10);
		if (isNaN(num) || num < 600) {
			setPlotArea(600);
			setCustomAreaInput("600");
		} else if (num > 15e3) {
			setPlotArea(15e3);
			setCustomAreaInput("15000");
		}
	};
	const handlePresetSelect = (area) => {
		setPlotArea(area);
		setCustomAreaInput(area.toString());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "calculator",
		className: "section-shell bg-surface border-y border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "06 · Financial Intelligence"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-primary/10 text-primary border border-primary/30",
							children: [
								"Official Rate: ₹",
								BASE_RATE.toLocaleString("en-IN"),
								" / Sq Ft"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "section-title",
						children: "Investment ROI & EMI Calculator"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed",
						children: [
							"Minimum allotment starts from",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "text-foreground font-medium",
								children: [
									"600 sq. ft. (",
									formatINR(600 * BASE_RATE),
									")"
								]
							}),
							", with flexible dimensions scalable up to commercial parcels and luxury multi-plot estates."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 bg-accent/10 border border-accent/30 px-4 py-2.5 rounded text-xs text-accent font-mono",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amausi Corridor 5-Yr Growth Trend: +128%" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-8 lg:grid-cols-12 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 bg-card border border-border rounded-lg p-6 sm:p-8 space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap justify-between items-center gap-2 mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Plot Area (Min 600 Sq Ft to Custom)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "calculator-plot-area",
										"aria-label": "Custom plot area in square feet",
										type: "number",
										min: 600,
										max: 15e3,
										step: 50,
										value: customAreaInput,
										onChange: (e) => handleCustomAreaChange(e.target.value),
										onBlur: handleCustomAreaBlur,
										className: "w-28 h-9 text-right font-display font-semibold text-primary text-base bg-background/80"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-mono text-muted-foreground",
										children: "Sq Ft"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								"aria-label": "Plot area slider from 600 to 4000 square feet",
								thumbAriaLabel: "Plot area in square feet",
								value: [plotArea > 4e3 ? 4e3 : Math.max(600, plotArea)],
								min: 600,
								max: 4e3,
								step: 50,
								onValueChange: (val) => {
									const v = val[0] ?? 600;
									setPlotArea(v);
									setCustomAreaInput(v.toString());
								},
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 mt-3",
								children: [
									{
										area: 600,
										label: "600 Sq Ft (₹7.19L)"
									},
									{
										area: 800,
										label: "800 Sq Ft (₹9.59L)"
									},
									{
										area: 1e3,
										label: "1,000 Sq Ft (₹11.99L)"
									},
									{
										area: 1200,
										label: "1,200 Sq Ft (₹14.39L)"
									},
									{
										area: 1500,
										label: "1,500 Sq Ft (₹17.99L)"
									},
									{
										area: 2e3,
										label: "2,000+ Sq Ft"
									}
								].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handlePresetSelect(preset.area),
									className: `px-3 py-1.5 rounded text-[11px] font-mono transition-all cursor-pointer ${plotArea === preset.area ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border"}`,
									children: preset.label
								}, preset.area))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: [
										"Down Payment (",
										downPaymentPercent,
										"%)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-display font-semibold text-accent",
									children: formatINR(downPaymentAmount)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								"aria-label": "Down payment percentage slider from 10 to 70 percent",
								thumbAriaLabel: "Down payment percentage",
								value: [downPaymentPercent],
								min: 10,
								max: 70,
								step: 5,
								onValueChange: (val) => setDownPaymentPercent(val[0] ?? 20),
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1 gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["10% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Booking Token)"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["20% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Standard)"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["50% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Lower EMI)"
									})] })
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Bank Loan Tenure"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-base sm:text-lg font-display font-semibold text-foreground",
									children: [
										tenureYears,
										" Years (",
										totalMonths,
										" Months)"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								"aria-label": "Bank loan tenure slider from 3 to 15 years",
								thumbAriaLabel: "Bank loan tenure in years",
								value: [tenureYears],
								min: 3,
								max: 15,
								step: 1,
								onValueChange: (val) => setTenureYears(val[0] ?? 10),
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1 gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "3 Years" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["10 Years ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Recommended)"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "15 Years" })
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono tracking-wider text-muted-foreground",
									children: "Bank Loan Interest Rate"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-base sm:text-lg font-display font-semibold text-primary font-mono",
									children: [annualInterestRate.toFixed(2), "% p.a."]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								"aria-label": "Annual interest rate slider from 7 to 14 percent",
								thumbAriaLabel: "Annual interest rate percentage",
								value: [annualInterestRate],
								min: 7,
								max: 14,
								step: .05,
								onValueChange: (val) => {
									const v = val[0] ?? 8.5;
									setAnnualInterestRate(Number(v.toFixed(2)));
								},
								className: "py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[10px] text-muted-foreground font-mono mt-1 gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["7.0% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Subsidized)"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["8.5% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(Standard)"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["14.0% ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xs:inline",
										children: "(NBFC)"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 mt-3",
								children: [
									{
										rate: 8.4,
										label: "8.40% (SBI Prime)"
									},
									{
										rate: 8.65,
										label: "8.65% (HDFC Standard)"
									},
									{
										rate: 9.25,
										label: "9.25% (Private Bank)"
									},
									{
										rate: 10.5,
										label: "10.50% (Plot Loan)"
									}
								].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAnnualInterestRate(preset.rate),
									className: `px-2.5 py-1 rounded text-[10px] font-mono transition-all cursor-pointer ${Math.abs(annualInterestRate - preset.rate) < .05 ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "bg-surface hover:bg-surface-hover text-muted-foreground hover:text-foreground border border-border"}`,
									children: preset.label
								}, preset.rate))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 border-t border-border/70 space-y-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 text-primary" }), "Estimated Registry & Stamp Duty (UP Standard ~8%)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground font-mono text-xs",
									children: formatINR(totalStatutoryFees)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-[11px] font-mono text-muted-foreground bg-background/50 p-2.5 rounded border border-border/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Stamp Duty (~7%):",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: formatINR(estimatedStampDuty)
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"Registration (~1%):",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: formatINR(estimatedRegistration)
									})
								] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 flex items-start gap-2.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgePercent, { className: "size-4 text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Computed at transparent fixed base rate",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "₹1,199 / sq ft"
								}),
								". Pre-approved plot loans available with nationalized lenders (SBI, HDFC, PNB) up to 80% financing with immediate legal title clearance."
							] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-primary/30 rounded-lg p-6 sm:p-8 relative overflow-hidden shadow-luxury",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-12 -right-12 size-36 bg-primary/10 rounded-full blur-2xl pointer-events-none" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-widest text-primary font-mono font-semibold block",
								children: "Estimated Monthly Outflow"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-baseline gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-4xl sm:text-5xl font-display font-semibold text-foreground",
									children: formatINR(emi)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase font-mono text-muted-foreground",
									children: "/ month"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-6 h-px bg-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Plot Size Selected"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-foreground font-mono text-sm",
											children: [effectiveArea.toLocaleString(), " Sq Ft"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Total Consideration (₹1,199/sq ft)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-primary font-medium text-sm",
											children: formatINR(totalCost)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												"Down Payment (",
												downPaymentPercent,
												"%)"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-accent font-medium text-sm",
											children: formatINR(downPaymentAmount)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Financed Loan Amount"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground font-medium text-sm",
											children: formatINR(loanAmount)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Interest Rate & Tenure"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-primary font-mono text-xs font-semibold",
											children: [
												annualInterestRate.toFixed(2),
												"% p.a. · ",
												tenureYears,
												" Yrs"
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 p-4 rounded-md bg-primary/10 border border-primary/30 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs font-mono text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "uppercase flex items-center gap-1.5 font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3.5" }), " 5-Yr Projected Value"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "18% CAGR" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-2xl font-display text-primary",
											children: formatINR(estimatedFutureValue5Years)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-emerald-400 font-semibold font-mono",
											children: [
												"+",
												formatINR(projectedNetGain),
												" net gain"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground leading-relaxed",
										children: "Conservative projection anchored on Lucknow Airport expansion, Amausi Railway & Metro transit connectivity."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "lg",
								onClick: () => onLockPriceClick(`${effectiveArea} sq ft`),
								className: "mt-6 w-full h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
								children: ["Lock Current ₹1,199 Rate ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-2" })]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface/80 border border-border/80 rounded p-3.5 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Pre-approved Bank Loans Available"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] text-accent font-medium",
							children: "SBI · HDFC · PNB"
						})]
					})]
				})]
			})]
		})
	});
}
function LegalTrustBadge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-primary/30 bg-card rounded-lg p-6 sm:p-8 relative overflow-hidden shadow-glow",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[10px] uppercase font-mono tracking-widest text-primary font-semibold flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Buyer Security & Title Assurance"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-display uppercase tracking-tight text-foreground mt-1",
				children: "Buy Land With Complete Peace of Mind"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase text-muted-foreground block font-mono",
							children: "Partner Banks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-xs text-foreground font-mono",
							children: "SBI · HDFC · PNB · ICICI"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-8 w-px bg-border hidden sm:block" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-primary/10 border border-primary/30 px-3 py-1.5 rounded text-xs text-primary font-mono font-semibold",
						children: "Up to 80% Financing"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6",
			children: [
				{
					icon: FileCheck,
					title: "100% Freehold Land",
					desc: "Clear individual registry with mutation (Dakhil Kharij) guarantee."
				},
				{
					icon: ShieldCheck,
					title: "Verified Title Deed",
					desc: "Clear legal search report & zero encumbrance certification."
				},
				{
					icon: Landmark,
					title: "Nationalized Bank Loans",
					desc: "Pre-approved plot purchase & home construction loans from SBI, HDFC & PNB."
				},
				{
					icon: Award,
					title: "Instant Possession",
					desc: "Demarcated on-ground boundary stones installed ready for immediate construction."
				}
			].map((item) => {
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group space-y-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "icon-monogram size-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4.5 transition-transform duration-300 group-hover:scale-110" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-display text-sm uppercase text-foreground font-semibold tracking-tight group-hover:text-primary transition-colors",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground leading-relaxed",
							children: item.desc
						})
					]
				}, item.title);
			})
		})]
	});
}
var AMENITIES = [
	{
		icon: Route,
		title: "30 ft, 25 ft & 22 ft Roads",
		tag: "Wide Paved Network",
		badge: "Wide Access",
		image: "/amenities/amenity-roads.jpg",
		description: "Wide interlocking concrete paver roads and arterial corridors ensuring smooth two-way vehicle movement, seamless turnaround radiuses, and designated walkway borders across all sectors.",
		highlights: [
			"30 ft Main Arterial Road",
			"25 ft Connecting Boulevards",
			"22 ft Residential Access Lanes"
		]
	},
	{
		icon: ShieldCheck,
		title: "24/7 Security",
		tag: "Round-the-Clock Safety",
		badge: "Guarded 24/7",
		image: "/amenities/amenity-security.jpg",
		description: "Trained on-ground security personnel on round-the-clock duty, centralized checkpoint protocols, and proactive perimeter monitoring to guarantee absolute peace of mind for every family.",
		highlights: [
			"Manned Entry/Exit Checkpoints",
			"Night Security Patrols",
			"Visitor Screening System"
		]
	},
	{
		icon: Building2,
		title: "Gated Society",
		tag: "Secure Residential Enclave",
		badge: "Private Enclave",
		image: "/amenities/amenity-gated-society.jpg",
		description: "A fully enclosed, boundary-walled residential enclave featuring a grand signature entrance arch, regulated entry, and a safe, private neighborhood environment.",
		highlights: [
			"Solid Perimeter Boundary Wall",
			"Grand Architectural Gate",
			"Private Gated Community"
		]
	},
	{
		icon: Zap,
		title: "Electricity",
		tag: "Energized Infrastructure",
		badge: "Power Ready",
		image: "/amenities/amenity-electricity.jpg",
		description: "Dedicated electrical infrastructure with high-capacity step-down transformers, organized utility cabling lines, and bright LED streetlights illuminating every lane and junction.",
		highlights: [
			"Dedicated Power Transformers",
			"All-Night Street Illumination",
			"Immediate Household Connection"
		]
	},
	{
		icon: Trees,
		title: "Parks & Green Zones",
		tag: "Eco-Friendly Living",
		badge: "Lush & Open",
		image: "/amenities/amenity-parks.jpg",
		description: "Lush manicured community green parks, shaded walking promenades, morning yoga spaces, and open recreation zones planned for children and senior citizens alike.",
		highlights: [
			"Landscaped Green Parks",
			"Tree-Lined Avenues",
			"Children's Play Areas"
		]
	},
	{
		icon: Droplets,
		title: "Water Supply",
		tag: "24/7 Fresh Water",
		badge: "Sweet Water",
		image: "/amenities/amenity-water-supply.jpg",
		description: "Reliable 24-hour sweet potable water pipeline network connected directly to every plot demarcated in the layout, powered by dedicated high-pressure storage systems.",
		highlights: [
			"Direct Pipeline to Each Plot",
			"24/7 Potable Sweet Water",
			"High-Pressure Distribution"
		]
	},
	{
		icon: Landmark,
		title: "Nagar Nigam",
		tag: "Municipal Corporation",
		badge: "Municipal Ward",
		image: "/amenities/amenity-nagar-nigam.jpg",
		description: "Situated within the Lucknow Municipal Corporation (Nagar Nigam) jurisdiction, ensuring structured waste disposal, regular road maintenance, and official civic services.",
		highlights: [
			"Nagar Nigam Civic Services",
			"Scheduled Garbage Disposal",
			"Official Municipal Standards"
		]
	}
];
function AmenitiesSection({ onScheduleVisit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "amenities",
		className: "section-shell bg-surface border-b border-border relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/4 left-1/2 -translate-x-1/2 w-3/4 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl relative z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "03 · Planned Modern Infrastructure"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "border-primary/40 text-primary bg-primary/10 text-[10px] font-mono",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-2.5 mr-1" }), " 100% Fully Equipped"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "section-title",
								children: "Amenities"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base text-muted-foreground leading-relaxed",
								children: "Every facility at Galaxy Green Sai Suraksha Nagar is carefully engineered to deliver an effortless, secure, and modern lifestyle. All these key facilities are available directly on-site for prospective homeowners and investors."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onScheduleVisit,
						className: "h-11 sm:h-12 px-6 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow shrink-0 btn-shimmer",
						children: ["Visit On Site Today ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5",
					children: AMENITIES.map((item, idx) => {
						const Icon = item.icon;
						const isFeatured = idx === 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `card-architectural group rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:border-primary/60 hover:shadow-luxury bg-[#091510] border border-border/80 ${isFeatured ? "sm:col-span-2 lg:col-span-3 xl:col-span-2 bg-gradient-to-br from-[#0c1c15] via-[#091510] to-[#07100c]" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `relative w-full overflow-hidden bg-black/40 ${isFeatured ? "h-52 sm:h-60" : "h-44 sm:h-48"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.image,
										alt: item.title,
										loading: "lazy",
										className: "w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#091510] via-[#091510]/50 to-black/35" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "icon-monogram size-10 rounded-lg bg-black/70 backdrop-blur-md border border-white/15 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-primary" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "border-emerald-500/40 text-emerald-300 bg-black/75 backdrop-blur-md text-[10px] uppercase font-mono tracking-wider px-2.5 py-0.5 shadow-md",
											children: item.badge
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-2.5 left-3.5 z-10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono uppercase tracking-widest text-primary font-semibold bg-black/80 backdrop-blur-md px-2.5 py-0.5 rounded border border-primary/30 shadow-sm",
											children: item.tag
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 sm:p-6 flex-1 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg sm:text-xl uppercase text-foreground font-semibold tracking-tight",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs sm:text-sm leading-relaxed text-muted-foreground",
									children: item.description
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 mt-5 border-t border-border/60 space-y-2",
									children: item.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs font-mono text-muted-foreground/90",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: h
										})]
									}, h))
								})]
							})]
						}, item.title);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 p-4 sm:p-5 rounded-xl bg-card/80 border border-primary/30 shadow-luxury flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 grid place-items-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block text-sm font-display uppercase text-foreground",
							children: "All Amenities Available & Active on Ground"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Visit Sai Suraksha Nagar to inspect road demarcation, water lines, transformer installation, and gated boundary in person."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: onScheduleVisit,
						className: "h-10 px-5 border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground uppercase text-xs tracking-wider shrink-0",
						children: "Inspect Infrastructure"
					})]
				})
			]
		})]
	});
}
var SiteVisitModal = (0, import_react.lazy)(() => import("./SiteVisitModal-By7OWqHE.mjs").then((m) => ({ default: m.SiteVisitModal })));
var BrochureModal = (0, import_react.lazy)(() => import("./BrochureModal--sHFx70d.mjs").then((m) => ({ default: m.BrochureModal })));
var AdminLeadsDrawer = (0, import_react.lazy)(() => import("./AdminLeadsDrawer-BPNuqqqA.mjs").then((m) => ({ default: m.AdminLeadsDrawer })));
var MyBookingsDrawer = (0, import_react.lazy)(() => import("./MyBookingsDrawer-DUodn_Sa.mjs").then((m) => ({ default: m.MyBookingsDrawer })));
var PHONE = "919044412642";
var MAP_URL = "https://www.google.com/maps/search/?api=1&query=Sai+Surksha+nagar%2C+QR4X%2B39W%2C+Amausi%2C+Lucknow%2C+Uttar+Pradesh+226008";
function Logo({ showMotto = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: "#home",
		className: "flex items-center gap-2.5 sm:gap-3 group shrink-0 min-w-0",
		"aria-label": "Galaxy Green home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative size-10 sm:size-11 md:size-12 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/50 group-hover:ring-primary group-hover:scale-105 transition-all duration-300 shrink-0 bg-white/10 flex items-center justify-center p-0.5 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/galaxy-green-emblem.png?v=2",
				alt: "Galaxy Green Official Seal Logo",
				width: 48,
				height: 48,
				className: "size-full object-contain filter drop-shadow-sm"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col justify-center leading-tight min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "block font-display text-sm sm:text-base md:text-lg font-bold tracking-tight text-foreground group-hover:text-primary transition-colors truncate",
					children: "Galaxy Green"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[8px] sm:text-[9px] md:text-[10px] uppercase tracking-widest text-primary/90 font-mono font-medium truncate",
					children: "Sai Suraksha Nagar"
				}),
				showMotto && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[8px] sm:text-[9px] uppercase tracking-wider text-muted-foreground/80 font-mono mt-0.5 truncate",
					children: "Safe Homes | Better Tomorrow"
				})
			]
		})]
	});
}
function Index() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [siteVisitOpen, setSiteVisitOpen] = (0, import_react.useState)(false);
	const [brochureOpen, setBrochureOpen] = (0, import_react.useState)(false);
	const [adminOpen, setAdminOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") {
			if (window.location.hash === "#admin" || sessionStorage.getItem("gg_admin_open") === "true") setAdminOpen(true);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined") if (adminOpen) {
			sessionStorage.setItem("gg_admin_open", "true");
			if (window.location.hash !== "#admin") window.history.replaceState(null, "", "#admin");
		} else {
			sessionStorage.removeItem("gg_admin_open");
			if (window.location.hash === "#admin") window.history.replaceState(null, "", window.location.pathname);
		}
	}, [adminOpen]);
	const [selectedPlotForVisit, setSelectedPlotForVisit] = (0, import_react.useState)("600 sq ft");
	const [airportModalOpen, setAirportModalOpen] = (0, import_react.useState)(false);
	const [airportZoom, setAirportZoom] = (0, import_react.useState)(1);
	const [airportPan, setAirportPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [isAirportDragging, setIsAirportDragging] = (0, import_react.useState)(false);
	const airportDragStartRef = (0, import_react.useRef)(null);
	const [scrolledPastHero, setScrolledPastHero] = (0, import_react.useState)(false);
	const [dockMinimized, setDockMinimized] = (0, import_react.useState)(false);
	const [isContactVisible, setIsContactVisible] = (0, import_react.useState)(false);
	const [isInputFocused, setIsInputFocused] = (0, import_react.useState)(false);
	const [myBookingsOpen, setMyBookingsOpen] = (0, import_react.useState)(false);
	const [myBookingsCount, setMyBookingsCount] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setMyBookingsCount(getLocalBookings().length);
		return subscribeToBookings((updated) => {
			setMyBookingsCount(updated.length);
		});
	}, []);
	const [baseRate, setBaseRate] = (0, import_react.useState)(1199);
	(0, import_react.useEffect)(() => {
		fetchMarketBaseRate().then((rate) => {
			if (rate && rate > 0) setBaseRate(rate);
		});
		const handleRateUpdated = (e) => {
			const customEvt = e;
			if (customEvt.detail?.rate) setBaseRate(customEvt.detail.rate);
			else fetchMarketBaseRate().then((rate) => {
				if (rate && rate > 0) setBaseRate(rate);
			});
		};
		window.addEventListener("market-rate-updated", handleRateUpdated);
		return () => window.removeEventListener("market-rate-updated", handleRateUpdated);
	}, []);
	const [contactName, setContactName] = (0, import_react.useState)("");
	const [contactPhone, setContactPhone] = (0, import_react.useState)("");
	const [contactPlot, setContactPlot] = (0, import_react.useState)("600 sq ft");
	const [customPlotArea, setCustomPlotArea] = (0, import_react.useState)(2e3);
	const [contactVisitDate, setContactVisitDate] = (0, import_react.useState)("");
	const [contactCustomTime, setContactCustomTime] = (0, import_react.useState)("");
	const [showContactClock, setShowContactClock] = (0, import_react.useState)(false);
	const [contactMessage, setContactMessage] = (0, import_react.useState)("");
	const [contactHoneypot, setContactHoneypot] = (0, import_react.useState)("");
	const [formError, setFormError] = (0, import_react.useState)("");
	const [formSubmitting, setFormSubmitting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const getScrollTop = () => {
			if (typeof window === "undefined") return 0;
			return window.pageYOffset || document.documentElement?.scrollTop || document.body?.scrollTop || window.scrollY || 0;
		};
		const handleScroll = () => {
			setScrolledPastHero(getScrollTop() > 260);
		};
		window.addEventListener("scroll", handleScroll, { passive: true });
		window.addEventListener("resize", handleScroll, { passive: true });
		window.addEventListener("orientationchange", handleScroll, { passive: true });
		handleScroll();
		return () => {
			window.removeEventListener("scroll", handleScroll);
			window.removeEventListener("resize", handleScroll);
			window.removeEventListener("orientationchange", handleScroll);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const contactSection = document.getElementById("contact");
		if (!contactSection) return;
		const observer = new IntersectionObserver((entries) => {
			const entry = entries[0];
			if (entry) setIsContactVisible(entry.isIntersecting);
		}, {
			threshold: .05,
			rootMargin: "0px 0px -40px 0px"
		});
		observer.observe(contactSection);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const handleFocusIn = (e) => {
			const target = e.target;
			if (target && [
				"INPUT",
				"TEXTAREA",
				"SELECT"
			].includes(target.tagName)) setIsInputFocused(true);
		};
		const handleFocusOut = () => {
			setTimeout(() => {
				const active = document.activeElement;
				if (!active || ![
					"INPUT",
					"TEXTAREA",
					"SELECT"
				].includes(active.tagName)) setIsInputFocused(false);
			}, 100);
		};
		window.addEventListener("focusin", handleFocusIn);
		window.addEventListener("focusout", handleFocusOut);
		return () => {
			window.removeEventListener("focusin", handleFocusIn);
			window.removeEventListener("focusout", handleFocusOut);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (menuOpen || airportModalOpen) {
			const originalOverflow = document.body.style.overflow;
			document.body.style.overflow = "hidden";
			return () => {
				document.body.style.overflow = originalOverflow;
			};
		}
	}, [menuOpen, airportModalOpen]);
	(0, import_react.useEffect)(() => {
		if (!airportModalOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") setAirportModalOpen(false);
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [airportModalOpen]);
	const resetAirportView = () => {
		setAirportZoom(1);
		setAirportPan({
			x: 0,
			y: 0
		});
	};
	const handleAirportPointerDown = (e) => {
		if (airportZoom <= 1) return;
		e.currentTarget.setPointerCapture(e.pointerId);
		setIsAirportDragging(true);
		airportDragStartRef.current = {
			startX: e.clientX,
			startY: e.clientY,
			initialPanX: airportPan.x,
			initialPanY: airportPan.y
		};
	};
	const handleAirportPointerMove = (e) => {
		if (!isAirportDragging || !airportDragStartRef.current) return;
		const deltaX = e.clientX - airportDragStartRef.current.startX;
		const deltaY = e.clientY - airportDragStartRef.current.startY;
		setAirportPan({
			x: airportDragStartRef.current.initialPanX + deltaX,
			y: airportDragStartRef.current.initialPanY + deltaY
		});
	};
	const handleAirportPointerUp = (e) => {
		if (isAirportDragging) {
			setIsAirportDragging(false);
			airportDragStartRef.current = null;
			try {
				e.currentTarget.releasePointerCapture(e.pointerId);
			} catch {}
		}
	};
	const handleAirportWheel = (e) => {
		e.preventDefault();
		const delta = e.deltaY > 0 ? -.25 : .25;
		setAirportZoom((prev) => {
			const next = Math.min(3.5, Math.max(.75, Number((prev + delta).toFixed(2))));
			if (next <= 1) setAirportPan({
				x: 0,
				y: 0
			});
			return next;
		});
	};
	const handlePlotSelectForBooking = (plotNumber, size) => {
		setSelectedPlotForVisit(`${size} (Plot ${plotNumber})`);
		setSiteVisitOpen(true);
	};
	const handleCalculatorLock = (plotSizeText) => {
		setSelectedPlotForVisit(plotSizeText);
		setSiteVisitOpen(true);
	};
	async function submitEnquiry(event) {
		event.preventDefault();
		if (contactName.trim().length < 2) {
			setFormError("Please enter your full name.");
			return;
		}
		const cleanPhone = contactPhone.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
			setFormError("Please enter a valid 10-digit Indian mobile number.");
			return;
		}
		if (contactVisitDate) {
			const todayStr = getLocalDateString();
			if (contactVisitDate < todayStr) {
				setFormError("Preferred visit date cannot be in the past. Only present and upcoming dates are allowed.");
				return;
			}
			if (contactVisitDate === todayStr && contactCustomTime.trim()) {
				if (isTimePassedForDate(contactCustomTime.trim(), contactVisitDate)) {
					setFormError(`The selected visit timing "${contactCustomTime.trim()}" has already passed for today. Please select an upcoming time.`);
					return;
				}
			}
		}
		setFormError("");
		setFormSubmitting(true);
		try {
			const finalPlot = contactPlot === "Custom Size" ? `Custom ${customPlotArea} Sq Ft (₹${(customPlotArea * baseRate / 1e5).toFixed(2)} Lakh · Tailored Size)` : contactPlot;
			const finalSlot = contactCustomTime.trim() ? `Custom Time: ${contactCustomTime.trim()}` : "Morning (10:00 AM)";
			const createdLead = await recordNewInquiry({
				name: contactName.trim(),
				phone: cleanPhone,
				plotPreference: finalPlot,
				visitDate: contactVisitDate || void 0,
				message: contactMessage.trim(),
				slot: finalSlot,
				cabPickup: false,
				pickupLocation: "On Site",
				website: contactHoneypot
			});
			saveLocalBooking({
				id: createdLead.id,
				name: createdLead.name,
				phone: createdLead.phone,
				plotPreference: createdLead.plotPreference,
				visitDate: createdLead.visitDate,
				slot: createdLead.slot,
				message: createdLead.message
			});
			toast.success(`Inquiry Recorded! Reference ID: ${createdLead.id}`);
			const text = [
				`Hello Vishal Chauhan, I am interested in Galaxy Green Sai Suraksha Nagar (Ref: ${createdLead.id}).`,
				`Name: ${contactName.trim()}`,
				`Mobile: ${cleanPhone}`,
				`Plot Preference: ${finalPlot}`,
				contactCustomTime.trim() ? `Preferred Timing: ${contactCustomTime.trim()}` : "",
				contactMessage.trim() ? `Message: ${contactMessage.trim()}` : ""
			].filter(Boolean).join("\n");
			window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
			setContactName("");
			setContactPhone("");
			setContactMessage("");
		} catch (err) {
			console.error(err);
			toast.error("Could not record inquiry. Please try again.");
		} finally {
			setFormSubmitting(false);
		}
	}
	const isFloatingDockVisible = scrolledPastHero && !isContactVisible && !isInputFocused && !siteVisitOpen && !brochureOpen && !adminOpen && !myBookingsOpen && !menuOpen && !airportModalOpen;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "home",
		className: "min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground min-w-0 w-full max-w-full overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed inset-x-0 top-0 z-50 border-b border-border/80 bg-background/85 backdrop-blur-xl transition-all pt-[env(safe-area-inset-top,0px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 sm:h-20 max-w-7xl xl:max-w-[1440px] items-center justify-between px-3 sm:px-6 lg:px-8 min-w-0 gap-2 sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1.5 2xl:gap-2.5 min-[1380px]:flex shrink-0 min-w-0",
							"aria-label": "Main navigation",
							itemScope: true,
							itemType: "https://schema.org/SiteNavigationElement",
							children: [
								["About", "#about"],
								["Master Plan", "#masterplan"],
								["Live Photos", "#site-gallery"],
								["Amenities", "#amenities"],
								["Connectivity", "#location"],
								["ROI Calculator", "#calculator"],
								["Pricing", "#pricing"],
								["FAQ", "#faq"],
								["Contact", "#contact"]
							].map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								itemProp: "url",
								className: "px-2 2xl:px-2.5 py-1 rounded text-[11px] 2xl:text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-all font-medium whitespace-nowrap",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									itemProp: "name",
									children: label
								})
							}, href))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden min-[1380px]:flex items-center gap-2 2xl:gap-3 shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-px bg-border/80 mx-0.5 2xl:mx-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setMyBookingsOpen(true),
									className: "h-8.5 sm:h-9 px-2.5 2xl:px-3 text-xs border-primary/40 text-foreground hover:text-primary hover:bg-primary/10 uppercase tracking-wider font-mono shrink-0 flex items-center gap-1.5",
									title: "View My Scheduled Visits",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-3.5 text-primary" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "My Bookings" }),
										myBookingsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-4.5 rounded-full bg-primary text-primary-foreground font-mono text-[10px] font-bold grid place-items-center ml-0.5",
											children: myBookingsCount
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAdminOpen(true),
									className: "h-8.5 sm:h-9 px-2.5 2xl:px-3 text-xs border-primary/40 text-primary hover:bg-primary/10 uppercase tracking-wider font-mono shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 mr-1.5" }), " Admin Portal"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setSelectedPlotForVisit("1000 sq ft");
										setSiteVisitOpen(true);
									},
									className: "h-8.5 sm:h-9 px-3 2xl:px-4 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow shrink-0 whitespace-nowrap btn-shimmer",
									children: ["Book Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 sm:gap-2.5 min-[1380px]:hidden shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAdminOpen(true),
									className: "h-8.5 sm:h-9 px-2 sm:px-2.5 text-xs border-primary/40 text-primary hover:bg-primary/10 uppercase font-mono shrink-0",
									title: "Open Admin Portal",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 mr-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Admin"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setSelectedPlotForVisit("1000 sq ft");
										setSiteVisitOpen(true);
									},
									className: "h-8.5 sm:h-9 px-2 sm:px-3.5 uppercase tracking-wider text-[11px] sm:text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow shrink-0 btn-shimmer",
									children: ["Book Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1 hidden xs:inline" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "size-8.5 sm:size-9 text-foreground hover:bg-surface rounded-lg border border-border/60 shrink-0",
									"aria-label": menuOpen ? "Close menu" : "Open menu",
									onClick: () => setMenuOpen((open) => !open),
									children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								})
							]
						})
					]
				}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "border-t border-border bg-background/95 backdrop-blur-2xl px-4 sm:px-6 py-5 sm:py-6 min-[1380px]:hidden animate-in fade-in slide-in-from-top-4 shadow-2xl max-h-[calc(100dvh-4.5rem)] overflow-y-auto",
					"aria-label": "Mobile navigation",
					itemScope: true,
					itemType: "https://schema.org/SiteNavigationElement",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1 max-w-lg sm:max-w-2xl mx-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-3 sm:pb-4 mb-2 border-b border-border/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-11 sm:size-12 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/50 bg-white/10 flex items-center justify-center p-0.5 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "/galaxy-green-emblem.png?v=2",
											alt: "Official Galaxy Green Seal",
											width: 48,
											height: 48,
											className: "size-full object-contain"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block font-display text-sm sm:text-base uppercase text-foreground font-bold truncate",
											children: "Galaxy Green"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[10px] sm:text-[11px] uppercase font-mono text-primary font-medium truncate",
											children: "Sai Suraksha Nagar · Lucknow"
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden sm:flex items-center gap-1.5 bg-primary/10 border border-primary/30 px-2.5 py-1 rounded text-[10px] font-mono text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400" }), "Freehold Plots"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pt-1 pb-3 mb-2 border-b border-border/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setMenuOpen(false);
										setMyBookingsOpen(true);
									},
									className: "flex-1 flex items-center justify-between py-2 px-3 rounded-lg bg-surface border border-border/80 hover:border-primary text-xs uppercase font-mono text-foreground font-semibold transition-all hover:bg-card",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-3.5 text-primary" }), "My Bookings"]
									}), myBookingsCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-5 rounded-full bg-primary text-primary-foreground font-mono text-[10px] font-bold grid place-items-center",
										children: myBookingsCount
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground font-mono",
										children: "(0)"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setMenuOpen(false);
										setAdminOpen(true);
									},
									className: "flex items-center gap-1.5 py-2 px-3 rounded-lg border border-primary/40 text-primary hover:bg-primary/10 text-xs uppercase font-mono font-semibold transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Admin" })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2",
								children: [
									["About", "#about"],
									["Master Plan", "#masterplan"],
									["Live Photos", "#site-gallery"],
									["Amenities", "#amenities"],
									["Connectivity", "#location"],
									["ROI Calculator", "#calculator"],
									["Pricing", "#pricing"],
									["FAQ", "#faq"],
									["Contact", "#contact"]
								].map(([label, href], idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href,
									itemProp: "url",
									onClick: () => setMenuOpen(false),
									className: "flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-surface text-sm uppercase tracking-wider text-muted-foreground hover:text-primary font-medium transition-colors border border-transparent hover:border-border/60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										itemProp: "name",
										children: label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-[10px] text-muted-foreground/60",
										children: ["0", idx + 1]
									})]
								}, label))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-4 mt-2 border-t border-border/80 grid grid-cols-1 sm:grid-cols-2 gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => {
										setMenuOpen(false);
										setSelectedPlotForVisit("1000 sq ft");
										setSiteVisitOpen(true);
									},
									className: "w-full h-11 uppercase text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
									children: ["Book Free Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => {
										setMenuOpen(false);
										setBrochureOpen(true);
									},
									className: "w-full h-11 uppercase text-xs border-border/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 mr-1.5" }), " Download E-Brochure"]
								})]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[92vh] min-h-[92dvh] items-end pt-20 sm:pt-24 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: township_entrance_default,
						alt: "Galaxy Green Sai Suraksha Nagar grand gated entrance archway in Lucknow",
						width: 1920,
						height: 1080,
						className: "absolute inset-0 h-full w-full object-cover scale-105 transition-transform duration-1000 ease-out"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-hero-overlay" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-grid opacity-25" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20 pt-28 sm:pt-36 lg:pb-24 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-glow -top-10 -left-10 opacity-75" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-4xl relative z-10 w-full min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 sm:mb-6 flex flex-wrap items-center gap-2.5 sm:gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/80 px-3.5 sm:px-4 py-1.5 backdrop-blur-md shadow-sm max-w-full",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/20 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] sm:text-xs uppercase tracking-widest text-primary font-mono font-medium truncate",
												children: "Phase 1 Open · Amausi Airport Growth Corridor"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-950/60 px-3 py-1 backdrop-blur-md",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] sm:text-[11px] uppercase tracking-wider text-emerald-300 font-mono font-medium",
												children: "Official Registry Seal"
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 mb-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative size-20 sm:size-24 md:size-28 rounded-full overflow-hidden shadow-luxury ring-2 ring-primary/60 bg-white/10 p-1.5 backdrop-blur-md shrink-0 hover:scale-105 transition-transform duration-300 group",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: "/galaxy-green-emblem.png?v=2",
												alt: "Official Galaxy Green Sai Suraksha Nagar Seal Logo",
												width: 112,
												height: 112,
												className: "size-full object-contain filter drop-shadow-md"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full ring-1 ring-inset ring-white/20 pointer-events-none" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
											className: "fluid-hero-title",
											children: ["Galaxy Green", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1.5 sm:mt-2 block text-emerald-gradient",
												children: "Sai Suraksha Nagar"
											})]
										}) })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 sm:mt-7 max-w-2xl text-sm sm:text-base lg:text-lg leading-relaxed text-foreground/80 text-pretty",
										children: "Secure your freehold residential plot at Amausi, Lucknow—where high-yield airport connectivity meets an eco-luxury gated community. Immediate registry and bank loan approvals."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-7 sm:mt-9 flex flex-wrap gap-2.5 sm:gap-3.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "lg",
												onClick: () => {
													setSelectedPlotForVisit("1000 sq ft");
													setSiteVisitOpen(true);
												},
												className: "h-11 sm:h-13 px-5 sm:px-8 uppercase tracking-wider text-[11px] sm:text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
												children: ["Schedule Site Visit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 sm:size-4 ml-1.5 sm:ml-2" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												variant: "outline",
												className: "h-11 sm:h-13 border-foreground/30 bg-background/40 px-4 sm:px-7 uppercase tracking-wider text-[11px] sm:text-xs backdrop-blur-md hover:bg-background/60",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "#masterplan",
													children: ["Explore Master Plan ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5 sm:size-4 ml-1.5 sm:ml-2" })]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "lg",
												variant: "ghost",
												onClick: () => setBrochureOpen(true),
												className: "h-11 sm:h-13 px-4 sm:px-6 uppercase tracking-wider text-[11px] sm:text-xs border border-primary/30 text-primary bg-primary/10 hover:bg-primary/20 backdrop-blur-md",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 sm:size-4 mr-1.5 sm:mr-2" }), " E-Brochure"]
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 sm:mt-14 grid w-full max-w-4xl grid-cols-2 border border-border/80 bg-background/60 backdrop-blur-xl rounded-md divide-y sm:divide-y-0 sm:divide-x divide-border/60 sm:grid-cols-4 shadow-luxury relative z-10 min-w-0",
								children: [
									[
										`₹${baseRate.toLocaleString("en-IN")}`,
										"Per Sq Ft Rate",
										"Phase 1 fixed pricing"
									],
									[
										"600+",
										"Sq Ft Min Size",
										"Up to custom requirement"
									],
									[
										"100%",
										"Freehold & Mutation",
										"Dakhil Kharij ready"
									],
									[
										"1.5 km",
										"Railway Station",
										"3 km to CCS Airport & 4 km Metro"
									]
								].map(([value, label, sub]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 sm:p-5 transition-colors hover:bg-white/[0.02] min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "font-display text-xl sm:text-2xl lg:text-3xl text-primary block tracking-tight truncate",
											children: value
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-[11px] sm:text-xs uppercase font-medium text-foreground tracking-wide truncate",
											children: label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] sm:text-[10px] text-muted-foreground font-mono block mt-0.5 truncate",
											children: sub
										})
									]
								}, label))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "about",
				className: "section-shell border-b border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-6 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "01 · Prime Plotted Living"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Build The Villa You Always Envisioned"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base sm:text-lg leading-relaxed text-muted-foreground",
									children: "Galaxy Green Sai Suraksha Nagar is meticulously planned for homeowners and astute real estate investors. Spread across lush green surroundings near Chaudhary Charan Singh International Airport, our layout gives you complete architectural freedom to design your private 2-storey duplex, family estate, or lush green retirement haven."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "card-architectural group p-5 rounded-lg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram size-11 mb-3.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "size-5 transition-transform duration-300 group-hover:scale-110" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-base uppercase text-foreground font-semibold tracking-tight",
												children: "Airport Growth Hub"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
												children: "Just 5 minutes from Amausi Airport. Prime zone benefiting from Lucknow’s infrastructure surge."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "card-architectural group p-5 rounded-lg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "icon-monogram-gold size-11 mb-3.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-5 transition-transform duration-300 group-hover:scale-110" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-base uppercase text-foreground font-semibold tracking-tight",
												children: "Zero Legal Ambiguity"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
												children: "100% freehold land with instant registry and mutation. Bank loan assistance up to 80%."
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setSelectedPlotForVisit("1000 sq ft");
											setSiteVisitOpen(true);
										},
										className: "h-12 px-6 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
										children: ["Schedule Free On-Site Inspection ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })]
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-6 relative",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-lg border border-primary/40 shadow-glow group",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: luxury_villa_concept_default,
										alt: "Modern luxury eco villa concept at Galaxy Green Sai Suraksha Nagar",
										width: 1280,
										height: 714,
										loading: "lazy",
										decoding: "async",
										className: "w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-6 left-6 right-6 p-4 rounded bg-background/80 backdrop-blur-md border border-border/80",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase font-mono text-primary tracking-widest block font-semibold",
												children: "Villa Concept"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-sm font-display uppercase text-foreground",
												children: "Contemporary 2-Storey Duplex on 1,500 Sq Ft"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "border-primary/50 text-primary bg-primary/10 text-[10px] font-mono",
												children: "Vastu Compliant"
											})]
										})
									})
								]
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterPlanViewer, { onSelectPlotForBooking: handlePlotSelectForBooking }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActualSiteGallery, { onScheduleVisit: (plotText) => {
				setSelectedPlotForVisit(plotText || "600 sq ft");
				setSiteVisitOpen(true);
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmenitiesSection, { onScheduleVisit: () => {
				setSelectedPlotForVisit("1000 sq ft");
				setSiteVisitOpen(true);
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "location",
				className: "section-shell bg-background border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-6 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "04 · Strategic Positioning"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Direct Airport & Metro Connectivity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base leading-relaxed text-muted-foreground",
									children: "Located at Sai Suraksha Nagar, Amausi, Lucknow (PIN 226008). Benefit from premier connectivity: 1.5 km from Railway Station, 2 km from TS Mishra Medical College & Hospital, 2.5 km from Kanpur-Lucknow Expressway, 3 km from CCS Airport, 4 km from Metro Station, and 500 m from Main Market."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2",
									children: [
										{
											icon: TramFront,
											dist: "1.5 km",
											label: "Railway Station",
											sub: "~3 Mins · Fast Transit Hub"
										},
										{
											icon: HeartPulse,
											dist: "2.0 km",
											label: "TS Mishra",
											sub: "Medical College & Hospital"
										},
										{
											icon: Plane,
											dist: "3.0 km",
											label: "CCS Airport",
											sub: "Chaudhary Charan Singh Intl"
										},
										{
											icon: Car,
											dist: "2.5 km",
											label: "Kanpur-Lucknow Expressway",
											sub: "High-Speed Access Link"
										},
										{
											icon: Route,
											dist: "4.0 km",
											label: "Metro Station",
											sub: "Amausi Metro · Red Line"
										},
										{
											icon: ShoppingBag,
											dist: "500 m",
											label: "Main Market",
											sub: "Daily Needs & Commercial Hub"
										}
									].map((item) => {
										const Icon = item.icon;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-lg bg-surface border border-border/80 text-center hover:border-primary/50 transition-all duration-300 group hover:-translate-y-1 hover:shadow-luxury",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "icon-monogram size-9 mx-auto mb-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 transition-transform duration-300 group-hover:scale-110" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "font-display text-2xl text-primary block group-hover:scale-105 transition-transform",
													children: item.dist
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-foreground uppercase block mt-1 line-clamp-1",
													children: item.label
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono block mt-0.5",
													children: item.sub
												})
											]
										}, item.label);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										className: "h-11 px-5 border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground uppercase text-xs tracking-wider",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: MAP_URL,
											target: "_blank",
											rel: "noreferrer",
											children: ["Open In Google Maps ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 ml-2" })]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setSelectedPlotForVisit("Airport Corridor Plot");
											setSiteVisitOpen(true);
										},
										className: "h-11 px-5 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
										children: ["Schedule Site Tour ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 ml-2" })]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-lg border border-border shadow-glow group cursor-pointer",
								onClick: () => {
									resetAirportView();
									setAirportModalOpen(true);
								},
								role: "button",
								tabIndex: 0,
								"aria-label": "View Chaudhary Charan Singh International Airport connectivity map in full screen HD",
								onKeyDown: (e) => {
									if (e.key === "Enter" || e.key === " ") {
										e.preventDefault();
										resetAirportView();
										setAirportModalOpen(true);
									}
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: lucknow_connectivity_default,
										alt: "Galaxy Green strategic location map and connectivity to Chaudhary Charan Singh International Airport Lucknow",
										width: 1e3,
										height: 625,
										loading: "lazy",
										decoding: "async",
										className: "w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background/95 via-transparent to-transparent pointer-events-none" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-3.5 right-3.5 z-10 flex items-center gap-2 rounded-full border border-primary/40 bg-background/85 px-3 py-1.5 backdrop-blur-md shadow-md transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-mono font-medium uppercase tracking-wider",
											children: "Full Screen HD"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute bottom-5 left-5 right-5 p-4 rounded bg-background/80 backdrop-blur-md border border-border flex items-center justify-between pointer-events-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-sm font-display uppercase text-foreground",
												children: "Galaxy Green Sai Suraksha Nagar"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground font-mono mt-0.5",
												children: "QR4X+39W, Amausi, Lucknow, Uttar Pradesh 226008"
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "hidden sm:inline-flex items-center gap-1.5 text-xs font-mono text-primary font-semibold",
											children: ["Click To Enlarge ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-3.5" })]
										})]
									})
								]
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmiRoiCalculator, {
				onLockPriceClick: handleCalculatorLock,
				baseRate
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "section-shell bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalTrustBadge, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "section-shell bg-surface border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 lg:grid-cols-12 items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "05 · Ground Execution"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "On-Site Progress Tracker"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground leading-relaxed",
									children: "We believe in complete transparency. Every infrastructure component is being developed as per timeline."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "06 · Buyer Experiences"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Trusted By Families & Investors"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-card border border-border p-6 rounded space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex text-amber-400 gap-1 text-xs",
												children: "★".repeat(5)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground leading-relaxed italic",
												children: "\"Visiting the site near Amausi Airport gave us huge confidence. The road widths are actually 40 feet as promised, and the title paperwork was crystal clear. We booked a 1,500 sq ft plot for our family home.\""
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-xs text-foreground uppercase block font-display",
													children: "Dr. S. K. Rastogi"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono",
													children: "Consultant Physician · Lucknow"
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "bg-card border border-border p-6 rounded space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex text-amber-400 gap-1 text-xs",
												children: "★".repeat(5)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground leading-relaxed italic",
												children: "\"From an investment standpoint, the proximity to the new airport terminal and Shaheed Path made this an easy choice. Vishal Chauhan and his team arranged immediate registry documentation without any hassle.\""
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 border-t border-border/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-xs text-foreground uppercase block font-display",
													children: "Rajesh Singhania"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground font-mono",
													children: "Business Owner & Property Investor"
												})]
											})
										]
									})]
								})
							]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "pricing",
				className: "section-shell bg-background border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col lg:flex-row lg:items-end justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "07 · Phase 1 Pricing"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "section-title",
								children: "Transparent Allotment Rates"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-l-2 border-primary pl-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-3xl font-semibold text-primary",
									children: [
										"₹",
										baseRate.toLocaleString("en-IN"),
										" / Sq Ft"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground font-mono mt-1",
									children: "Fixed Phase 1 Base Rate · Min 600 Sq Ft to Custom Requirements"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								{
									size: "600",
									dim: "20 × 30 ft",
									total: `₹${(600 * baseRate).toLocaleString("en-IN")}`,
									note: "Minimum entry size. Ideal for compact smart duplex or high-yield investment.",
									tag: "Starting Size",
									popular: false
								},
								{
									size: "1,000",
									dim: "25 × 40 ft",
									total: `₹${(1e3 * baseRate).toLocaleString("en-IN")}`,
									note: "Most sought-after layout. Perfect for luxury 3BHK independent villa with lawn & parking.",
									tag: "Most Popular",
									popular: true
								},
								{
									size: "1,500",
									dim: "30 × 50 ft",
									total: `₹${(1500 * baseRate).toLocaleString("en-IN")}`,
									note: "Generous frontage for front lawn, two-car parking, and spacious terrace garden.",
									tag: "Executive Villa",
									popular: false
								},
								{
									size: "Custom",
									dim: "As Per Requirement",
									total: `₹${baseRate.toLocaleString("en-IN")} / sq ft`,
									note: "Tailored to your exact wish. Combine multiple plots for large commercial or luxury estates.",
									tag: "On Buyer Wish",
									popular: false
								}
							].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `relative rounded-md border p-6 bg-card flex flex-col justify-between transition-all hover:shadow-glow ${card.popular ? "border-primary shadow-glow ring-1 ring-primary/40" : "border-border"}`,
								children: [
									card.tag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `absolute right-0 top-0 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider font-mono rounded-bl ${card.popular ? "bg-primary text-primary-foreground" : "bg-surface border-b border-l border-border text-muted-foreground"}`,
										children: card.tag
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs uppercase tracking-widest text-muted-foreground font-mono",
											children: "Residential Plot"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex items-baseline gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "font-display text-4xl font-semibold text-foreground",
												children: card.size
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs uppercase font-mono text-muted-foreground",
												children: card.size === "Custom" ? "Sizes" : "Sq Ft"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground font-mono block mt-1",
											children: card.dim
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-5 h-px bg-border" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase font-mono text-muted-foreground block",
											children: "Allotment Cost"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-display text-2xl font-semibold text-primary",
											children: card.total
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-xs text-muted-foreground leading-relaxed",
											children: card.note
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => {
												setSelectedPlotForVisit(card.size === "Custom" ? "Custom Requirement" : `${card.size} sq ft`);
												setSiteVisitOpen(true);
											},
											className: "w-full h-10 uppercase text-xs tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
											children: ["Reserve This Plot ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5 ml-1.5" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											onClick: () => setBrochureOpen(true),
											className: "w-full h-9 uppercase text-[11px] tracking-wider border-border",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3 mr-1.5" }), " Specifications"]
										})]
									})
								]
							}, card.size))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-center text-xs text-muted-foreground font-mono",
							children: "* Prices are exclusive of government registration fees and stamp duty. Bank loan financing available up to 80%."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "faq",
				className: "section-shell bg-background border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center max-w-2xl mx-auto mb-12",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "08 · Buyer Knowledge Base"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "section-title",
								children: "Frequently Asked Questions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "section-subtitle mx-auto",
								children: "Everything property buyers and NRI investors need to know about freehold land registry, bank loans, location advantages, and payment schedules at Galaxy Green."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-card border border-border rounded-xl p-6 sm:p-8 shadow-glow",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Accordion, {
							type: "single",
							collapsible: true,
							defaultValue: "item-1",
							className: "w-full divide-y divide-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-1",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Where is Galaxy Green Sai Suraksha Nagar located in Lucknow?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Galaxy Green Sai Suraksha Nagar is strategically located in Amausi, Lucknow (Plus Code: QR4X+39W, Pin 226008). Key nearby connectivity points include: Railway Station (1.5 km), TS Mishra Medical College & Hospital (2 km), CCS Airport (3 km), Kanpur-Lucknow Expressway (2.5 km), Metro Station (4 km), and Main Market (500 m). Head Office: Barabirwa Ajanta Tower, Shop No. 35, Lucknow."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-2",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "What are the plot sizes and rates per sq ft at Galaxy Green?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: [
											"Standard residential plots start at a transparent Phase 1 rate of ₹",
											baseRate.toLocaleString("en-IN"),
											" per sq ft. Minimum plot area starts from 600 sq ft, and maximum can be fully tailored to your wish and architectural requirements:",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
												className: "list-disc pl-5 mt-2 space-y-1 text-xs sm:text-sm font-mono text-foreground/90",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"600 Sq Ft (20 × 30 ft) — starting at ₹",
														(600 * baseRate / 1e5).toFixed(2),
														" ",
														"Lakh (Ideal budget duplex)"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"800 Sq Ft (20 × 40 ft) — starting at ₹",
														(800 * baseRate / 1e5).toFixed(2),
														" ",
														"Lakh"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"1,000 Sq Ft (25 × 40 ft) — starting at ₹",
														(1e3 * baseRate / 1e5).toFixed(2),
														" Lakh (Most popular 3BHK)"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"1,200 Sq Ft (30 × 40 ft) — starting at ₹",
														(1200 * baseRate / 1e5).toFixed(2),
														" Lakh"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"1,500 Sq Ft (30 × 50 ft) — starting at ₹",
														(1500 * baseRate / 1e5).toFixed(2),
														" Lakh (Executive villa)"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
														"2,000 Sq Ft (40 × 50 ft) — starting at ₹",
														(2e3 * baseRate / 1e5).toFixed(2),
														" Lakh (Luxury estate)"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Custom plot sizes up to 5,000+ sq ft customized as per buyer requirement" })
												]
											}),
											"Corner and wide-boulevard facing plots carry standard Preferential Location Charges (PLC)."
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-3",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Are the plots freehold with immediate registry and Dakhil Kharij?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Yes, 100%. All plots at Galaxy Green are strictly freehold with clear, unencumbered land titles. We guarantee instant registry upon payment completion along with full government land mutation (Dakhil Kharij) documentation assistance. You receive complete legal ownership rights to build or hold."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-4",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "Can I avail a bank loan or easy EMI facility for plot purchase?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: "Yes. We have active tie-ups and verification processes with leading nationalized and private banking institutions (SBI, HDFC, ICICI, PNB, and Bank of Baroda). Eligible buyers can secure up to 75%–80% financing with low interest rates and flexible tenures up to 20 years."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-5",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "What infrastructure and amenities are provided inside the township?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: ["Galaxy Green is developed as an eco-luxury gated township featuring:", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
											className: "list-disc pl-5 mt-2 space-y-1 text-xs sm:text-sm text-foreground/90",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "30-ft and 40-ft wide paved internal concrete boulevards" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Underground drainage and sewage system" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Solar-powered street illumination and dedicated transformer power supply" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "24/7 manned security checkpoint with automated RFID barrier & CCTV" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Landscaped community park, children's play area, and open green recreational spaces" })
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
									value: "item-6",
									className: "border-b-0 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
										className: "text-left font-display uppercase tracking-wide text-foreground hover:text-primary text-base sm:text-lg",
										children: "How can I schedule a personal site visit to Galaxy Green?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionContent, {
										className: "text-muted-foreground text-sm sm:text-base leading-relaxed pt-2",
										children: [
											"You can schedule a personalized site tour directly on our website or by contacting our project sales desk at",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "tel:+919044412642",
												className: "text-primary font-semibold underline",
												children: "+91 90444 12642"
											}),
											". Our site coordinators are available daily from 9:00 AM to 6:30 PM to guide you through the property, inspect plot demarcation stones, and verify registry paperwork on-site."
										]
									})]
								})
							]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "contact",
				className: "section-shell bg-surface border-t border-border pb-28 sm:pb-20 min-w-0 w-full overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl min-w-0 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 lg:gap-12 lg:grid-cols-12 items-start min-w-0 w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5 space-y-6 min-w-0 w-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "09 · Direct Management Contact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Arrange Your Personal Site Tour"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base text-muted-foreground leading-relaxed break-words",
									children: "Connect directly with the management team. Submit your requirement below to receive verified layout sheets, schedule a personalized site visit, or discuss custom plot boundaries."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-6 rounded-xl bg-card border border-primary/40 shadow-glow space-y-4 min-w-0 w-full",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-11 sm:size-12 rounded-full bg-primary/10 border border-primary/30 text-primary grid place-items-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 sm:size-6" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] uppercase font-mono tracking-wider text-muted-foreground block truncate",
													children: "Managing Director"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "font-display text-base sm:text-lg uppercase text-foreground font-semibold truncate",
													children: "Vishal Chauhan"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2.5 text-xs font-mono pt-3 border-t border-border/60 min-w-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col xs:flex-row xs:items-center justify-between gap-1 py-1.5 border-b border-border/40 min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[11px] uppercase tracking-wider shrink-0",
														children: "Direct Hotline:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: "tel:+919044412642",
														className: "text-primary font-semibold hover:underline break-all xs:break-words xs:text-right font-mono",
														children: "+91 90444 12642"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col xs:flex-row xs:items-start justify-between gap-1 py-1.5 border-b border-border/40 min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[11px] uppercase tracking-wider shrink-0",
														children: "Head Office:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground break-words xs:text-right min-w-0",
														children: "Barabirwa Ajanta Tower, Shop No. 35"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col xs:flex-row xs:items-start justify-between gap-1 py-1.5 border-b border-border/40 min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[11px] uppercase tracking-wider shrink-0",
														children: "Site Address:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground break-words xs:text-right min-w-0",
														children: "Sai Suraksha Nagar, Amausi, Lucknow"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col xs:flex-row xs:items-center justify-between gap-1 py-1.5 min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground text-[11px] uppercase tracking-wider shrink-0",
														children: "Office Hours:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground break-words xs:text-right min-w-0",
														children: "9:00 AM – 6:30 PM (Daily)"
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											className: "w-full h-11 uppercase text-xs tracking-wider font-semibold bg-emerald-600 hover:bg-emerald-500 text-white min-w-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `https://wa.me/${PHONE}?text=${encodeURIComponent("Hello Vishal Chauhan, I would like to schedule a discussion regarding Galaxy Green Sai Suraksha Nagar.")}`,
												target: "_blank",
												rel: "noreferrer",
												className: "flex items-center justify-center truncate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4 mr-2 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: "Chat Directly On WhatsApp"
												})]
											})
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7 bg-card border border-border rounded-xl p-4 sm:p-8 min-w-0 w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-4 mb-6 pb-3 border-b border-border/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg sm:text-xl uppercase tracking-tight text-foreground",
									children: "Send Booking Inquiry"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] sm:text-xs text-muted-foreground font-mono",
									children: "Instant Response Guaranteed"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submitEnquiry,
								className: "space-y-4",
								noValidate: true,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										name: "website",
										tabIndex: -1,
										autoComplete: "off",
										value: contactHoneypot,
										onChange: (e) => setContactHoneypot(e.target.value),
										className: "hidden",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "form-label",
											children: "Full Name *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											name: "name",
											maxLength: 80,
											autoComplete: "name",
											placeholder: "Enter your name",
											value: contactName,
											onChange: (e) => setContactName(e.target.value),
											className: "form-control"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "form-label",
											children: "Mobile Number *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											name: "phone",
											inputMode: "numeric",
											maxLength: 10,
											autoComplete: "tel",
											placeholder: "10-digit mobile",
											value: contactPhone,
											onChange: (e) => setContactPhone(e.target.value),
											className: "form-control"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-1 mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "contact-plot-preference",
											className: "form-label mb-0 cursor-pointer",
											children: "Plot Preference"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] sm:text-xs font-mono text-emerald-400 font-medium",
											children: [
												"₹",
												baseRate.toLocaleString("en-IN"),
												" / Sq Ft Base"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "contact-plot-preference",
										"aria-label": "Select plot size preference",
										value: contactPlot,
										onChange: (e) => setContactPlot(e.target.value),
										className: "form-control block w-full px-4 text-xs font-mono",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "600 sq ft",
												children: [
													"600 Sq Ft (₹",
													(600 * baseRate / 1e5).toFixed(2),
													" Lakh · Starting Size)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "800 sq ft",
												children: [
													"800 Sq Ft (₹",
													(800 * baseRate / 1e5).toFixed(2),
													" Lakh)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "1000 sq ft",
												children: [
													"1,000 Sq Ft (₹",
													(1e3 * baseRate / 1e5).toFixed(2),
													" Lakh · Most Popular)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "1200 sq ft",
												children: [
													"1,200 Sq Ft (₹",
													(1200 * baseRate / 1e5).toFixed(2),
													" Lakh)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "1500 sq ft",
												children: [
													"1,500 Sq Ft (₹",
													(1500 * baseRate / 1e5).toFixed(2),
													" Lakh)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "2000 sq ft",
												children: [
													"2,000 Sq Ft (₹",
													(2e3 * baseRate / 1e5).toFixed(2),
													" Lakh)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Custom Size",
												children: "⚡ Custom Size Requirement (Any Size On Buyer Wish)"
											})
										]
									})] }),
									contactPlot === "Custom Size" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-lg bg-surface/90 border border-primary/40 space-y-2.5 animate-in fade-in",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] font-mono text-primary font-semibold",
													children: "Custom Area (Sq Ft):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] font-mono text-emerald-400 font-semibold",
													children: [
														"Estimated: ₹",
														(customPlotArea * baseRate / 1e5).toFixed(2),
														" Lakh"
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 600,
													max: 25e3,
													step: 50,
													value: customPlotArea,
													onChange: (e) => {
														const v = parseInt(e.target.value, 10);
														setCustomPlotArea(isNaN(v) ? 600 : v);
													},
													className: "h-9 text-xs font-mono font-semibold bg-background"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-mono text-muted-foreground",
													children: "Sq Ft"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap gap-1",
												children: [
													750,
													1800,
													2500,
													3500,
													5e3
												].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setCustomPlotArea(s),
													className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${customPlotArea === s ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background border-border text-muted-foreground hover:text-foreground"}`,
													children: [s, " Sq Ft"]
												}, s))
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														htmlFor: "contact-visit-date",
														className: "form-label mb-0 flex items-center gap-1.5 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3 text-primary" }), " Calendar (Year / Month / Date)"]
													}), contactVisitDate === getLocalDateString() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-primary font-semibold font-mono",
														children: "Today"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "contact-visit-date",
													"aria-label": "Select preferred visit date",
													type: "date",
													min: getLocalDateString(),
													value: contactVisitDate,
													onChange: (e) => {
														const val = e.target.value;
														const minDate = getLocalDateString();
														if (val && val < minDate) {
															setFormError("Preferred visit date cannot be in the past. Only present and upcoming dates are allowed.");
															return;
														}
														setFormError("");
														setContactVisitDate(val);
													},
													className: "form-control"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-1.5 mt-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																setContactVisitDate(getLocalDateString());
																setFormError("");
															},
															className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${contactVisitDate === getLocalDateString() ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background/80 border-border text-muted-foreground hover:text-foreground"}`,
															children: "Today"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																const d = /* @__PURE__ */ new Date();
																d.setDate(d.getDate() + 1);
																setContactVisitDate(getLocalDateString(d));
																setFormError("");
															},
															className: "px-2 py-0.5 rounded text-[10px] font-mono border border-border text-muted-foreground hover:text-foreground bg-background/80 transition-all",
															children: "Tomorrow"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[9px] font-mono text-muted-foreground ml-auto",
															children: "Past dates blocked"
														})
													]
												})
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center justify-between gap-1 mb-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "form-label mb-0 flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-primary" }), " Preferred Visit Timing"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => setShowContactClock((prev) => !prev),
														className: "text-[10px] sm:text-xs font-mono text-primary hover:underline flex items-center gap-1 font-semibold",
														children: ["🕒 ", showContactClock ? "Hide Clock" : "Open Clock Selector"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: "e.g. 11:30 AM or 05:00 PM",
													value: contactCustomTime,
													onChange: (e) => {
														setContactCustomTime(e.target.value);
														setFormError("");
													},
													className: "form-control"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1 mt-1.5",
													children: [
														"10:00 AM",
														"11:30 AM",
														"02:00 PM",
														"04:30 PM",
														"05:30 PM"
													].map((t) => {
														const isPassed = isTimePassedForDate(t, contactVisitDate || getLocalDateString());
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															disabled: isPassed,
															onClick: () => {
																if (isPassed) return;
																setContactCustomTime(t);
																setFormError("");
															},
															className: `px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${isPassed ? "opacity-35 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : contactCustomTime === t ? "bg-primary text-primary-foreground border-primary font-semibold" : "bg-background/80 border-border text-muted-foreground hover:text-foreground"}`,
															children: [t, isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "ml-1 text-[8px] no-underline",
																children: "✕"
															})]
														}, t);
													})
												})
											] })]
										}), showContactClock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "animate-in fade-in slide-in-from-top-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockTimePicker, {
												value: contactCustomTime || "11:30 AM",
												onChange: (val) => {
													setContactCustomTime(val);
													setFormError("");
												},
												selectedDate: contactVisitDate || getLocalDateString(),
												compact: false
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "form-label",
										children: "Notes or Special Requirements"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										name: "message",
										maxLength: 500,
										placeholder: "Preferred visit date, questions about bank loan, corner plots, etc.",
										value: contactMessage,
										onChange: (e) => setContactMessage(e.target.value),
										className: "mt-2 min-h-28 border-border bg-background/50 text-xs"
									})] }),
									formError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										role: "alert",
										className: "text-xs text-destructive bg-destructive/10 p-2.5 rounded",
										children: formError
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										disabled: formSubmitting,
										className: "w-full h-12 uppercase tracking-wider text-xs font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow btn-shimmer",
										children: [formSubmitting ? "Submitting Inquiry..." : "Submit Inquiry & Connect On WhatsApp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center text-[11px] text-muted-foreground font-mono",
										children: "Your inquiry is recorded in real time and opens directly with project MD Vishal Chauhan."
									})
								]
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border bg-background px-5 pt-12 pb-24 sm:pb-16 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl flex flex-col gap-8 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { showMotto: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-1 text-xs leading-relaxed text-muted-foreground max-w-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground font-semibold",
								children: "Head Office:"
							}), " Barabirwa Ajanta Tower, Shop No. 35, Lucknow, Uttar Pradesh."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground font-semibold",
								children: "Site Address:"
							}), " Galaxy Green Sai Suraksha Nagar, QR4X+39W, Amausi, Lucknow, Uttar Pradesh 226008."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground/80 font-mono",
								children: "Freehold residential plotted development with immediate registry and mutation."
							})
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 text-xs font-mono text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setMyBookingsOpen(true),
								className: "text-foreground hover:text-primary hover:underline flex items-center gap-1 uppercase",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-3 text-primary" }),
									" My Bookings",
									myBookingsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-0.5 px-1.5 py-0.2 rounded-full bg-primary text-primary-foreground text-[10px] font-bold",
										children: myBookingsCount
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setAdminOpen(true),
								className: "text-primary hover:underline flex items-center gap-1 uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), " Admin Portal"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setBrochureOpen(true),
								className: "hover:text-foreground uppercase",
								children: "Download Brochure"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:+${PHONE}`,
								"aria-label": "Call sales office at +91 90444 12642",
								className: "hover:text-foreground uppercase",
								children: "+91 90444 12642"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 Galaxy Green" })
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `fixed bottom-3 right-3 sm:bottom-6 sm:right-6 mb-[env(safe-area-inset-bottom,0px)] mr-[env(safe-area-inset-right,0px)] z-40 transition-all duration-300 ease-out max-w-[calc(100vw-1.5rem)] ${isFloatingDockVisible ? "opacity-100 translate-y-0 pointer-events-auto" : "opacity-0 translate-y-6 pointer-events-none"}`,
				children: dockMinimized ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setDockMinimized(false),
					className: "flex items-center gap-2 rounded-full border border-primary/50 bg-card/95 p-1 pl-1.5 pr-3 text-xs font-semibold uppercase tracking-wider text-foreground shadow-luxury backdrop-blur-xl transition-all hover:border-primary hover:bg-card hover:scale-105 active:scale-95",
					"aria-label": "Open Luxury Concierge Desk",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-7 rounded-full overflow-hidden shadow-glow ring-1 ring-primary/40 bg-white/10 flex items-center justify-center p-0.5 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/galaxy-green-emblem.png?v=2",
								alt: "Concierge",
								width: 28,
								height: 28,
								className: "size-full object-contain"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display tracking-normal text-xs text-primary font-semibold",
							children: "Concierge"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5 text-emerald-400 ml-0.5" })
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 sm:gap-2 rounded-full border border-border/80 bg-card/95 p-1 sm:p-1.5 pl-2.5 sm:pl-3 pr-1.5 sm:pr-2 shadow-luxury backdrop-blur-xl ring-1 ring-white/5 transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-2 pr-2 border-r border-border/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-5 rounded-full overflow-hidden ring-1 ring-primary/40 bg-white/10 flex items-center justify-center p-0.5 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/galaxy-green-emblem.png?v=2",
									alt: "Galaxy Green",
									width: 20,
									height: 20,
									className: "size-full object-contain"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] uppercase tracking-wider text-muted-foreground",
								children: "Direct Desk"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => {
								setSelectedPlotForVisit("1000 sq ft");
								setSiteVisitOpen(true);
							},
							size: "sm",
							className: "h-8.5 sm:h-9 px-2.5 sm:px-3.5 rounded-full uppercase tracking-wider text-[10px] sm:text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm border border-primary/50 btn-shimmer shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3 sm:size-3.5 mr-1 sm:mr-1.5" }), " Book Visit"]
						}),
						myBookingsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => setMyBookingsOpen(true),
							size: "sm",
							variant: "outline",
							className: "h-8.5 sm:h-9 px-2 sm:px-2.5 rounded-full uppercase tracking-wider text-[10px] sm:text-[11px] font-semibold border-primary/40 bg-primary/10 hover:bg-primary/20 text-primary shrink-0 flex items-center gap-1",
							title: "View My Scheduled Visits",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-3 sm:size-3.5" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visits" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-4 rounded-full bg-primary text-primary-foreground font-mono text-[9px] font-bold grid place-items-center",
									children: myBookingsCount
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "icon",
							className: "size-8.5 sm:size-9 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-transform hover:scale-105 shrink-0",
							"aria-label": "Chat directly on WhatsApp",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `https://wa.me/${PHONE}?text=${encodeURIComponent("Hello Vishal Chauhan, I am interested in Galaxy Green Sai Suraksha Nagar plots.")}`,
								target: "_blank",
								rel: "noreferrer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5 sm:size-4" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDockMinimized(true),
							className: "size-6 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface flex items-center justify-center text-xs transition-colors ml-0.5 shrink-0",
							title: "Minimize Concierge",
							"aria-label": "Minimize Concierge",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Suspense, {
				fallback: null,
				children: [
					myBookingsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyBookingsDrawer, {
						open: myBookingsOpen,
						onOpenChange: setMyBookingsOpen,
						onOpenVisitModal: () => setSiteVisitOpen(true),
						hideFloatingTrigger: true
					}),
					siteVisitOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteVisitModal, {
						open: siteVisitOpen,
						onOpenChange: setSiteVisitOpen,
						defaultPlotPreference: selectedPlotForVisit,
						baseRate
					}),
					brochureOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrochureModal, {
						open: brochureOpen,
						onOpenChange: setBrochureOpen
					}),
					adminOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLeadsDrawer, {
						open: adminOpen,
						onOpenChange: setAdminOpen
					})
				]
			}),
			airportModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 bg-background/95 backdrop-blur-2xl flex flex-col justify-between p-3 sm:p-6 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] animate-in fade-in duration-200",
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border/80 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 sm:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "border-primary/50 text-primary bg-primary/10 font-mono text-[11px] uppercase tracking-wider",
								children: "Full Screen HD · Original Quality"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-mono text-foreground font-medium hidden md:inline",
								children: "Chaudhary Charan Singh International Airport (LKO) & Amausi Plots"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1 bg-surface border border-border rounded-lg p-0.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => setAirportZoom((prev) => {
												const next = Math.max(.75, Number((prev - .25).toFixed(2)));
												if (next <= 1) setAirportPan({
													x: 0,
													y: 0
												});
												return next;
											}),
											disabled: airportZoom <= .75,
											className: "size-7 sm:size-8 text-foreground hover:bg-background",
											title: "Zoom Out",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-3.5 sm:size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono font-semibold px-1 min-w-[2.8rem] text-center",
											children: [Math.round(airportZoom * 100), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => setAirportZoom((prev) => Math.min(3.5, Number((prev + .25).toFixed(2)))),
											disabled: airportZoom >= 3.5,
											className: "size-7 sm:size-8 text-foreground hover:bg-background",
											title: "Zoom In",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-3.5 sm:size-4" })
										}),
										(airportZoom !== 1 || airportPan.x !== 0 || airportPan.y !== 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: resetAirportView,
											className: "size-7 sm:size-8 text-muted-foreground hover:text-foreground hover:bg-background",
											title: "Reset View",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setAirportModalOpen(false);
										setSelectedPlotForVisit("Airport Vicinity Plot");
										setSiteVisitOpen(true);
									},
									className: "h-8 px-3 uppercase text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 hidden sm:inline-flex",
									children: ["Inquire Plots ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => setAirportModalOpen(false),
									className: "size-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-surface",
									"aria-label": "Close Full Screen View",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative flex-1 flex items-center justify-center my-2 sm:my-3 overflow-hidden rounded-xl border border-border/80 bg-black/70 p-2 sm:p-4 select-none touch-none",
						onPointerDown: handleAirportPointerDown,
						onPointerMove: handleAirportPointerMove,
						onPointerUp: handleAirportPointerUp,
						onPointerCancel: handleAirportPointerUp,
						onWheel: handleAirportWheel,
						onDoubleClick: () => {
							if (airportZoom > 1) resetAirportView();
							else setAirportZoom(2);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "origin-center transition-transform select-none",
							style: {
								transform: `translate3d(${airportPan.x}px, ${airportPan.y}px, 0) scale(${airportZoom})`,
								transitionDuration: isAirportDragging ? "0ms" : "200ms",
								cursor: airportZoom > 1 ? isAirportDragging ? "grabbing" : "grab" : "zoom-in"
							},
							title: airportZoom > 1 ? "Drag to pan · Double-click to reset · Scroll to zoom" : "Click zoom controls, double-click, or use wheel/trackpad to zoom",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/assets/lucknow-connectivity-D3tu17Py.jpg",
								alt: "Chaudhary Charan Singh International Airport (LKO) and Amausi Available Plots aerial photograph",
								className: "max-h-[72vh] max-h-[72dvh] w-auto max-w-full object-contain rounded-lg shadow-2xl pointer-events-none select-none",
								draggable: false
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-border/80 pt-3 max-w-5xl mx-auto w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-xs sm:text-sm font-display uppercase tracking-wide text-foreground block",
								children: "Chaudhary Charan Singh International Airport · Runway (09/27) · Terminals 1 & 2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] sm:text-xs text-muted-foreground font-mono mt-0.5",
								children: "Direct connectivity to Kanpur Road (NH27), Amausi Metro Station & Galaxy Green Sai Suraksha Nagar available plots."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setAirportModalOpen(false);
										setSelectedPlotForVisit("Airport Vicinity Plot");
										setSiteVisitOpen(true);
									},
									className: "sm:hidden w-full h-8 uppercase text-[11px] font-semibold bg-primary text-primary-foreground",
									children: ["Inquire Nearby Plots ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3 ml-1" })]
								})
							})]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { Index as component };
