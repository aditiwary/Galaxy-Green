import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as Button, t as Badge } from "./badge-CC6878ln.mjs";
import { t as Input } from "./server-inquiries-BZCzG7ab.mjs";
import { t as Label } from "./label-C0fbpOZw.mjs";
import { C as MessageCircle, F as FilePen, G as Clock, J as CircleCheck, O as LoaderCircle, S as Pencil, Y as CircleAlert, a as User, k as Layers, l as Trash2, m as ShieldCheck, nt as Calendar, rt as CalendarCheck, x as Phone, y as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-oBgWH-X9.mjs";
import { t as Textarea } from "./textarea-CHsQRKv8.mjs";
import { f as subscribeToBookings, i as getLocalDateString, m as syncUpdateUserBooking, p as syncDeleteUserBooking, r as getLocalBookings } from "./visit-helpers-Cila1FpI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/MyBookingsDrawer-DUodn_Sa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHONE_NUMBER = "919044412642";
var PRESET_SLOTS = [
	"Morning (10:00 AM)",
	"Afternoon (2:00 PM)",
	"Evening Sunset (4:30 PM)",
	"Twilight Sunset Tour (5:30 PM)"
];
var PRESET_PLOTS = [
	"1000 sq ft (Residential)",
	"1200 sq ft (Standard)",
	"1500 sq ft (Premium Villa)",
	"2000 sq ft (Corner East Facing)",
	"Commercial Frontage (30 ft Road)"
];
function MyBookingsDrawer({ open: controlledOpen, onOpenChange: controlledOnOpenChange, onOpenVisitModal, hideFloatingTrigger = false }) {
	const [internalOpen, setInternalOpen] = (0, import_react.useState)(false);
	const isControlled = controlledOpen !== void 0;
	const open = isControlled ? controlledOpen : internalOpen;
	const setOpen = (val) => {
		if (isControlled) controlledOnOpenChange?.(val);
		else setInternalOpen(val);
	};
	const [bookings, setBookings] = (0, import_react.useState)([]);
	const [deletingId, setDeletingId] = (0, import_react.useState)(null);
	const [confirmDeleteId, setConfirmDeleteId] = (0, import_react.useState)(null);
	const [editingBooking, setEditingBooking] = (0, import_react.useState)(null);
	const [editDate, setEditDate] = (0, import_react.useState)("");
	const [editSlot, setEditSlot] = (0, import_react.useState)("");
	const [editPlot, setEditPlot] = (0, import_react.useState)("");
	const [editMessage, setEditMessage] = (0, import_react.useState)("");
	const [isSavingEdit, setIsSavingEdit] = (0, import_react.useState)(false);
	const todayStr = getLocalDateString(/* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		setBookings(getLocalBookings());
		const unsubscribe = subscribeToBookings((updated) => {
			setBookings(updated);
		});
		const handleOpenEvent = () => setOpen(true);
		window.addEventListener("open-my-bookings", handleOpenEvent);
		return () => {
			unsubscribe();
			window.removeEventListener("open-my-bookings", handleOpenEvent);
		};
	}, [isControlled, controlledOnOpenChange]);
	const handleStartEdit = (booking, e) => {
		e.stopPropagation();
		setEditingBooking(booking);
		setEditDate(booking.visitDate || todayStr);
		setEditSlot(booking.slot || "Morning (10:00 AM)");
		setEditPlot(booking.plotPreference || "1000 sq ft");
		setEditMessage(booking.message || "");
	};
	const handleSaveEdit = async (e) => {
		e.preventDefault();
		if (!editingBooking) return;
		if (editDate && editDate < todayStr) {
			toast.error("Visit date cannot be in the past. Please select today or a future date.");
			return;
		}
		setIsSavingEdit(true);
		try {
			const res = await syncUpdateUserBooking(editingBooking.id, {
				visitDate: editDate,
				slot: editSlot,
				plotPreference: editPlot,
				message: editMessage,
				phone: editingBooking.phone
			});
			if (res.success) {
				toast.success(`Booking #${editingBooking.id} updated & synced with server!`);
				setEditingBooking(null);
			} else toast.error(res.error || "Failed to update booking on server.");
		} catch (err) {
			toast.error("Network error while saving changes.");
			console.error(err);
		} finally {
			setIsSavingEdit(false);
		}
	};
	const handleExecuteDelete = async (id, phone) => {
		setDeletingId(id);
		try {
			const res = await syncDeleteUserBooking(id, phone);
			if (res.success) toast.success(`Booking #${id} cancelled and removed from server.`);
			else toast.warning(res.error || `Removed from device. Server sync pending.`);
		} catch (err) {
			console.error("Delete error:", err);
			toast.info("Booking removed from device.");
		} finally {
			setDeletingId(null);
			setConfirmDeleteId(null);
		}
	};
	const formatDateLabel = (isoOrDate) => {
		if (!isoOrDate) return "Flexible / To be coordinated";
		try {
			const parts = isoOrDate.split("T")[0].split("-");
			if (parts.length === 3) return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10)).toLocaleDateString("en-IN", {
				weekday: "short",
				day: "numeric",
				month: "short",
				year: "numeric"
			});
			return isoOrDate;
		} catch {
			return isoOrDate;
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		!hideFloatingTrigger && bookings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed bottom-4 left-3 sm:bottom-6 sm:left-6 mb-[env(safe-area-inset-bottom,0px)] ml-[env(safe-area-inset-left,0px)] z-40 transition-all duration-300",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "group relative flex items-center gap-1.5 sm:gap-2 rounded-full border border-primary/50 bg-card/95 py-1.5 px-3 sm:py-2 sm:px-4 shadow-luxury backdrop-blur-xl ring-1 ring-white/10 hover:border-primary hover:shadow-[0_0_25px_rgba(16,185,129,0.35)] hover:scale-105 active:scale-95 transition-all text-foreground",
				"aria-label": "View My Bookings",
				title: "My Bookings (Cached on device & synced with server)",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex items-center justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-4 sm:size-4.5 text-primary group-hover:text-emerald-300 transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "absolute -top-1 -right-1 flex h-2 w-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-emerald-500" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs font-semibold uppercase tracking-wider text-foreground",
						children: "My Bookings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-5 rounded-full bg-primary text-primary-foreground font-mono text-[10px] font-bold grid place-items-center shadow-sm",
						children: bookings.length
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md sm:max-w-lg p-5 sm:p-6 bg-card border-border shadow-2xl rounded-2xl max-h-[88vh] flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
						className: "space-y-1.5 pb-3 border-b border-border/70 text-left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-full overflow-hidden shadow-glow ring-1.5 ring-primary/40 bg-white/10 flex items-center justify-center p-0.5 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/galaxy-green-emblem.png?v=2",
										alt: "Official Galaxy Green Seal",
										width: 40,
										height: 40,
										className: "size-full object-contain"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
									className: "font-display text-lg uppercase tracking-tight text-foreground",
									children: "My Scheduled Bookings"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] font-mono text-muted-foreground",
									children: [
										"Synced with Online Server (",
										bookings.length,
										" ",
										bookings.length === 1 ? "entry" : "entries",
										")"
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "outline",
								className: "border-emerald-500/40 text-emerald-400 text-[10px] font-mono shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3 mr-1" }), " Live Sync"]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 overflow-y-auto py-3 space-y-3.5 pr-1",
						children: [bookings.length > 0 && onOpenVisitModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-primary/15 via-primary/5 to-transparent border border-primary/30 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-lg bg-primary/20 text-primary grid place-items-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-foreground",
									children: "Book Another Site Visit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-mono text-muted-foreground",
									children: "Reserve another plot tour or session"
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								onClick: () => {
									setOpen(false);
									onOpenVisitModal();
								},
								className: "h-8 px-3 text-[11px] font-mono font-semibold uppercase bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 mr-1" }), " Book Another"]
							})]
						}), bookings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center py-10 px-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-14 rounded-full bg-surface border border-border mx-auto grid place-items-center text-muted-foreground/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-7" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-display text-base uppercase text-foreground",
									children: "No Bookings Found On This Device"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground font-mono leading-relaxed max-w-sm mx-auto",
									children: "When you schedule a site tour or submit a booking inquiry, your visit date, chosen time slot, and plot preferences will be securely saved and synced with our online server."
								}),
								onOpenVisitModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									onClick: () => {
										setOpen(false);
										onOpenVisitModal();
									},
									className: "mt-2 text-xs uppercase font-mono tracking-wider font-semibold bg-primary text-primary-foreground hover:bg-primary/90",
									children: "Schedule A Visit Now →"
								})
							]
						}) : bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/30 bg-surface/90 p-4 space-y-3 shadow-sm hover:border-primary/60 transition-all text-left relative overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2 border-b border-border/60 pb-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-mono font-bold text-primary",
											children: ["#", b.id]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold uppercase",
											children: "Confirmed & Synced"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] font-mono text-muted-foreground mt-0.5",
										children: [
											"Booked:",
											" ",
											new Date(b.bookedAt).toLocaleString("en-IN", {
												day: "numeric",
												month: "short",
												hour: "2-digit",
												minute: "2-digit"
											})
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: (e) => handleStartEdit(b, e),
											className: "size-7 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 grid place-items-center transition-colors",
											title: "Edit Booking & Sync with Server",
											"aria-label": "Edit Booking",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: (e) => {
												e.stopPropagation();
												setConfirmDeleteId(b.id);
											},
											disabled: deletingId === b.id,
											className: "size-7 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 grid place-items-center transition-colors disabled:opacity-50",
											title: "Delete Booking from Device & Server",
											"aria-label": "Delete Booking",
											children: deletingId === b.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin text-destructive" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
										})]
									})]
								}),
								confirmDeleteId === b.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-lg bg-destructive/10 border border-destructive/30 text-xs font-mono space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-destructive font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Delete from server & admin ledger?" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground",
											children: [
												"This will permanently cancel booking #",
												b.id,
												" on the website server and admin panel."
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 pt-1 justify-end",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "sm",
												onClick: () => setConfirmDeleteId(null),
												className: "h-7 text-xs font-mono px-2.5",
												children: "Cancel"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "destructive",
												size: "sm",
												disabled: deletingId === b.id,
												onClick: () => handleExecuteDelete(b.id, b.phone),
												className: "h-7 text-xs font-mono px-2.5 font-semibold",
												children: deletingId === b.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin mr-1" }), " Deleting..."] }) : "Confirm Delete"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: formatDateLabel(b.visitDate)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate font-semibold",
												children: b.slot || "Morning (10:00 AM)"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-muted-foreground sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5 text-cyan-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-foreground truncate",
												children: b.plotPreference
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-muted-foreground sm:col-span-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-muted-foreground shrink-0" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-foreground truncate",
													children: b.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "·"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 text-muted-foreground shrink-0" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-foreground truncate",
													children: b.phone
												})
											]
										}),
										b.message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] text-muted-foreground sm:col-span-2 bg-background/50 p-2 rounded border border-border/40 italic",
											children: [
												"\"",
												b.message,
												"\""
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 pt-1 border-t border-border/50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "sm",
											className: "flex-1 h-8 text-[11px] font-mono font-semibold uppercase bg-emerald-600 hover:bg-emerald-500 text-white",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent(`Hello Vishal Chauhan, I am inquiring about my Galaxy Green booking #${b.id} for ${b.plotPreference} scheduled on ${formatDateLabel(b.visitDate)} at ${b.slot || "10:00 AM"}.`)}`,
												target: "_blank",
												rel: "noreferrer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3 mr-1.5" }), " WhatsApp MD"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: (e) => handleStartEdit(b, e),
											className: "h-8 px-2.5 text-[11px] font-mono font-semibold uppercase border-border hover:border-primary text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3 mr-1" }), " Edit"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "outline",
											size: "sm",
											className: "h-8 px-2.5 text-[11px] font-mono font-semibold uppercase border-border hover:border-primary",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `tel:+${PHONE_NUMBER}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 mr-1" }), " Call"]
											})
										})
									]
								})
							]
						}, b.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-3 border-t border-border/70 flex items-center justify-between text-[11px] font-mono text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-primary" }), " Synced with Server & Admin"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [bookings.length > 0 && onOpenVisitModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => {
									setOpen(false);
									onOpenVisitModal();
								},
								className: "h-7 text-xs font-mono border-primary/40 text-primary hover:bg-primary/10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3 mr-1" }), " Book Another"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => setOpen(false),
								className: "h-7 text-xs font-mono",
								children: "Close"
							})]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(editingBooking),
			onOpenChange: (isOpen) => {
				if (!isOpen && !isSavingEdit) setEditingBooking(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md p-5 sm:p-6 bg-card border-border shadow-2xl rounded-2xl max-h-[90vh] overflow-y-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "space-y-1 pb-3 border-b border-border/70 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePen, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "font-display text-lg uppercase tracking-tight text-foreground",
								children: "Edit Scheduled Visit"
							})]
						}), editingBooking && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "font-mono text-xs text-primary border-primary/40",
							children: ["#", editingBooking.id]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground font-mono",
						children: "Updates will instantly sync with the website database and dealer admin panel."
					})]
				}), editingBooking && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSaveEdit,
					className: "space-y-4 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-2.5 rounded-lg bg-surface/70 border border-border/60 text-xs font-mono flex items-center justify-between text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground font-medium",
									children: editingBooking.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5 text-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: editingBooking.phone
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "edit-visit-date",
								className: "text-xs font-mono uppercase text-muted-foreground",
								children: "Scheduled Visit Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "edit-visit-date",
									type: "date",
									min: todayStr,
									value: editDate,
									onChange: (e) => setEditDate(e.target.value),
									required: true,
									className: "font-mono text-xs bg-surface border-border focus:border-primary text-foreground"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-mono uppercase text-muted-foreground",
									children: "Preferred Time Slot"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-1.5",
									children: PRESET_SLOTS.map((slot) => {
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setEditSlot(slot),
											className: `text-[11px] font-mono p-2 rounded-lg border text-left transition-all ${editSlot === slot ? "bg-primary/20 border-primary text-primary font-semibold shadow-sm" : "bg-surface/50 border-border/70 text-muted-foreground hover:border-primary/50"}`,
											children: slot
										}, slot);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									placeholder: "Or custom time (e.g. 11:30 AM)",
									value: editSlot,
									onChange: (e) => setEditSlot(e.target.value),
									className: "font-mono text-xs mt-1.5 bg-surface border-border"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-mono uppercase text-muted-foreground",
									children: "Plot Size / Preference"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 gap-1.5",
									children: PRESET_PLOTS.map((plot) => {
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setEditPlot(plot),
											className: `text-[11px] font-mono px-2.5 py-1.5 rounded-lg border text-left transition-all ${editPlot === plot ? "bg-primary/20 border-primary text-primary font-semibold shadow-sm" : "bg-surface/50 border-border/70 text-muted-foreground hover:border-primary/50"}`,
											children: plot
										}, plot);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									placeholder: "Or enter custom plot size...",
									value: editPlot,
									onChange: (e) => setEditPlot(e.target.value),
									className: "font-mono text-xs mt-1.5 bg-surface border-border"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "edit-message",
								className: "text-xs font-mono uppercase text-muted-foreground",
								children: "Special Instructions / Notes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "edit-message",
								rows: 2,
								placeholder: "Any questions, cab pickup request, or specific plot requirement...",
								value: editMessage,
								onChange: (e) => setEditMessage(e.target.value),
								className: "font-mono text-xs bg-surface border-border resize-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2 pt-2 border-t border-border/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								disabled: isSavingEdit,
								onClick: () => setEditingBooking(null),
								className: "font-mono text-xs",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								size: "sm",
								disabled: isSavingEdit,
								className: "font-mono text-xs uppercase bg-primary text-primary-foreground hover:bg-primary/90 font-semibold",
								children: isSavingEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin mr-1.5" }), " Syncing With Server..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 mr-1.5" }), " Save & Sync"] })
							})]
						})
					]
				})]
			})
		})
	] });
}
//#endregion
export { MyBookingsDrawer };
