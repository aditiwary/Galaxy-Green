import { o as __toESM } from "../_runtime.mjs";
import { b as require_react, y as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { G as Clock, J as CircleCheck, K as CircleX, o as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as isHourEntirelyPassed, c as isWithinOperatingHours, d as splitTimeToHMP, i as getLocalDateString, n as composeHMPToTime, o as isSpecificTimePassed } from "./visit-helpers-Cila1FpI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ClockTimePicker-CK5prHzn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HOURS_LIST = [
	7,
	8,
	9,
	10,
	11,
	12,
	1,
	2,
	3,
	4,
	5,
	6,
	7
];
var MINUTES_LIST = [
	0,
	15,
	30,
	45
];
function ClockTimePicker({ value, onChange, selectedDate, className = "", compact = false }) {
	const todayStr = (0, import_react.useMemo)(() => getLocalDateString(), []);
	const isToday = (selectedDate || "").trim() === todayStr;
	const { hour12, minute, period } = (0, import_react.useMemo)(() => {
		return splitTimeToHMP(value);
	}, [value]);
	const hourAngle = (0, import_react.useMemo)(() => {
		return (hour12 % 12 + minute / 60) * 30;
	}, [hour12, minute]);
	const minuteAngle = (0, import_react.useMemo)(() => {
		return minute * 6;
	}, [minute]);
	const isCurrentTimePassed = (0, import_react.useMemo)(() => {
		return isSpecificTimePassed(hour12, minute, period, selectedDate);
	}, [
		hour12,
		minute,
		period,
		selectedDate
	]);
	const isCurrentInOperatingHours = (0, import_react.useMemo)(() => {
		return isWithinOperatingHours(hour12, minute, period);
	}, [
		hour12,
		minute,
		period
	]);
	const isAmEntirelyPassedToday = (0, import_react.useMemo)(() => {
		if (!isToday) return false;
		return (/* @__PURE__ */ new Date()).getHours() >= 12;
	}, [isToday]);
	const isPmEntirelyPassedToday = (0, import_react.useMemo)(() => {
		if (!isToday) return false;
		return (/* @__PURE__ */ new Date()).getHours() >= 19;
	}, [isToday]);
	const updateTime = (newH, newM, newP) => {
		onChange(composeHMPToTime(newH, newM, newP));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border border-primary/30 bg-surface/95 p-3.5 sm:p-4 backdrop-blur-md shadow-sm transition-all ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border/70",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-12 sm:size-14 rounded-full bg-background border-2 border-primary/50 shadow-[0_0_12px_rgba(16,185,129,0.25)] flex items-center justify-center shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-1 rounded-full border border-dashed border-border/60" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "12"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "6"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute left-1 text-[8px] font-mono text-muted-foreground font-bold",
								children: "9"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute w-1 bg-primary rounded-full origin-bottom transition-transform duration-300",
								style: {
									height: "14px",
									bottom: "50%",
									transform: `rotate(${hourAngle}deg)`
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute w-0.5 bg-amber-400 rounded-full origin-bottom transition-transform duration-300",
								style: {
									height: "18px",
									bottom: "50%",
									transform: `rotate(${minuteAngle}deg)`
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-white border border-primary z-10" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] uppercase tracking-wider font-mono font-semibold text-muted-foreground",
							children: "Visit Timing Clock"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-1 mt-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-lg sm:text-xl font-bold tracking-tight text-foreground text-glow-subtle",
							children: [
								String(hour12).padStart(2, "0"),
								" : ",
								String(minute).padStart(2, "0")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs font-bold text-primary ml-0.5 px-1.5 py-0.5 rounded bg-primary/10 border border-primary/30 uppercase",
							children: period
						})]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: isCurrentTimePassed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-destructive/15 border border-destructive/40 text-destructive text-[11px] font-mono flex items-center gap-1.5 animate-pulse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Time Passed Today" })]
					}) : !isCurrentInOperatingHours ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-amber-500/15 border border-amber-500/40 text-amber-300 text-[11px] font-mono flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Outside 7 AM – 7 PM" })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 shrink-0 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Available Slot" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase font-mono tracking-wider text-muted-foreground font-semibold",
					children: "1. Meridian:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex rounded-lg border border-border bg-background/80 p-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: isAmEntirelyPassedToday,
						onClick: () => {
							if (isAmEntirelyPassedToday) return;
							updateTime(hour12, minute, "AM");
						},
						className: `px-3 py-1 text-xs font-mono font-semibold rounded-md transition-all ${isAmEntirelyPassedToday ? "opacity-35 cursor-not-allowed line-through text-muted-foreground" : period === "AM" ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"}`,
						children: ["AM ", isAmEntirelyPassedToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] no-underline",
							children: "✕"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: isPmEntirelyPassedToday,
						onClick: () => {
							if (isPmEntirelyPassedToday) return;
							updateTime(hour12, minute, "PM");
						},
						className: `px-3 py-1 text-xs font-mono font-semibold rounded-md transition-all ${isPmEntirelyPassedToday ? "opacity-35 cursor-not-allowed line-through text-muted-foreground" : period === "PM" ? "bg-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground"}`,
						children: ["PM ", isPmEntirelyPassedToday && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] no-underline",
							children: "✕"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-[10px] font-mono text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "2. Select Hour:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: period === "AM" ? "Morning (7–11 AM)" : "Afternoon/Evening (12–7 PM)" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-6 sm:grid-cols-6 gap-1.5",
					children: HOURS_LIST.map((h, idx) => {
						const isInOps = period === "AM" ? h >= 7 && h <= 11 : h === 12 || h >= 1 && h <= 7;
						const isPassed = isHourEntirelyPassed(h, period, selectedDate);
						const isSelected = hour12 === h;
						const disabled = !isInOps || isPassed;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled,
							onClick: () => {
								if (disabled) return;
								updateTime(h, minute, period);
							},
							className: `py-1.5 px-1 rounded-md text-xs font-mono font-medium border text-center transition-all relative ${disabled ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary font-bold shadow-glow ring-1 ring-primary/40" : "bg-background/80 border-border text-foreground hover:border-primary/50 hover:bg-surface-hover"}`,
							title: !isInOps ? `Hour ${h} ${period} is outside 7 AM – 7 PM daylight visiting hours` : isPassed ? `Hour ${h} ${period} has already passed for today` : `Select ${h}:00 ${period}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[8px] block opacity-75 font-normal",
								children: period
							})]
						}, `${h}-${idx}`);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-[10px] font-mono text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "3. Select Minutes:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "15-min Intervals" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-1.5",
					children: MINUTES_LIST.map((m) => {
						const isPassed = isSpecificTimePassed(hour12, m, period, selectedDate);
						const isSelected = minute === m;
						const disabled = isPassed;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled,
							onClick: () => {
								if (disabled) return;
								updateTime(hour12, m, period);
							},
							className: `py-1.5 rounded-md text-xs font-mono font-semibold border text-center transition-all ${disabled ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary shadow-glow ring-1 ring-primary/40" : "bg-background/80 border-border text-foreground hover:border-primary/50 hover:bg-surface-hover"}`,
							title: isPassed ? `Time :${String(m).padStart(2, "0")} has passed for today` : `Set to ${String(m).padStart(2, "0")} mins`,
							children: [
								":",
								String(m).padStart(2, "0"),
								isPassed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-[8px] no-underline",
									children: "✕"
								})
							]
						}, m);
					})
				})]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 pt-2.5 border-t border-border/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between mb-1.5 text-[10px] font-mono text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase font-semibold tracking-wider",
						children: "Quick Daylight Tour Slots:"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [
						{
							label: "10:00 AM",
							h: 10,
							m: 0,
							p: "AM",
							desc: "Morning"
						},
						{
							label: "11:30 AM",
							h: 11,
							m: 30,
							p: "AM",
							desc: "Midday"
						},
						{
							label: "02:00 PM",
							h: 2,
							m: 0,
							p: "PM",
							desc: "Afternoon"
						},
						{
							label: "04:30 PM",
							h: 4,
							m: 30,
							p: "PM",
							desc: "Sunset"
						},
						{
							label: "05:30 PM",
							h: 5,
							m: 30,
							p: "PM",
							desc: "Golden Hour"
						}
					].map((slot) => {
						const isPassed = isSpecificTimePassed(slot.h, slot.m, slot.p, selectedDate);
						const isSelected = hour12 === slot.h && minute === slot.m && period === slot.p;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: isPassed,
							onClick: () => {
								if (isPassed) return;
								updateTime(slot.h, slot.m, slot.p);
							},
							className: `px-2 py-1 rounded text-[10px] font-mono border transition-all ${isPassed ? "opacity-30 cursor-not-allowed bg-background/40 line-through text-muted-foreground border-border/40" : isSelected ? "bg-primary text-primary-foreground border-primary font-bold shadow-glow" : "bg-background/80 border-border text-muted-foreground hover:text-foreground hover:border-primary/40"}`,
							children: [
								slot.label,
								" (",
								slot.desc,
								")"
							]
						}, slot.label);
					})
				})]
			})
		]
	});
}
//#endregion
export { ClockTimePicker as t };
