import { a as objectType, i as numberType, n as enumType, o as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plot-types-Dpo7Dr3n.js
var plotSchema = objectType({
	number: stringType().min(1, "Plot number required"),
	sizeSqFt: numberType().min(100, "Minimum 100 sq ft"),
	dimensions: stringType().min(3, "Dimensions required (e.g. 25 × 40 ft)"),
	facing: enumType([
		"East",
		"North",
		"Park Facing",
		"Boulevard Corner",
		"West",
		"South"
	]),
	roadWidth: stringType().default("30 ft Internal"),
	ratePerSqFt: numberType().min(500, "Rate per sq ft required"),
	status: enumType([
		"Available",
		"Fast Selling",
		"Reserved",
		"Sold Out"
	]),
	feature: stringType().default("Freehold residential plot with clear title")
});
var DEFAULT_PLOTS = [
	{
		id: "plot-a1",
		number: "A-101",
		sizeSqFt: 1e3,
		dimensions: "25 × 40 ft",
		facing: "East",
		roadWidth: "30 ft Internal",
		ratePerSqFt: 1199,
		status: "Available",
		feature: "Ideal for 3BHK compact luxury independent duplex."
	},
	{
		id: "plot-a2",
		number: "A-102",
		sizeSqFt: 1e3,
		dimensions: "25 × 40 ft",
		facing: "North",
		roadWidth: "30 ft Internal",
		ratePerSqFt: 1199,
		status: "Fast Selling",
		feature: "Vastu-compliant entrance with clear morning sunlight."
	},
	{
		id: "plot-b1",
		number: "B-201",
		sizeSqFt: 1200,
		dimensions: "30 × 40 ft",
		facing: "Park Facing",
		roadWidth: "30 ft Internal",
		ratePerSqFt: 1199,
		status: "Fast Selling",
		feature: "Direct unobstructed view of central green park & jogging trail."
	},
	{
		id: "plot-b2",
		number: "B-205",
		sizeSqFt: 1500,
		dimensions: "30 × 50 ft",
		facing: "East",
		roadWidth: "30 ft Internal",
		ratePerSqFt: 1199,
		status: "Available",
		feature: "Generous frontage for double-car porch and front garden."
	},
	{
		id: "plot-c1",
		number: "C-301",
		sizeSqFt: 2e3,
		dimensions: "40 × 50 ft",
		facing: "Park Facing",
		roadWidth: "40 ft Boulevard",
		ratePerSqFt: 1199,
		status: "Available",
		feature: "Premium estate plot overlooking central landscaped green park & avenue."
	},
	{
		id: "plot-c2",
		number: "C-308",
		sizeSqFt: 2e3,
		dimensions: "40 × 50 ft",
		facing: "Boulevard Corner",
		roadWidth: "40 ft × 30 ft Dual Road",
		ratePerSqFt: 1299,
		status: "Fast Selling",
		feature: "Two-side open corner plot with grand boulevard visibility."
	},
	{
		id: "plot-d1",
		number: "D-401",
		sizeSqFt: 3e3,
		dimensions: "50 × 60 ft",
		facing: "Boulevard Corner",
		roadWidth: "40 ft Main Avenue",
		ratePerSqFt: 1299,
		status: "Reserved",
		feature: "Ultra-luxury mansion plot with expansive private lawn and garden clearance."
	},
	{
		id: "plot-d2",
		number: "D-405",
		sizeSqFt: 1e3,
		dimensions: "25 × 40 ft",
		facing: "North",
		roadWidth: "30 ft Internal",
		ratePerSqFt: 1199,
		status: "Available",
		feature: "Prime location near security entrance and visitor parking."
	}
];
//#endregion
export { plotSchema as n, DEFAULT_PLOTS as t };
