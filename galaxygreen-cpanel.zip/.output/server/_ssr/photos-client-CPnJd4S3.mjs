import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { i as createSsrRpc } from "./server-inquiries-BZCzG7ab.mjs";
import { t as DEFAULT_PLOTS } from "./plot-types-BfZTxHrx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/photos-client-CPnJd4S3.js
var getPlotsFn = createServerFn({ method: "GET" }).handler(createSsrRpc("edbac7c3ae6095459940938f08e64e482be3eee43774392588100cc872807d7b"));
var createPlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("fd475df625a73983c0c3375d6a7527582026cb8a08676484661b19b79f06298e"));
var updatePlotStatusFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("259c099986c4c7c61bab8947852c80d8fde8680824e76666722a26c4725ea1fd"));
var deletePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("d125ede39de5148edd10518c551ad2202cbab0d643afefdf8b8a497be6188831"));
var updatePlotFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("0f2f9b5130e556d3703f4e4e0b680d8beadac7e625696b2c98bdb56803ea808a"));
var PLOTS_STORAGE_KEY = "galaxy_green_plots_v1";
async function fetchLivePlots() {
	try {
		const serverPlots = await getPlotsFn();
		if (Array.isArray(serverPlots) && serverPlots.length > 0) {
			if (typeof window !== "undefined") localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(serverPlots));
			return serverPlots;
		}
	} catch (err) {
		console.warn("Using local storage fallback for plots:", err);
	}
	if (typeof window !== "undefined") {
		const saved = localStorage.getItem(PLOTS_STORAGE_KEY);
		if (saved) try {
			return JSON.parse(saved);
		} catch {}
		localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(DEFAULT_PLOTS));
	}
	return DEFAULT_PLOTS;
}
function getClientToken$1(token) {
	if (token) return token;
	if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || void 0;
}
async function addLivePlot(input, token) {
	const activeToken = getClientToken$1(token);
	try {
		const res = await createPlotFn({ data: {
			plot: input,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.plot) {
			if (typeof window !== "undefined") try {
				const updated = [...(await fetchLivePlots()).filter((p) => p.id !== res.plot.id), res.plot];
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return res.plot;
		}
		if (res?.error) console.error("Failed to add plot to database:", res.error);
	} catch (err) {
		console.error("Server add plot error:", err);
	}
	return null;
}
async function setPlotStatus(id, status, token) {
	const activeToken = getClientToken$1(token);
	try {
		if ((await updatePlotStatusFn({ data: {
			id,
			status,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLivePlots()).map((p) => p.id === id ? {
					...p,
					status
				} : p);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server plot status update error:", err);
	}
	return false;
}
async function removePlot(id, token) {
	const activeToken = getClientToken$1(token);
	try {
		if ((await deletePlotFn({ data: {
			id,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLivePlots()).filter((p) => p.id !== id);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updated));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server plot deletion error:", err);
	}
	return false;
}
async function updateLivePlot(id, plotUpdates, token) {
	const activeToken = getClientToken$1(token);
	try {
		const res = await updatePlotFn({ data: {
			id,
			plot: plotUpdates,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.plot) {
			if (typeof window !== "undefined") try {
				const updatedList = (await fetchLivePlots()).map((p) => p.id === id ? res.plot : p);
				localStorage.setItem(PLOTS_STORAGE_KEY, JSON.stringify(updatedList));
			} catch {}
			return res.plot;
		}
	} catch (err) {
		console.error("Server plot update error:", err);
	}
	return null;
}
var DEFAULT_GALLERY_PHOTOS = [
	{
		id: "site-photo-1",
		src: "/site-photos/galaxy-green-actual-site-1.jpg",
		title: "Ground Demarcation & Boundary Pillars",
		category: "demarcation",
		categoryLabel: "Demarcation & Registry Ready",
		tag: "Phase 1 Demarcation",
		dimensionsLabel: "Min 600 sq ft to Custom Requirements",
		description: "Clear on-ground plot boundaries with reinforced stone pillars and concrete edging. Plots start from compact 600 sq ft up to large custom footprints.",
		highlights: [
			"Physical boundary curbing & corner pillars installed",
			"Immediate registry & mutation (Dakhil Kharij) ready",
			"Customizable plot dimensions starting from 600 sq ft",
			"Direct frontage onto wide 30ft internal access roads"
		]
	},
	{
		id: "site-photo-2",
		src: "/site-photos/galaxy-green-actual-site-2.jpg",
		title: "Wide 30-Ft Internal Road & Sunset Streetlighting",
		category: "roads",
		categoryLabel: "Internal Roads & Lighting",
		tag: "30-Ft Road Infrastructure",
		dimensionsLabel: "30-Ft Wide Internal Avenue",
		description: "Wide, leveled internal township road network illuminated by active street lighting poles with utility pathways.",
		highlights: [
			"30-ft wide internal avenue for smooth two-way driving",
			"Functional electric poles and evening streetlights active",
			"Direct connectivity to Kanpur-Lucknow Expressway (3 km)",
			"Unobstructed access for construction materials and private vehicles"
		]
	},
	{
		id: "site-photo-3",
		src: "/site-photos/galaxy-green-actual-site-3.jpg",
		title: "Elevated Township Panorama & Surrounding Greenery",
		category: "panorama",
		categoryLabel: "Township Horizon",
		tag: "Open Green Environs",
		dimensionsLabel: "Pollution-Free Eco Zone",
		description: "Panoramic elevated perspective of Sai Suraksha Nagar showing peaceful residential surroundings and overhead water infrastructure.",
		highlights: [
			"Overhead water reservoir ensuring reliable high-pressure water supply",
			"Clean, green environment away from city congestion",
			"Close proximity to Railway Station (1.5 km) & Main Market (500 m)",
			"Vastu-compliant residential zoning with open morning sunlight"
		]
	},
	{
		id: "site-photo-4",
		src: "/site-photos/galaxy-green-actual-site-4.jpg",
		title: "Main Access Boulevard & Plot Inventory Grid",
		category: "roads",
		categoryLabel: "Boulevard & Demarcations",
		tag: "Central Layout View",
		dimensionsLabel: "Allotment Starting ₹7.19 Lakh",
		description: "Central access road traversing the plotted layout with clearly lined plot parcels ready for boundary walling.",
		highlights: [
			"Transparent Phase 1 allotment at ₹1,199 / sq ft",
			"Compact 600 sq ft villas start at only ₹7.19 Lakh",
			"Wide turning radiuses suitable for SUVs and delivery trucks",
			"Independent housing cluster already developing rapidly on site"
		]
	},
	{
		id: "site-photo-5",
		src: "/site-photos/galaxy-green-actual-site-5.jpg",
		title: "Underground Utility Lines & Soil Leveling Progress",
		category: "construction",
		categoryLabel: "Civil Engineering",
		tag: "Ground Work Active",
		dimensionsLabel: "Phase 1 Fast-Track Delivery",
		description: "Active compaction and leveling machinery preparing future residential sectors with pre-laid drainage conduits.",
		highlights: [
			"Real residential buildings under active brick and pillar construction",
			"Immediate possession allows buyers to begin construction right away",
			"Only 2 km from TS Mishra Medical College & Hospital",
			"3 km from CCS Airport & 4 km from Metro Station"
		]
	},
	{
		id: "site-photo-6",
		src: "/site-photos/galaxy-green-airport-connectivity.jpg",
		title: "Chaudhary Charan Singh International Airport & Amausi Plots",
		category: "panorama",
		categoryLabel: "Airport & Metro Connectivity",
		tag: "Prime Airport Vicinity",
		dimensionsLabel: "3 Km from CCS Airport",
		description: "Strategic aerial master photograph showing Chaudhary Charan Singh International Airport (Terminal 1 & 2, Runway 09/27), Kanpur Road (NH27), Amausi Metro Station, and the immediate proximity of Amausi available plots at Galaxy Green Sai Suraksha Nagar.",
		highlights: [
			"Direct proximity to CCS International Airport (LKO) & Terminals 1 & 2",
			"Immediate access to Kanpur Road (NH27) & Amausi Metro Station",
			"Rapidly appreciating high-capital growth corridor",
			"Direct expressway arterial connectivity across Lucknow & NCR"
		]
	}
];
var getGalleryPhotosFn = createServerFn({ method: "GET" }).handler(createSsrRpc("8c710ba4c68dd2ed572581dc584f419650b9e0a6aa6f12e5d0c6347969b95968"));
var uploadGalleryPhotoFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("9d6b73876cd40b51a52c7ab36aa575bd58faa97bae203d0ffe1f8d16caf4ad01"));
var deleteGalleryPhotoFn = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e1c9dfbebb211bc04aae75249b29da3d4165d897aeceaad3c8d64a443253e4fd"));
var PHOTOS_STORAGE_KEY = "galaxy_green_photos_v1";
async function fetchLiveGalleryPhotos() {
	try {
		const serverPhotos = await getGalleryPhotosFn();
		if (Array.isArray(serverPhotos) && serverPhotos.length > 0) {
			if (typeof window !== "undefined") localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(serverPhotos));
			return serverPhotos;
		}
	} catch (err) {
		console.warn("Using local storage fallback for photos:", err);
	}
	if (typeof window !== "undefined") {
		const saved = localStorage.getItem(PHOTOS_STORAGE_KEY);
		if (saved) try {
			return JSON.parse(saved);
		} catch {}
		localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(DEFAULT_GALLERY_PHOTOS));
	}
	return DEFAULT_GALLERY_PHOTOS;
}
function getClientToken(token) {
	if (token) return token;
	if (typeof window !== "undefined") return sessionStorage.getItem("gg_dealer_token") || localStorage.getItem("gg_dealer_token") || void 0;
}
async function uploadLivePhoto(photoInput, token) {
	const activeToken = getClientToken(token);
	try {
		const res = await uploadGalleryPhotoFn({ data: {
			photo: photoInput,
			...activeToken ? { token: activeToken } : {}
		} });
		if (res?.success && res.photo) {
			if (typeof window !== "undefined") try {
				const current = await fetchLiveGalleryPhotos();
				const updated = [res.photo, ...current.filter((p) => p.id !== res.photo.id)];
				localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(updated));
				window.dispatchEvent(new CustomEvent("gallery-updated"));
			} catch {}
			return res.photo;
		}
		if (res?.error) console.error("Failed to upload photo to database:", res.error);
	} catch (err) {
		console.error("Server photo upload error:", err);
	}
	return null;
}
async function removeLivePhoto(id, token) {
	const activeToken = getClientToken(token);
	try {
		if ((await deleteGalleryPhotoFn({ data: {
			id,
			...activeToken ? { token: activeToken } : {}
		} }))?.success) {
			if (typeof window !== "undefined") try {
				const updated = (await fetchLiveGalleryPhotos()).filter((p) => p.id !== id);
				localStorage.setItem(PHOTOS_STORAGE_KEY, JSON.stringify(updated));
				window.dispatchEvent(new CustomEvent("gallery-updated"));
			} catch {}
			return true;
		}
	} catch (err) {
		console.error("Server photo deletion error:", err);
	}
	return false;
}
//#endregion
export { removePlot as a, uploadLivePhoto as c, removeLivePhoto as i, fetchLiveGalleryPhotos as n, setPlotStatus as o, fetchLivePlots as r, updateLivePlot as s, addLivePlot as t };
