//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BAqlme3Z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-55c_6lKZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-55c_6lKZ.js"
		} }]
	},
	"/": {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-rGZOGqIO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
