//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BhA7SYrg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BJz-F4zQ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BJz-F4zQ.js"
		} }]
	},
	"/": {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B0aewYDl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
