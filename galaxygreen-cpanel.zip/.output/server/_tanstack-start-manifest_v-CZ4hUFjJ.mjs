//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CZ4hUFjJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BtcODWq1.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BtcODWq1.js"
		} }]
	},
	"/": {
		filePath: "/Users/rajadityaaa23/Downloads/Galaxy_Green_V101/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-fwHu_eVp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
